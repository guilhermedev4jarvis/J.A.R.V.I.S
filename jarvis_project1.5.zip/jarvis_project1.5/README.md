# JARVIS Project 1.5 — PT-BR · Feedback visual · UI minimalista

## Destaques desta build

### Voz sempre em português
- System prompt força **português do Brasil** em todas as respostas
- Labels da HUD: OUVINDO · FALANDO · PENSANDO · PROCESSANDO · EM ESPERA

### Feedback visual pós-ação (a)
Cada ferramenta mostra um **toast** na tela, em português:
- ✓ `Aba aberta no navegador padrão: YouTube (youtube.com)`
- ✕ `Não foi possível abrir Chrome`
- ! `Pedido enviado, sem confirmação`

Implementado em `core/action_feedback.py` + toast no `ui.py`, chamado após **toda** tool em `_execute_tool`.

### Proatividade (b)
`actions/proactive.py` 3.0:
- CPU/RAM em tempo real (alerta se CPU alta)
- Eventos do Google Calendar (se OAuth existir)
- Foco rotativo + prompts em português

### UI minimalista (c)
- Fundo **preto puro**
- Orbe central **branco/prateado** com partículas reativas à voz (`hud_style=core`)
- Toast flutuante com resultado das ações
- Atalho na Área de Trabalho + Menu Iniciar (Windows)  
  → botão direito no atalho → **Fixar na barra de tarefas**

### Pipeline local (sem download de voz neural)
- STT: Whisper base (CPU)
- LLM: gemini-2.5-flash
- TTS: voz do sistema (`tts_system`)

---

## Como rodar

```bash
cd desktop
python -m venv venv
# Windows: venv\Scripts\activate
# Linux/macOS: source venv/bin/activate
python setup.py
python -m pip install faster-whisper   # STT local
python main.py
```

No painel ⚙ use o botão de **atalho** para criar ícone na área de trabalho / menu iniciar.

---

## Actions incluídas
clipboard_smart · window_manager · powershell_cmd · system_health ·  
file_organize · focus_timer · code_review_local · email_triage · meeting_brief  
(+ todas as actions originais)

---

Feito para uso real.
