# Autoria e identidade

## Identidade do produto

| Campo | Valor |
|--------|--------|
| **Nome do aplicativo** | MARK LVI (56) |
| **Nome do assistente padrão** | JARVIS / MARK LVI |
| **Autor** | Guilherme |
| **Ano** | 2026 |
| **Repositório de referência** | conforme publicação oficial do autor |

A interface, o instalador e a documentação devem apresentar essa identidade.
Créditos e licenças de bibliotecas e ativos de terceiros permanecem nos
respectivos projetos (PyQt6, Google, Ollama, faster-whisper, etc.).

## Licença (resumo)

- **Uso pessoal / não comercial:** gratuito, nos termos do arquivo `LICENSE`.
- **Uso comercial:** somente com **taxa mensal** paga ao autor **e** **contrato
  de venda ou aluguel assinado online** antes do uso comercial.
- Valores de referência e regras completas: ver **`LICENSE`**.

Não use o Software em contexto comercial sem contrato e pagamento em dia.

## Comportamento na primeira execução

Na primeira execução, o MARK LVI pode ser configurado para iniciar no login do
usuário. Essa opção pode ser desligada em Controles; a escolha é mantida.

A ativação por voz é opcional: ao configurá-la, os modelos são baixados uma vez;
em espera, o reconhecimento local aceita “Jarvis”, “Mark LVI” e “Hey Jarvis”,
sem enviar o áudio de espera ao serviço de conversa na nuvem.

## Motor online e ajudante offline

- **Padrão com internet:** Gemini Live (chave em `.env` / `config/api_keys.json`).
- **Sem internet:** ajudante local via Ollama (`qwen2.5:7b` por padrão), Whisper
  e TTS local; ao voltar a rede, o app tenta retomar o Gemini.

## Contato comercial

Solicitações de licença comercial, contrato online e condições especiais devem
ser feitas pelo canal oficial do autor (repositório ou contato indicado na
publicação do projeto).
