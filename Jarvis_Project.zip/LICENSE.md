MARK LVI (56) — JARVIS
Copyright (c) 2026 Guilherme

================================================================================
LICENÇA DE USO DO SOFTWARE MARK LVI (56)
================================================================================

Este arquivo define os termos de uso do código-fonte, binários, documentação e
materiais associados do MARK LVI (56) (“Software”), de autoria de Guilherme
(“Licenciante”).

Bibliotecas, modelos e ativos de terceiros (PyQt6, Google Gemini, Ollama,
Whisper, etc.) permanecem sob as licenças dos respectivos titulares.

--------------------------------------------------------------------------------
1. USO PESSOAL E NÃO COMERCIAL (GRATUITO)
--------------------------------------------------------------------------------

É permitido, sem pagamento de taxa ao Licenciante:

  a) baixar, instalar e executar o Software em equipamentos de uso pessoal;
  b) estudar o código-fonte e adaptá-lo para uso pessoal;
  c) redistribuir cópias não modificadas ou modificadas do Software, desde que:
     - mantenham este arquivo LICENSE e o arquivo AUTORIA.md;
     - não cobrem pelo Software em si;
     - não utilizem o Software em atividade comercial (ver seção 2).

Uso “não comercial” inclui estudo, hobby, demonstração acadêmica e avaliação
técnica sem receita vinculada ao Software.

--------------------------------------------------------------------------------
2. USO COMERCIAL (PAGO + CONTRATO)
--------------------------------------------------------------------------------

Qualquer uso comercial do Software exige cumulativamente:

  (i)  pagamento de uma taxa de licença mensal ao Licenciante; e
  (ii) assinatura de um contrato de venda ou aluguel online, firmado com o
       Licenciante, antes do início do uso comercial.

Considera-se uso comercial, entre outros:

  - oferecer o Software (ou serviço baseado nele) a clientes, mediante pagamento
    ou em troca de vantagem econômica;
  - incorporar o Software em produto, SaaS, appliance ou consultoria vendida;
  - uso interno em empresa, órgão ou organização com fins econômicos, além de
    avaliação pontual;
  - redistribuir versões modificadas em contexto comercial.

2.1. Taxa mensal (valores de referência)

  Enquanto não houver tabela diversa no contrato online vigente:

  - Pessoa física / MEI / uso comercial leve:
      R$ 49,00 (quarenta e nove reais) por mês, por usuário ou instalação
      principal, ou o equivalente em USD na data do pagamento
      (referência: USD 9,90 / mês).

  - Empresa (uso em equipe, produto ou serviço ao cliente):
      R$ 149,00 (cento e quarenta e nove reais) por mês, por organização,
      cobrindo até 10 instalações; acima disso, valores sob proposta,
      ou o equivalente em USD (referência: USD 29,90 / mês).

  Os valores podem ser atualizados pelo Licenciante com aviso prévio de 30 dias
  para novos contratos ou renovações. O contrato online assinado prevalece sobre
  esta tabela quando houver divergência.

2.2. Contrato de venda / aluguel online

  O uso comercial só é autorizado após:

  1. contato com o Licenciante e aceite da proposta;
  2. assinatura eletrônica do contrato de licença comercial (venda de licença
     perpétua com manutenção, ou aluguel/assinatura mensal), em plataforma
     online indicada pelo Licenciante;
  3. confirmação do primeiro pagamento da taxa mensal (ou do valor à vista
     previsto no contrato).

  Sem o contrato assinado e o pagamento em dia, o uso comercial não é licenciado
  e constitui violação destes termos.

--------------------------------------------------------------------------------
3. RESTRIÇÕES GERAIS
--------------------------------------------------------------------------------

Salvo autorização escrita do Licenciante ou o contrato comercial vigente:

  a) não remover créditos de autoria (AUTORIA.md, menções a MARK LVI / Guilherme);
  b) não apresentar o Software como criação de terceiros;
  c) não usar marcas, nomes ou identidade visual do MARK LVI de forma a sugerir
     endosso oficial sem permissão;
  d) respeitar leis aplicáveis (privacidade, gravação de áudio, automação de
     sistemas de terceiros, etc.).

--------------------------------------------------------------------------------
4. SEM GARANTIA
--------------------------------------------------------------------------------

O SOFTWARE É FORNECIDO “COMO ESTÁ”, SEM GARANTIAS DE QUALQUER TIPO, EXPRESSAS OU
IMPLÍCITAS, INCLUINDO COMERCIALIZAÇÃO, ADEQUAÇÃO A UM FIM ESPECÍFICO E
NÃO VIOLAÇÃO. O LICENCIANTE NÃO SE RESPONSABILIZA POR DANOS DIRETOS, INDIRETOS,
INCIDENTAIS OU CONSEQUENCIAIS DECORRENTES DO USO OU DA IMPOSSIBILIDADE DE USO DO
SOFTWARE, NA MÁXIMA EXTENSÃO PERMITIDA PELA LEI.

--------------------------------------------------------------------------------
5. CONTATO PARA LICENÇA COMERCIAL
--------------------------------------------------------------------------------

Para solicitar contrato de venda/aluguel online e uso comercial:

  - Consulte AUTORIA.md para a identidade do autor.
  - Abra uma solicitação no repositório oficial do projeto ou pelo canal de
    contato indicado pelo Licenciante.

--------------------------------------------------------------------------------
6. DISPOSIÇÕES FINAIS
--------------------------------------------------------------------------------

  - A falha do Licenciante em exercer um direito não constitui renúncia.
  - Se alguma cláusula for inválida, as demais permanecem em vigor.
  - Lei aplicável e foro: legislação brasileira; foro da comarca do domicílio
    do Licenciante, salvo disposição em contrário no contrato comercial.

Copyright (c) 2026 Guilherme. Todos os direitos reservados, exceto as permissões
expressamente concedidas neste documento.
