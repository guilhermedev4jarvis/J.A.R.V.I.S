"""
Local LLM client for MARK XL.

Supports two backends — selected via  "llm_provider"  in config/api_keys.json:

  "llm_provider": "ollama"   (default)
        Uses Ollama's native /api/chat endpoint.
        Download: https://ollama.com
        Default port: 11434

  "llm_provider": "openai"
        Uses any OpenAI-compatible server: LM Studio, Jan, LocalAI,
        llama.cpp server, vLLM, etc.
        LM Studio download: https://lmstudio.ai   (default port: 1234)
        Set  "llm_url": "http://localhost:1234"  in config.
        Note: tool-calling support depends on the model; use a model that
        supports function/tool calls (e.g. Qwen2.5, Llama-3.1, Mistral).

Latency notes (what actually moves the needle)
─────────────────────────────────────────────
* Streaming (`call_llm_stream`) yields complete sentences as soon as they
  arrive so TTS can start speaking the first sentence while the model is still
  generating the rest. Prefer this path for any voice reply.
* `warmup_model()` primes Ollama's KV prefix cache with the static system
  prompt — first-token latency drops from ~17 s to <1 s on typical machines.
* A small in-memory response cache answers repeated short, deterministic
  queries (time, simple facts) without another round-trip to the model.
"""
import hashlib
import json
import re
import subprocess
import sys
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import Callable, Generator, Optional

import requests

# Matches a sentence boundary: [.!?] followed by whitespace, or a blank line.
# Avoids splitting on decimals (3.5) because those have no space after the dot.
# Also treats ; and : as soft boundaries when followed by a capital letter so
# the first spoken sentence arrives earlier on long replies.
_SENT_END = re.compile(
    r'(?<=[.!?])\s+|(?<=\n)\s*\n|(?<=[;:])\s+(?=[A-ZÀ-Ý"\'«])'
)

# ── Two-tier response cache (memory + SQLite) ────────────────────────────────
# Short, deterministic answers (clock, simple conversions, stock phrases) are
# repeated constantly in a voice session. Hitting the model again for them
# costs 200–800 ms of first-token latency for zero value.
#
# Tier 1: process-local LRU (fast, ~µs).
# Tier 2: SQLite under cache/llm_response_cache.db so answers survive restarts
#         (common morning queries, unit conversions, stock phrases).
_CACHE_MAX = 64
_CACHE_TTL_S = 300.0          # 5 minutes in-memory
_CACHE_DB_TTL_S = 86_400.0    # 24 hours on disk
_cache: "OrderedDict[str, tuple[float, str]]" = OrderedDict()
_cache_lock = threading.Lock()
_db_lock = threading.Lock()
_db_path: Optional[Path] = None
_db_ready = False


def _cache_key(prompt: str, system: str | None, model: str | None) -> str:
    raw = f"{model or ''}|{system or ''}|{prompt.strip().lower()}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def _db_file() -> Path:
    global _db_path
    if _db_path is None:
        # get_base_dir is defined later in this module; resolve relative to
        # this file so the cache works even during early import.
        base = Path(__file__).resolve().parent.parent
        _db_path = base / "cache" / "llm_response_cache.db"
    return _db_path


def _ensure_db() -> bool:
    """Open/create the SQLite cache. Never raises into callers."""
    global _db_ready
    if _db_ready:
        return True
    try:
        import sqlite3
        path = _db_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        with _db_lock:
            con = sqlite3.connect(str(path), timeout=2.0)
            try:
                con.execute(
                    "CREATE TABLE IF NOT EXISTS responses ("
                    "  key TEXT PRIMARY KEY,"
                    "  value TEXT NOT NULL,"
                    "  created REAL NOT NULL"
                    ")"
                )
                con.execute(
                    "CREATE INDEX IF NOT EXISTS idx_responses_created "
                    "ON responses(created)"
                )
                # Drop entries older than DB TTL on open
                cutoff = time.time() - _CACHE_DB_TTL_S
                con.execute("DELETE FROM responses WHERE created < ?", (cutoff,))
                con.commit()
            finally:
                con.close()
        _db_ready = True
        return True
    except Exception as e:
        print(f"[LLM] response cache DB unavailable: {e}")
        return False


def _db_get(key: str) -> Optional[str]:
    if not _ensure_db():
        return None
    try:
        import sqlite3
        with _db_lock:
            con = sqlite3.connect(str(_db_file()), timeout=1.0)
            try:
                row = con.execute(
                    "SELECT value, created FROM responses WHERE key = ?",
                    (key,),
                ).fetchone()
                if not row:
                    return None
                value, created = row
                if time.time() - float(created) > _CACHE_DB_TTL_S:
                    con.execute("DELETE FROM responses WHERE key = ?", (key,))
                    con.commit()
                    return None
                return str(value)
            finally:
                con.close()
    except Exception:
        return None


def _db_put(key: str, value: str) -> None:
    if not _ensure_db():
        return
    try:
        import sqlite3
        with _db_lock:
            con = sqlite3.connect(str(_db_file()), timeout=1.0)
            try:
                con.execute(
                    "INSERT OR REPLACE INTO responses(key, value, created) "
                    "VALUES (?, ?, ?)",
                    (key, value, time.time()),
                )
                # Keep the table bounded
                con.execute(
                    "DELETE FROM responses WHERE key NOT IN ("
                    "  SELECT key FROM responses ORDER BY created DESC LIMIT 500"
                    ")"
                )
                con.commit()
            finally:
                con.close()
    except Exception:
        pass


def cache_get(prompt: str, system: str | None = None, model: str | None = None) -> Optional[str]:
    """Return a cached answer if still fresh (memory first, then SQLite)."""
    key = _cache_key(prompt, system, model)
    with _cache_lock:
        hit = _cache.get(key)
        if hit is not None:
            ts, value = hit
            if time.monotonic() - ts <= _CACHE_TTL_S:
                _cache.move_to_end(key)
                return value
            _cache.pop(key, None)

    # Disk tier
    value = _db_get(key)
    if value is not None:
        with _cache_lock:
            _cache[key] = (time.monotonic(), value)
            _cache.move_to_end(key)
            while len(_cache) > _CACHE_MAX:
                _cache.popitem(last=False)
        return value
    return None


def cache_put(prompt: str, value: str, system: str | None = None, model: str | None = None) -> None:
    """Store a short answer in memory + SQLite. Ignores long replies."""
    if not value or len(value) > 400:
        return
    key = _cache_key(prompt, system, model)
    with _cache_lock:
        _cache[key] = (time.monotonic(), value)
        _cache.move_to_end(key)
        while len(_cache) > _CACHE_MAX:
            _cache.popitem(last=False)
    _db_put(key, value)


def cache_clear() -> None:
    """Clear both memory and SQLite tiers."""
    with _cache_lock:
        _cache.clear()
    if not _ensure_db():
        return
    try:
        import sqlite3
        with _db_lock:
            con = sqlite3.connect(str(_db_file()), timeout=1.0)
            try:
                con.execute("DELETE FROM responses")
                con.commit()
            finally:
                con.close()
    except Exception:
        pass

def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR    = get_base_dir()
CONFIG_PATH = BASE_DIR / "config" / "api_keys.json"

_DEFAULTS = {
    "llm_url":      "http://localhost:11434",
    # Qwen2.5 7B — strong multilingual + tool-calling. Pull once:
    #   ollama pull qwen2.5:7b
    "llm_model":    "qwen2.5:7b",
    "llm_provider": "ollama",   # "ollama" | "openai"
}

# Messy names people type in the UI / config → real Ollama tag.
_MODEL_ALIASES = {
    "qwen 2.5 2:7b": "qwen2.5:7b",
    "qwen 2.5:7b": "qwen2.5:7b",
    "qwen2.5 7b": "qwen2.5:7b",
    "qwen2.5-7b": "qwen2.5:7b",
    "qwen 2.5 7b": "qwen2.5:7b",
    "qwen2.5 7b-instruct": "qwen2.5:7b",
    "qwen2.5:7b-instruct": "qwen2.5:7b",
    "qwen2.5-7b-instruct": "qwen2.5:7b",
    "qwen2.5:7b": "qwen2.5:7b",
    "llama3.2": "llama3.2",
    "llama 3.2": "llama3.2",
}


def normalize_model_name(name: str | None) -> str:
    """Return a clean Ollama/OpenAI model id from user/config input."""
    if not name:
        return _DEFAULTS["llm_model"]
    raw = str(name).strip()
    key = raw.lower().replace("_", " ").strip()
    while "  " in key:
        key = key.replace("  ", " ")
    if key in _MODEL_ALIASES:
        return _MODEL_ALIASES[key]
    # "qwen 2.5:7b" → strip spaces around punctuation / between tokens
    cleaned = key.replace(" :", ":").replace(": ", ":").replace(" ", "")
    if cleaned in _MODEL_ALIASES:
        return _MODEL_ALIASES[cleaned]
    if cleaned:
        return cleaned
    return raw


def get_llm_provider() -> str:
    """Returns 'ollama' or 'openai' (covers LM Studio, LocalAI, Jan, etc.)."""
    raw = _load_config().get("llm_provider", "ollama").strip().lower()
    return "openai" if raw in ("openai", "lmstudio", "localai", "jan", "llamacpp") else "ollama"


def _load_config() -> dict:
    try:
        from core.secrets import apply_env_secrets, read_json_config
        return apply_env_secrets(read_json_config())
    except Exception:
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}


def ensure_ollama_running(timeout: int = 15) -> bool:
    """
    For Ollama: ping /api/tags; auto-launch 'ollama serve' if not running.
    For OpenAI-compatible providers: just ping /v1/models (server must be started manually).
    Returns True if the LLM server is reachable.
    """
    url, _   = get_llm_settings()
    provider = get_llm_provider()

    if provider == "openai":
        # OpenAI-compatible servers (LM Studio, LocalAI, etc.) must be started
        # by the user — we just check if they're reachable.
        health = f"{url}/v1/models"
        try:
            ok = requests.get(health, timeout=5).status_code == 200
            if ok:
                print(f"[LLM] OpenAI-compatible server reachable at {url}")
            else:
                print(f"[LLM] Server at {url} returned non-200.  Is it running?")
            return ok
        except Exception as e:
            print(
                f"[LLM] Cannot reach OpenAI-compatible server at {url}.\n"
                "      Make sure LM Studio / LocalAI / Jan is running and the server is started."
            )
            return False

    # ── Ollama ──────────────────────────────────────────────────────────────
    health = f"{url}/api/tags"

    def _is_up() -> bool:
        try:
            return requests.get(health, timeout=3).status_code == 200
        except Exception:
            return False

    if _is_up():
        return True

    print("[LLM] Ollama not running — launching 'ollama serve'…")
    try:
        kwargs: dict = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if sys.platform == "win32":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        subprocess.Popen(["ollama", "serve"], **kwargs)
    except FileNotFoundError:
        print("[LLM] 'ollama' command not found. Install Ollama from https://ollama.com")
        return False
    except Exception as e:
        print(f"[LLM] Could not launch Ollama: {e}")
        return False

    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(1.0)
        if _is_up():
            print("[LLM] Ollama started successfully.")
            return True

    print("[LLM] Ollama did not respond within the timeout.")
    return False


def warmup_model(system_prompt: str | None = None) -> bool:
    """
    Pre-load the model AND prime Ollama's KV prefix cache.

    Why the system_prompt matters
    ─────────────────────────────
    Ollama caches the KV attention state of the prompt prefix across requests.
    If warmup includes the same system prompt that real requests will use, Ollama
    evaluates those tokens ONCE at startup.  Every subsequent request only needs
    to evaluate the small delta (user message ± time context) instead of the full
    300-500 token system prompt → drops first-token latency from ~17 s to <1 s.

    Pass the *static* part of the system prompt (the JARVIS protocol text, without
    timestamps or per-minute context) so the prefix stays valid across calls.
    """
    url, model = get_llm_settings()
    provider   = get_llm_provider()
    print(f"[LLM] Warming up '{model}' ({provider})…")

    messages: list[dict] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": "hi"})

    if provider == "openai":
        # OpenAI-compatible: just fire a minimal request to ensure the model is loaded.
        # No keep_alive or KV-cache priming available — server manages this internally.
        payload = {
            "model":      model,
            "messages":   messages,
            "stream":     False,
            "max_tokens": 1,
        }
        try:
            resp = requests.post(f"{url}/v1/chat/completions", json=payload, timeout=180)
            resp.raise_for_status()
            print(f"[LLM] '{model}' ready (OpenAI-compatible server).")
            return True
        except Exception as e:
            print(f"[LLM] Warmup failed (non-fatal): {e}")
            return False

    # ── Ollama ──────────────────────────────────────────────────────────────
    payload = {
        "model":      model,
        "messages":   messages,
        "stream":     False,
        "keep_alive": -1,
        # num_gpu:99 → push ALL transformer layers to GPU (Ollama caps at available)
        # This is safe even without a GPU — Ollama silently ignores if n_gpu_layers=0
        "options":    {"num_predict": 1, "num_gpu": 99},
    }
    try:
        resp = requests.post(f"{url}/api/chat", json=payload, timeout=180)
        resp.raise_for_status()
        print(f"[LLM] '{model}' loaded and KV cache primed.")
        return True
    except Exception as e:
        print(f"[LLM] Warmup failed (non-fatal): {e}")
        return False


def check_model_available(log: Callable | None = None) -> bool:
    """
    Returns True if the configured model is already pulled in Ollama.
    Logs an actionable warning (to console + optional UI callback) if not.
    Always returns True for non-Ollama providers (cannot inspect their model list).
    """
    if get_llm_provider() != "ollama":
        return True

    url, model = get_llm_settings()
    try:
        resp = requests.get(f"{url}/api/tags", timeout=5)
        resp.raise_for_status()
        pulled = [m.get("name", "") for m in resp.json().get("models", [])]
        model_base = model.split(":")[0]
        found = any(
            m == model or m == model_base or m.startswith(model_base + ":")
            for m in pulled
        )
        if not found:
            available = ", ".join(pulled) if pulled else "none"
            warn = (
                f"WRN: Model '{model}' is not pulled in Ollama.\n"
                f"     Available: {available}\n"
                f"     Fix: ollama pull {model}"
            )
            print(warn)
            if log:
                log(f"WRN: '{model}' not found — run: ollama pull {model}")
        return found
    except Exception:
        return True   # Ollama might still be starting up; non-blocking


def get_llm_settings() -> tuple[str, str]:
    """Returns (base_url, model_name). Model names are normalised so typos like
    'qwen 2.5 2:7b' become the real Ollama tag 'qwen2.5:7b'."""
    cfg   = _load_config()
    url   = cfg.get("llm_url",   _DEFAULTS["llm_url"]).rstrip("/")
    model = normalize_model_name(cfg.get("llm_model", _DEFAULTS["llm_model"]))
    return url, model


# Aliases used by prepare_offline.py (offline local-engine path).
def get_offline_ollama_settings() -> tuple[str, str]:
    """Same as get_llm_settings — kept for prepare_offline.py."""
    return get_llm_settings()


def ensure_offline_ollama_running(timeout: int = 15) -> bool:
    """Ensure Ollama is reachable for offline prep. Alias of ensure_ollama_running."""
    return ensure_ollama_running(timeout=timeout)


def offline_model_available() -> bool:
    """True if the configured Ollama model is already pulled."""
    return check_model_available()


def call_llm(
    messages: list,
    tools:    list | None = None,
    timeout:  int = 120,
) -> dict:
    """
    Non-streaming chat request.  Routes to Ollama or OpenAI-compatible backend.

    Returns:
        {"content": str, "tool_calls": list}
    """
    url, model = get_llm_settings()
    provider   = get_llm_provider()

    if provider == "openai":
        endpoint = f"{url}/v1/chat/completions"
        payload: dict = {
            "model":      model,
            "messages":   messages,
            "stream":     False,
            "max_tokens": 150,
        }
        if tools:
            payload["tools"]       = tools
            payload["tool_choice"] = "auto"
        try:
            resp = requests.post(endpoint, json=payload, timeout=timeout)
            resp.raise_for_status()
            choice = resp.json().get("choices", [{}])[0]
            msg    = choice.get("message", {})
            # OpenAI tool_calls format → normalise to Ollama-style
            raw_tc  = msg.get("tool_calls") or []
            tc_list = [
                {
                    "id":       t.get("id", ""),
                    "function": {
                        "name":      t["function"]["name"],
                        "arguments": (
                            json.loads(t["function"]["arguments"])
                            if isinstance(t["function"].get("arguments"), str)
                            else t["function"].get("arguments", {})
                        ),
                    },
                }
                for t in raw_tc
            ]
            return {
                "content":    (msg.get("content") or "").strip(),
                "tool_calls": tc_list,
            }
        except Exception as e:
            raise RuntimeError(f"OpenAI-compatible LLM call failed: {e}")

    # ── Ollama ──────────────────────────────────────────────────────────────
    endpoint = f"{url}/api/chat"
    payload = {
        "model":      model,
        "messages":   messages,
        "stream":     False,
        "keep_alive": -1,
        "options":    {"num_predict": 150, "num_gpu": 99},
    }
    if tools:
        payload["tools"] = tools

    try:
        resp = requests.post(endpoint, json=payload, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        msg  = data.get("message", {})
        return {
            "content":    (msg.get("content") or "").strip(),
            "tool_calls": msg.get("tool_calls") or [],
        }
    except requests.exceptions.ConnectionError as e:
        print(f"[LLM] ConnectionError — trying to restart Ollama… ({e})")
        if ensure_ollama_running():
            try:
                resp = requests.post(endpoint, json=payload, timeout=timeout)
                resp.raise_for_status()
                data = resp.json()
                msg  = data.get("message", {})
                return {
                    "content":    (msg.get("content") or "").strip(),
                    "tool_calls": msg.get("tool_calls") or [],
                }
            except Exception:
                pass
        raise RuntimeError(
            f"Cannot connect to Ollama at {url}. "
            "Make sure Ollama is installed and run: ollama serve"
        )
    except requests.exceptions.Timeout:
        raise RuntimeError("Ollama request timed out after 120 s.")
    except requests.exceptions.HTTPError as e:
        print(f"[LLM] HTTPError: {e.response.status_code} — {e.response.text[:200]}")
        raise RuntimeError(f"Ollama HTTP error: {e.response.status_code}")
    except Exception as e:
        print(f"[LLM] Unexpected error: {type(e).__name__}: {e}")
        raise RuntimeError(f"LLM call failed: {e}")


def call_llm_text(
    prompt:  str,
    system:  str | None = None,
    model:   str | None = None,
    timeout: int = 120,
    use_cache: bool = True,
) -> str:
    """
    Simple text-only generation (no tools).
    Used by planner, executor, error_handler, code_helper, dev_agent.

    Short, repeated prompts hit an in-process LRU cache (TTL ~2 min) so common
    voice queries ("what time is it?", unit conversions, stock phrases) avoid
    another model round-trip.
    """
    url, default_model = get_llm_settings()
    m = model or default_model

    if use_cache:
        cached = cache_get(prompt, system, m)
        if cached is not None:
            return cached

    messages: list[dict] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    provider = get_llm_provider()
    try:
        if provider == "openai":
            endpoint = f"{url}/v1/chat/completions"
            payload = {
                "model": m,
                "messages": messages,
                "stream": False,
                "max_tokens": 600,
            }
            resp = requests.post(endpoint, json=payload, timeout=timeout)
            resp.raise_for_status()
            text = (resp.json().get("choices", [{}])[0]
                    .get("message", {}).get("content") or "").strip()
        else:
            endpoint = f"{url}/api/chat"
            payload = {
                "model": m,
                "messages": messages,
                "stream": False,
                "keep_alive": -1,
                "options": {"num_predict": 600, "num_gpu": 99},
            }
            resp = requests.post(endpoint, json=payload, timeout=timeout)
            resp.raise_for_status()
            text = (resp.json().get("message", {}).get("content") or "").strip()

        if use_cache and text:
            cache_put(prompt, text, system, m)
        return text
    except requests.exceptions.ConnectionError:
        if provider != "openai" and ensure_ollama_running():
            try:
                resp = requests.post(endpoint, json=payload, timeout=timeout)
                resp.raise_for_status()
                text = (resp.json().get("message", {}).get("content") or "").strip()
                if use_cache and text:
                    cache_put(prompt, text, system, m)
                return text
            except Exception:
                pass
        raise RuntimeError(
            f"Cannot connect to LLM at {url}. "
            "Make sure Ollama / LM Studio is running."
        )
    except Exception as e:
        raise RuntimeError(f"LLM text call failed: {e}")


def _stream_openai(
    messages: list,
    tools:    list | None,
    timeout:  int,
) -> Generator[dict, None, None]:
    """
    Streaming backend for OpenAI-compatible servers (LM Studio, LocalAI, Jan…).

    Parses Server-Sent Events (SSE) and accumulates streaming tool-call fragments
    so the output format is identical to the Ollama backend.
    """
    url, model = get_llm_settings()
    endpoint   = f"{url}/v1/chat/completions"

    payload: dict = {
        "model":      model,
        "messages":   messages,
        "stream":     True,
        # Match Ollama path: short budget for pure chat, roomier when tools exist.
        "max_tokens": 220 if tools else 120,
    }
    if tools:
        payload["tools"]       = tools
        payload["tool_choice"] = "auto"

    try:
        with requests.post(endpoint, json=payload, timeout=timeout, stream=True) as resp:
            resp.raise_for_status()
            full_content = ""
            buf          = ""
            # tool_call fragments: index → {"id", "function": {"name", "arguments"}}
            tc_fragments: dict[int, dict] = {}

            for raw in resp.iter_lines():
                if not raw:
                    continue
                # SSE lines look like: b"data: {...}" or b"data: [DONE]"
                line = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue

                choice = chunk.get("choices", [{}])[0]
                delta  = choice.get("delta", {})
                text   = delta.get("content") or ""

                full_content += text
                buf          += text

                # Accumulate sentence boundaries for streaming TTS
                while True:
                    m = _SENT_END.search(buf)
                    if not m:
                        break
                    sentence = buf[: m.start() + 1].strip()
                    buf      = buf[m.end():]
                    if sentence:
                        yield {"type": "sentence", "text": sentence}

                # Accumulate streaming tool-call fragments
                for tc in (delta.get("tool_calls") or []):
                    idx = tc.get("index", 0)
                    if idx not in tc_fragments:
                        tc_fragments[idx] = {"id": "", "function": {"name": "", "arguments": ""}}
                    frag = tc_fragments[idx]
                    frag["id"] = frag["id"] or tc.get("id", "")
                    fn = tc.get("function", {})
                    frag["function"]["name"]      += fn.get("name") or ""
                    frag["function"]["arguments"] += fn.get("arguments") or ""

                finish = choice.get("finish_reason")
                if finish in ("stop", "tool_calls", "length"):
                    break

            # Flush any trailing content
            if buf.strip():
                yield {"type": "sentence", "text": buf.strip()}

            # Parse accumulated tool-call argument strings → dicts
            tool_calls: list = []
            for idx in sorted(tc_fragments):
                frag = tc_fragments[idx]
                args = frag["function"]["arguments"]
                try:
                    args = json.loads(args)
                except Exception:
                    pass   # leave as raw string; _execute_tool handles it
                tool_calls.append({
                    "id":       frag["id"],
                    "function": {"name": frag["function"]["name"], "arguments": args},
                })

            yield {
                "type":       "done",
                "content":    full_content.strip(),
                "tool_calls": tool_calls,
            }

    except requests.exceptions.ConnectionError:
        raise RuntimeError(
            f"Cannot reach OpenAI-compatible server at {url}.\n"
            "Make sure LM Studio / LocalAI / Jan is running and the server is started."
        )
    except requests.exceptions.Timeout:
        raise RuntimeError("OpenAI-compatible stream timed out.")
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"OpenAI-compatible HTTP error: {e.response.status_code}")
    except Exception as e:
        raise RuntimeError(f"OpenAI-compatible stream failed: {e}")


def call_llm_stream(
    messages: list,
    tools:    list | None = None,
    timeout:  int = 120,
) -> Generator[dict, None, None]:
    """
    Streaming chat request.  Routes to Ollama or OpenAI-compatible backend.

    Yields:
        {"type": "sentence", "text": str}   — each complete sentence as it arrives
        {"type": "done", "content": str, "tool_calls": list}  — when stream ends

    Sentences are split on [.!?] + whitespace so TTS can start immediately.
    Tool calls always appear in the final "done" event.
    """
    provider = get_llm_provider()
    if provider == "openai":
        yield from _stream_openai(messages, tools, timeout)
        return

    url, model = get_llm_settings()
    endpoint   = f"{url}/api/chat"

    # Voice replies should be short. Tools sometimes need a longer reasoning
    # trail, so the budget expands only when tool declarations are present.
    # Lower num_predict → earlier stop → lower time-to-last-token on chat.
    num_predict = 220 if tools else 120
    payload: dict = {
        "model":      model,
        "messages":   messages,
        "stream":     True,
        "keep_alive": -1,
        # num_gpu:99 pushes all layers to GPU; Ollama auto-tunes threads.
        "options":    {"num_predict": num_predict, "num_gpu": 99},
    }
    if tools:
        payload["tools"] = tools

    def _do_stream() -> Generator[dict, None, None]:
        with requests.post(endpoint, json=payload, timeout=timeout, stream=True) as resp:
            resp.raise_for_status()
            full_content = ""
            tool_calls:  list = []
            buf          = ""

            for raw in resp.iter_lines():
                if not raw:
                    continue
                try:
                    chunk = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                msg   = chunk.get("message", {})
                delta = msg.get("content") or ""

                full_content += delta
                buf          += delta

                # Yield complete sentences as they accumulate
                while True:
                    m = _SENT_END.search(buf)
                    if not m:
                        break
                    sentence = buf[: m.start() + 1].strip()
                    buf      = buf[m.end() :]
                    if sentence:
                        yield {"type": "sentence", "text": sentence}

                tc = msg.get("tool_calls")
                if tc:
                    tool_calls.extend(tc)

                if chunk.get("done"):
                    if buf.strip():
                        yield {"type": "sentence", "text": buf.strip()}

                    yield {
                        "type":       "done",
                        "content":    full_content.strip(),
                        "tool_calls": tool_calls,
                    }
                    return

    try:
        yield from _do_stream()
    except requests.exceptions.ConnectionError as e:
        print(f"[LLM] Stream ConnectionError — trying to restart Ollama… ({e})")
        if ensure_ollama_running():
            yield from _do_stream()
            return
        raise RuntimeError(
            f"Cannot connect to Ollama at {url}. "
            "Make sure Ollama is installed and run: ollama serve"
        )
    except requests.exceptions.Timeout:
        raise RuntimeError("Ollama stream timed out.")
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(f"Ollama HTTP error: {e.response.status_code}")
    except Exception as e:
        print(f"[LLM] Stream error: {type(e).__name__}: {e}")
        raise RuntimeError(f"LLM stream failed: {e}")
