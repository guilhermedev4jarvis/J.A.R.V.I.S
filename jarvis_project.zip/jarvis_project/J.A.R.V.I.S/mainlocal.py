#!/usr/bin/env python3
"""
mainlocal.py — J.A.R.V.I.S. MARK LXI (61) exclusive offline / air-gapped entrypoint.

Forces pipeline mode (Ollama + Whisper + Piper/system), blocks cloud tools and
cloud provider modules, keeps biometrics + owner_gate + localhost dashboard.

Run:
    python mainlocal.py
"""
from __future__ import annotations

import os
import socket
import sys
import traceback
from pathlib import Path
from typing import Iterable

# ── 0. Force offline BEFORE any project imports that might touch the network ─
os.environ["OFFLINE_MODE"] = "1"
os.environ["AIRGAPPED"] = "1"
os.environ["JARVIS_FORCE_LOCAL"] = "1"
os.environ["JARVIS_PROVIDER_MODE"] = "pipeline"
# Ignore cloud keys even if present on disk
for _k in (
    "MARK_GEMINI_API_KEY",
    "GEMINI_API_KEY",
    "GOOGLE_API_KEY",
    "OPENAI_API_KEY",
    "ELEVEN_API_KEY",
    "ELEVENLABS_API_KEY",
):
    os.environ.pop(_k, None)
    os.environ[_k] = ""

BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

LOG_PREFIX = "[MARK-LXI-LOCAL]"

# Default local stack
DEFAULT_OLLAMA_HOST = "127.0.0.1"
DEFAULT_OLLAMA_PORT = 11434
DEFAULT_MODEL = "qwen2.5-coder:7b"

# Tools that require external network / cloud APIs — excluded from discovery.
BLOCKED_ACTIONS: frozenset[str] = frozenset({
    "web_search",
    "deep_research",
    "noticias_brasil",
    "cotacao_dolar",
    "flight_finder",
    "youtube_video",
    "resumo_link",
    "baixar_arquivo",
    "whatsapp_web",
    "send_message",
    "email_triage",
    "webhook_bridge",
    "ai_collaboration",
    "screen_context_advisor",  # Gemini vision
})

# Explicit allowlist (offline-capable). Anything not listed and not blocked still
# loads only if it is a normal local tool; cloud names above are hard-denied.
ALLOWED_ACTIONS: frozenset[str] = frozenset({
    "desktop_control", "desktop_agent", "window_manager", "window_workspace_saver",
    "open_app", "process_manager", "file_manager", "file_organize", "clipboard_smart",
    "quick_note", "reminder", "focus_timer", "screenshot_ocr", "screen_memory_timeline",
    "screen_processor", "local_doc_rag", "meeting_transcriber", "meeting_brief",
    "app_audio_mixer", "audio_latency_tuner", "power_profile_manager", "computer_settings",
    "battery", "system_health", "system_resources_monitor", "hwmonitor_integration",
    "resource_governor", "dependency_health", "memory_compactor", "action_analytics",
    "hot_reload", "mission_planner", "routine_orchestrator", "context_triggers",
    "intruder_alert", "secure_vault_helper", "powershell_tool", "powershell_generator",
    "code_studio", "code_review_local", "self_program", "blender_assist", "godot_assist",
    "roblox_assist", "treinador", "treino_hoje", "modo_treinador", "biometrics",
    "owner_setup", "agent_mode_control", "video_player", "media_control", "unit_convert",
    "git_voice_copilot",  # local ops only; push is gated inside the tool + we warn
    "proactive", "browser_control",  # may degrade offline
    "computer_control", "system_monitor", "weather_report",  # weather may fail offline
})


def log(msg: str) -> None:
    print(f"{LOG_PREFIX} {msg}", flush=True)


def _tcp_open(host: str, port: int, timeout: float = 1.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def healthcheck_local_stack() -> dict:
    """Non-blocking diagnostics for Ollama / optional STT-TTS deps."""
    report: dict = {
        "ollama": False,
        "model_hint": DEFAULT_MODEL,
        "stt_whisper": False,
        "tts_piper": False,
        "tts_system": True,
    }
    report["ollama"] = _tcp_open(DEFAULT_OLLAMA_HOST, DEFAULT_OLLAMA_PORT)
    if report["ollama"]:
        try:
            import urllib.request
            url = f"http://{DEFAULT_OLLAMA_HOST}:{DEFAULT_OLLAMA_PORT}/api/tags"
            with urllib.request.urlopen(url, timeout=2.0) as resp:
                body = resp.read().decode("utf-8", errors="replace")
            report["ollama_tags"] = DEFAULT_MODEL in body
        except Exception as e:
            report["ollama_tags_error"] = str(e)[:120]
    try:
        import importlib.util
        report["stt_whisper"] = importlib.util.find_spec("faster_whisper") is not None
        report["tts_piper"] = importlib.util.find_spec("piper") is not None
    except Exception:
        pass
    return report


def print_health(report: dict) -> None:
    if report.get("ollama"):
        log(f"Ollama OK em {DEFAULT_OLLAMA_HOST}:{DEFAULT_OLLAMA_PORT}")
        if report.get("ollama_tags") is False:
            log(f"Aviso: modelo '{DEFAULT_MODEL}' pode não estar baixado — "
                f"rode: ollama pull {DEFAULT_MODEL}")
        elif report.get("ollama_tags"):
            log(f"Modelo local detectado: {DEFAULT_MODEL}")
    else:
        log("AVISO: Ollama não respondeu em 127.0.0.1:11434 — "
            "instale/inicie o Ollama para o LLM local.")
    if not report.get("stt_whisper"):
        log("AVISO: faster-whisper não instalado — STT local pode falhar "
            "(pip install faster-whisper).")
    else:
        log("STT local (faster-whisper) disponível.")
    if report.get("tts_piper"):
        log("TTS Piper disponível.")
    else:
        log("TTS Piper ausente — fallback para tts_system (voz do SO).")


def force_pipeline_config() -> None:
    """Persist runtime preference: pipeline + Ollama + Whisper + Piper/system."""
    try:
        from memory import config_manager as cm
        cm.save_provider_mode(cm.PROVIDER_MODE_PIPELINE)
        # llm_openai provider id is typically "openai" — configure Ollama base URL
        try:
            from providers import registry
            # discover llm ids
            decls = registry.discover("llm") or []
            llm_id = "openai"
            for d in decls:
                if d and d.get("id"):
                    llm_id = d["id"]
                    break
            cm.save_provider_config(llm_id, {
                "base_url": f"http://{DEFAULT_OLLAMA_HOST}:{DEFAULT_OLLAMA_PORT}/v1",
                "model": DEFAULT_MODEL,
                "api_key": "ollama",  # local dummy; never sent as real cloud key
            })
            pipe = {"llm": llm_id, "stt": "whisper", "tts": "piper"}
            # If piper missing, prefer system
            import importlib.util
            if importlib.util.find_spec("piper") is None:
                pipe["tts"] = "system"
            cm.save_pipeline(**pipe)
            cm.save_provider_config("whisper", {"backend": "local", "model": "base"})
            log(f"Pipeline forçado: llm={pipe['llm']} stt={pipe['stt']} tts={pipe['tts']}")
        except Exception as e:
            log(f"Config de providers parcial: {e}")
            try:
                cm.save_provider_mode("pipeline")
            except Exception:
                pass
    except Exception as e:
        log(f"Não foi possível gravar config_manager ({e}) — seguindo com env.")


def install_action_filter() -> None:
    """Wrap core.action_loader.discover_actions to drop cloud tools."""
    import core.action_loader as al

    original = al.discover_actions

    def filtered_discover(actions_dir, reserved_names=None, logger=print):
        registry = original(actions_dir, reserved_names=reserved_names, logger=logger)
        removed = []
        # ActionRegistry stores actions in .actions dict (or _actions)
        bag = getattr(registry, "_actions", None)
        if isinstance(bag, dict):
            for name in list(bag.keys()):
                if name in BLOCKED_ACTIONS:
                    removed.append(name)
                    bag.pop(name, None)
            if removed:
                msg = f"{LOG_PREFIX} tools bloqueadas (cloud): {', '.join(sorted(removed))}"
                try:
                    logger(msg)
                except Exception:
                    log(msg)
        return registry

    al.discover_actions = filtered_discover  # type: ignore[assignment]
    log("Filtro de actions offline instalado.")


def harden_git_voice_local() -> None:
    """Discourage/block git push in offline entry (network)."""
    try:
        import actions._git_voice_copilot_impl as git_impl
        _orig = git_impl.run

        def _run(parameters=None, player=None, **ctx):
            p = dict(parameters or {})
            action = str(p.get("action") or "").strip().lower()
            if action in ("push",):
                from core.outcome import failed
                return failed(
                    "git_voice_copilot",
                    "push bloqueado em mainlocal.py (modo air-gapped). "
                    "Use status_summary, diff_explain, smart_commit ou create_branch.",
                )
            return _orig(parameters, player=player, **ctx)

        git_impl.run = _run  # type: ignore[assignment]
        log("git_voice_copilot: push remoto desabilitado neste entrypoint.")
    except Exception as e:
        log(f"git_voice_copilot patch opcional: {e}")


def block_cloud_imports() -> None:
    """Mark cloud modules as intentionally unused in this process."""
    # Soft: do not import gemini / elevenlabs / openai realtime at startup.
    sys.modules.setdefault("jarvis_local_block_gemini", type(sys)("jarvis_local_block_gemini"))
    log("Modo air-gapped: não inicializar Gemini / OpenAI Realtime / ElevenLabs.")


def bind_dashboard_localhost() -> None:
    """Prefer dashboard bind on 127.0.0.1 only."""
    os.environ.setdefault("JARVIS_DASHBOARD_HOST", "127.0.0.1")
    try:
        import dashboard.server as ds
        if hasattr(ds, "HOST"):
            ds.HOST = "127.0.0.1"  # type: ignore[attr-defined]
        if hasattr(ds, "PORT"):
            pass
        log("Dashboard preferencialmente em 127.0.0.1")
    except Exception as e:
        log(f"Dashboard ainda não importado ({e})")


def main() -> int:
    log("J.A.R.V.I.S. — MARK LXI (61) · entrypoint LOCAL / AIR-GAPPED")
    log("Cloud APIs desativadas (Gemini / OpenAI / ElevenLabs / web tools).")

    report = healthcheck_local_stack()
    print_health(report)

    block_cloud_imports()
    force_pipeline_config()
    install_action_filter()
    harden_git_voice_local()
    bind_dashboard_localhost()

    # Late imports after offline policy is active
    try:
        from PyQt6.QtWidgets import QApplication
    except Exception:
        QApplication = None  # type: ignore

    try:
        from ui import JarvisUI
        import main as jarvis_main
    except Exception as e:
        log(f"Falha ao importar UI/main: {e}")
        traceback.print_exc()
        return 1

    # Force engine mode helper on the class for this process
    try:
        def _engine_mode_local(self) -> str:
            return "pipeline"

        jarvis_main.JarvisLive._engine_mode = _engine_mode_local  # type: ignore[method-assign]
        log("JarvisLive._engine_mode forçado para 'pipeline'.")
    except Exception as e:
        log(f"Não foi possível forçar _engine_mode: {e}")

    # Boot UI + biometrics same path as main.py
    try:
        app = None
        if QApplication is not None:
            app = QApplication.instance() or QApplication(sys.argv)

        ui = JarvisUI()
        jarvis = jarvis_main.JarvisLive(ui)

        try:
            from core.boot_biometrics import enforce_startup_biometrics, hard_exit
            ok = enforce_startup_biometrics(ui=ui)
            if ok is False:
                log("Biometria recusada — encerrando.")
                try:
                    hard_exit()
                except Exception:
                    return 2
        except Exception as e:
            log(f"Boot biométrico: {e} (seguindo se já liberado)")

        import asyncio
        try:
            asyncio.run(jarvis.run())
        except KeyboardInterrupt:
            log("Interrompido pelo usuário.")
            return 0
        return 0
    except Exception as e:
        log(f"Erro fatal: {e}")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
