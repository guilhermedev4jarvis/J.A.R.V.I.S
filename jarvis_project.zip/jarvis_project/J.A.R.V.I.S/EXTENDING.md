# Estendendo o J.A.R.V.I.S. / MARK LXI

Tudo novo encaixa em **actions/** (tools descobertas pelo `action_loader`) ou
**plugins/** (descobertos pelo `plugin_loader`). Não precisa registrar em
`main.py`.

## Setup (só ponte)

```bash
python setup.py              # requirements.txt
python setup.py --local      # + voz offline
python setup.py --heavy      # + pandas/mcp/chroma/…
python setup.py --browsers   # motores Playwright
python setup.py --all
```

Edite `requirements.txt` / `requirements-local.txt` / `requirements-heavy.txt`.
O `setup.py` não lista pacotes — só chama o pip nesses arquivos.

## Criar action ou plugin em 10 segundos

```bash
python scripts/new_module.py action minha_ferramenta --desc "Faz X quando o usuário pedir Y" --risk safe
python scripts/new_module.py plugin meu_plugin --desc "…"
```

### Contrato de action (`actions/*.py`)

```python
TOOL = {
    "name": "minha_ferramenta",
    "description": "…",          # o modelo lê isto
    "parameters": {"type": "OBJECT", "properties": {...}, "required": []},
    "handler": minha_ferramenta, # callable
    "risk": "safe",              # safe | review | destructive | autonomous
}
```

Sempre devolver strings do `core.outcome`:

```python
from core.outcome import done, failed, ask, unverified, started
return done("minha_ferramenta", note="ok")
```

### Contrato de plugin (`plugins/*.py`)

```python
PLUGIN = { "name": "...", "description": "...", "parameters": {...} }

def run(parameters, player=None, session_memory=None) -> str:
    return "status=done action=... result=..."
```

## Camadas úteis ao estender

| Módulo | Quando usar |
|--------|-------------|
| `core.outcome` | Resposta honesta ao modelo |
| `core.contracts` | risk tiers / validação de schema |
| `core.confirm` | Ação irreversível com banner no HUD |
| `core.owner_gate` | Shutdown/restart → biometria do dono |
| `core.sandbox` | dry-run / paths seguros |
| `core.redaction` | Logs sem vazar secrets |
| `core.audit` | Trilha de ações críticas |
| `core.agent_mode` | listen / assist / autonomous |
| `core.retry` | Rede/UI instável |
| `memory.memory_manager` | Fatos, episódios, grafo |

## Hot reload

Sem reiniciar o processo:

```text
hot_reload action=actions
hot_reload action=one name=minha_ferramenta
```

## Testes mínimos

```bash
python tests/test_action_contracts.py
python tests/test_quality_layers.py
python scripts/check_deps.py
```

## Biometria do dono

Ver `docs_OWNER_BIOMETRICS.md`. Arquivos em `memory/biometrics/`.

## Modelo local padrão

Ollama: `qwen2.5-coder:7b` (`config/api_keys.json` / `core/llm_client.py`).

## Plugins de apps criativos (exemplos inclusos)

| Plugin | App | O que faz |
|--------|-----|-----------|
|  | Blender | abrir, mesh básico, script bpy, export, render |
|  | Roblox Studio + Rojo | projeto Rojo, scripts Luau, abrir Studio |
|  | Godot | projeto, GDScript, abrir editor |

Variáveis de ambiente úteis: , , .
