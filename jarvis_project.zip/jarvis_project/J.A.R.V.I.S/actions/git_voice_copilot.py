"""Action: git_voice_copilot — safe voice-driven git operations."""
from __future__ import annotations
from core.outcome import failed

def git_voice_copilot(parameters=None, player=None, session_memory=None, **ctx):
    try:
        from actions._git_voice_copilot_impl import run
        return run(parameters, player=player, session_memory=session_memory, **ctx)
    except Exception as e:
        return failed("git_voice_copilot", f"impl error: {e}")

TOOL = {
    "name": "git_voice_copilot",
    "description": (
        "Controle Git por voz: status_summary, diff_explain, smart_commit, push, "
        "create_branch. Respeita sandbox e exige owner_gate em commit/push. "
        "Use for 'resumo do git', 'explica o diff', 'faz commit inteligente', "
        "'cria branch feature-x'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "enum": ["status_summary", "diff_explain", "smart_commit", "push", "create_branch"],
            },
            "path": {"type": "STRING", "description": "Caminho do repositorio"},
            "message": {"type": "STRING", "description": "Mensagem de commit opcional"},
            "branch": {"type": "STRING"},
            "remote": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": git_voice_copilot,
    "tier": "core",
    "risk": "destructive",
}
