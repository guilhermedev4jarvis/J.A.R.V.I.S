"""Save/restore multi-window layouts (Windows; best-effort elsewhere)."""
from __future__ import annotations

import json
import platform
import subprocess
from pathlib import Path
from typing import Optional

from core.outcome import ask, done, failed, unverified

_BASE = Path(__file__).resolve().parents[1]
_STORE = _BASE / "config" / "window_workspaces.json"
_OS = platform.system()


def _load() -> dict:
    if not _STORE.is_file():
        return {"version": 1, "workspaces": {}}
    try:
        return json.loads(_STORE.read_text(encoding="utf-8"))
    except Exception:
        return {"version": 1, "workspaces": {}}


def _save(data: dict) -> None:
    _STORE.parent.mkdir(parents=True, exist_ok=True)
    _STORE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _run_ps(script: str, timeout: float = 25.0) -> tuple[int, str, str]:
    kw = {"creationflags": 0x08000000} if _OS == "Windows" else {}
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True, text=True, timeout=timeout, **kw,
        )
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except Exception as e:
        return 1, "", str(e)


def _capture_windows() -> list[dict]:
    if _OS != "Windows":
        return []
    # Compact one-liner style to avoid quoting hell
    ps = (
        "$ErrorActionPreference='SilentlyContinue'; "
        "Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle } | "
        "ForEach-Object { "
        "  $h=$_.MainWindowHandle; $t=$_.MainWindowTitle; "
        "  Add-Type -MemberDefinition '"
        "[DllImport(\"user32.dll\")] public static extern bool GetWindowRect(IntPtr h, out RECT r); "
        "[StructLayout(LayoutKind.Sequential)] public struct RECT{public int L,T,R,B;}' "
        "-Name WU -Namespace Native -ErrorAction SilentlyContinue; "
        "  $r = New-Object Native.WU+RECT; "
        "  [void][Native.WU]::GetWindowRect([IntPtr]$h, [ref]$r); "
        "  [pscustomobject]@{title=$t; x=$r.L; y=$r.T; w=($r.R-$r.L); h=($r.B-$r.T)} "
        "} | ConvertTo-Json -Compress"
    )
    code, out, err = _run_ps(ps)
    if code != 0 or not out:
        # fallback: titles only
        code2, out2, _ = _run_ps(
            "Get-Process | Where-Object {$_.MainWindowTitle} | "
            "Select-Object -ExpandProperty MainWindowTitle | ConvertTo-Json -Compress"
        )
        if code2 != 0 or not out2:
            return []
        try:
            titles = json.loads(out2)
            if isinstance(titles, str):
                titles = [titles]
            return [{"title": t, "x": 50, "y": 50, "w": 900, "h": 700} for t in titles]
        except Exception:
            return []
    try:
        data = json.loads(out)
        if isinstance(data, dict):
            data = [data]
        return [
            {"title": d.get("title"), "x": d.get("x", 0), "y": d.get("y", 0),
             "w": d.get("w", 800), "h": d.get("h", 600)}
            for d in data if (d.get("w") or 0) > 40
        ]
    except Exception:
        return []


def _restore_windows(layout: list[dict]) -> int:
    if _OS != "Windows":
        return 0
    applied = 0
    for item in layout:
        title = str(item.get("title") or "").replace("'", "''")
        x, y = int(item.get("x") or 0), int(item.get("y") or 0)
        w, h = int(item.get("w") or 800), int(item.get("h") or 600)
        ps = (
            f"$p = Get-Process | Where-Object {{ $_.MainWindowTitle -eq '{title}' }} | Select-Object -First 1; "
            f"if ($p) {{ "
            f"  Add-Type -Name W -Namespace N -MemberDefinition '"
            f"[DllImport(\"user32.dll\")] public static extern bool MoveWindow(IntPtr h,int x,int y,int w,int hh,bool r);' "
            f"-ErrorAction SilentlyContinue; "
            f"  [void][N.W]::MoveWindow($p.MainWindowHandle, {x}, {y}, {w}, {h}, $true); "
            f"}}"
        )
        code, _, _ = _run_ps(ps)
        if code == 0:
            applied += 1
    return applied


def run(parameters: Optional[dict] = None, player=None, **_ctx) -> str:
    p = dict(parameters or {})
    action = str(p.get("action") or p.get("mode") or "list").strip().lower()
    name = str(p.get("name") or p.get("workspace") or p.get("layout") or "").strip()
    data = _load()
    spaces = data.setdefault("workspaces", {})

    if action in ("list", "show"):
        return done(
            "window_workspace_saver",
            op="list",
            count=len(spaces),
            names=",".join(sorted(spaces)) or "(none)",
        )

    if action in ("save", "store"):
        if not name:
            return ask("window_workspace_saver", "Qual o nome do layout a salvar?")
        layout = _capture_windows()
        if not layout:
            return unverified(
                "window_workspace_saver",
                "no windows captured (Windows required or empty desktop)",
            )
        spaces[name] = {"windows": layout}
        _save(data)
        return done("window_workspace_saver", op="save", name=name, windows=len(layout))

    if action in ("apply", "restore", "load"):
        if not name or name not in spaces:
            return ask(
                "window_workspace_saver",
                "Qual layout aplicar? " + (", ".join(spaces) or "nenhum"),
            )
        layout = spaces[name].get("windows") or []
        n = _restore_windows(layout)
        if n == 0 and _OS != "Windows":
            return failed("window_workspace_saver", "restore requires Windows")
        return done(
            "window_workspace_saver",
            op="apply",
            name=name,
            applied=n,
            stored=len(layout),
        )

    if action in ("delete", "remove"):
        if not name or name not in spaces:
            return failed(
                "window_workspace_saver",
                f"layout not found: {name or '(empty)'}",
            )
        del spaces[name]
        _save(data)
        return done("window_workspace_saver", op="delete", name=name)

    return failed("window_workspace_saver", f"unknown action {action}")
