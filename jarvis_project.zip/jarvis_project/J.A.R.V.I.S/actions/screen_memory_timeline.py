"""Action: screen_memory_timeline — private window title + OCR timeline."""
from __future__ import annotations
from core.outcome import failed

def screen_memory_timeline(parameters=None, player=None, session_memory=None, **ctx):
    try:
        from actions._screen_memory_timeline_impl import run
        return run(parameters, player=player, session_memory=session_memory, **ctx)
    except Exception as e:
        return failed("screen_memory_timeline", f"impl error: {e}")

TOOL = {
    "name": "screen_memory_timeline",
    "description": (
        "Memoria visual privada: captura titulo da janela ativa e texto OCR "
        "(com redaction) em memory/screen_timeline.db. Modes: capture_now, search, "
        "recent, clear (owner_gate). Use for 'o que eu estava vendo hoje cedo', "
        "'recupera o erro do terminal de 10 minutos atras'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "enum": ["capture_now", "search", "recent", "clear"],
            },
            "query": {"type": "STRING"},
            "since_minutes": {"type": "NUMBER"},
            "limit": {"type": "NUMBER"},
            "title": {"type": "STRING"},
            "text": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": screen_memory_timeline,
    "tier": "core",
    "risk": "review",
}
