"""screen_memory_timeline — private OCR/title timeline in SQLite."""
from __future__ import annotations

import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.outcome import ask, done, failed

_BASE = Path(__file__).resolve().parents[1]
_DB = _BASE / "memory" / "screen_timeline.db"


def _db_path() -> Path:
    _DB.parent.mkdir(parents=True, exist_ok=True)
    return _DB


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(str(_db_path()))
    c.row_factory = sqlite3.Row
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS timeline (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL NOT NULL,
            window_title TEXT,
            ocr_text TEXT,
            source TEXT
        )
        """
    )
    c.execute("CREATE INDEX IF NOT EXISTS idx_timeline_ts ON timeline(ts)")
    c.commit()
    return c


def _redact(text: str) -> str:
    try:
        from core.redaction import redact_text
        return redact_text(text or "")
    except Exception:
        return text or ""


def _active_window_title() -> str:
    try:
        import platform
        if platform.system() == "Windows":
            import ctypes
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(length + 1)
            ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
            return buf.value or ""
    except Exception:
        pass
    try:
        import subprocess
        r = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowname"],
            capture_output=True, text=True, timeout=3,
        )
        if r.returncode == 0:
            return (r.stdout or "").strip()
    except Exception:
        pass
    return ""


def _ocr_screen() -> str:
    """Best-effort screenshot OCR; returns empty string if deps missing."""
    try:
        import tempfile
        from pathlib import Path as P
        try:
            import mss
            import mss.tools
            with mss.mss() as sct:
                mon = sct.monitors[1]
                shot = sct.grab(mon)
                tmp = P(tempfile.gettempdir()) / "jarvis_screen_ocr.png"
                mss.tools.to_png(shot.rgb, shot.size, output=str(tmp))
        except Exception:
            # pillow grab
            from PIL import ImageGrab
            img = ImageGrab.grab()
            tmp = P(tempfile.gettempdir()) / "jarvis_screen_ocr.png"
            img.save(str(tmp))
        try:
            import pytesseract
            from PIL import Image
            text = pytesseract.image_to_string(Image.open(str(tmp))) or ""
            return text[:8000]
        except Exception:
            return ""
    except Exception:
        return ""


def capture_now(title: str = "", text: str = "", source: str = "capture_now") -> dict:
    title = title or _active_window_title()
    if not text:
        text = _ocr_screen()
    title_r = _redact(title)
    text_r = _redact(text)
    ts = time.time()
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO timeline(ts, window_title, ocr_text, source) VALUES (?,?,?,?)",
            (ts, title_r, text_r, source),
        )
        c.commit()
        row_id = cur.lastrowid
    return {
        "id": row_id,
        "ts": ts,
        "window_title": title_r,
        "ocr_text": text_r[:500],
        "chars": len(text_r),
    }


def search(query: str, since_minutes: Optional[float] = None, limit: int = 20) -> list[dict]:
    query = (query or "").strip()
    limit = max(1, min(int(limit), 100))
    sql = "SELECT id, ts, window_title, ocr_text, source FROM timeline WHERE 1=1"
    args: list = []
    if since_minutes is not None:
        sql += " AND ts >= ?"
        args.append(time.time() - float(since_minutes) * 60.0)
    if query:
        sql += " AND (window_title LIKE ? OR ocr_text LIKE ?)"
        q = f"%{query}%"
        args.extend([q, q])
    sql += " ORDER BY ts DESC LIMIT ?"
    args.append(limit)
    with _conn() as c:
        rows = c.execute(sql, args).fetchall()
    out = []
    for r in rows:
        out.append({
            "id": r["id"],
            "ts": r["ts"],
            "when": datetime.fromtimestamp(r["ts"]).isoformat(timespec="seconds"),
            "window_title": r["window_title"],
            "snippet": (r["ocr_text"] or "")[:240],
            "source": r["source"],
        })
    return out


def recent(limit: int = 10) -> list[dict]:
    return search("", since_minutes=None, limit=limit)


def clear_all() -> int:
    with _conn() as c:
        cur = c.execute("DELETE FROM timeline")
        c.commit()
        return cur.rowcount if cur.rowcount is not None else 0


def _owner_ok() -> tuple[bool, str]:
    try:
        from core import owner_gate
        if hasattr(owner_gate, "require_unlocked_for_critical"):
            r = owner_gate.require_unlocked_for_critical("screen_memory_timeline", "clear", camera=True)
            if isinstance(r, dict):
                return bool(r.get("accepted")), str(r.get("detail") or "")
        return True, "ok"
    except Exception as e:
        return False, f"owner_gate error: {e}"


def run(parameters=None, player=None, **_ctx) -> str:
    p = dict(parameters or {})
    action = str(p.get("action") or p.get("mode") or "recent").strip().lower()

    if action in ("capture_now", "capture"):
        # allow tests to inject title/text without OCR/hardware
        rec = capture_now(
            title=str(p.get("title") or p.get("window_title") or ""),
            text=str(p.get("text") or p.get("ocr_text") or ""),
            source="capture_now",
        )
        return done(
            "screen_memory_timeline",
            op="capture_now",
            id=rec["id"],
            title=rec["window_title"][:120],
            chars=rec["chars"],
        )

    if action in ("search", "find", "query"):
        q = str(p.get("query") or p.get("q") or p.get("text") or "").strip()
        if not q:
            return ask("screen_memory_timeline", "O que procurar na timeline de tela?")
        since = p.get("since_minutes")
        if since is None and p.get("minutes") is not None:
            since = p.get("minutes")
        rows = search(q, since_minutes=float(since) if since is not None else None,
                      limit=int(p.get("limit") or 20))
        summary = " | ".join(
            f"{r['when']}:{r['window_title'][:40]}:{r['snippet'][:60]}" for r in rows
        ) or "(no hits)"
        return done("screen_memory_timeline", op="search", query=q, hits=len(rows), results=summary)

    if action in ("recent", "list", "history"):
        rows = recent(limit=int(p.get("limit") or 10))
        summary = " | ".join(
            f"{r['when']}:{r['window_title'][:50]}" for r in rows
        ) or "(empty)"
        return done("screen_memory_timeline", op="recent", count=len(rows), results=summary)

    if action in ("clear", "wipe", "reset"):
        ok, detail = _owner_ok()
        if not ok:
            return failed("screen_memory_timeline", f"owner_gate denied: {detail}")
        n = clear_all()
        return done("screen_memory_timeline", op="clear", deleted=n)

    return failed("screen_memory_timeline", f"action desconhecida: {action}")
