"""Action: window_workspace_saver — save/restore multi-window layouts."""
from __future__ import annotations
from core.outcome import failed

def window_workspace_saver(parameters=None, player=None, session_memory=None, **ctx):
    try:
        from actions._window_workspace_saver_impl import run
        return run(parameters, player=player, session_memory=session_memory, **ctx)
    except Exception as e:
        return failed("window_workspace_saver", f"impl error: {e}")

TOOL = {
    "name": "window_workspace_saver",
    "description": (
        "Save and restore exact multi-window positions/sizes as named layouts "
        "(config/window_workspaces.json). Use for 'salvar layout programação', "
        "'aplicar layout trabalho', 'listar layouts de janelas'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "enum": ["list", "save", "apply", "delete"]},
            "name": {"type": "STRING", "description": "Layout name"},
        },
        "required": [],
    },
    "handler": window_workspace_saver,
    "tier": "core",
    "risk": "review",
}
