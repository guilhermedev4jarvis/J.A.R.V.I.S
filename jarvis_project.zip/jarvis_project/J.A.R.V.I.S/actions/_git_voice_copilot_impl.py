"""git_voice_copilot — voice-driven git with sandbox + owner_gate."""
from __future__ import annotations

import platform
import re
import subprocess
from pathlib import Path
from typing import Optional

from core.outcome import ask, done, failed

_OS = platform.system()


def _run_git(args: list[str], cwd: Path, timeout: float = 30.0) -> tuple[int, str, str]:
    kw = {}
    if _OS == "Windows":
        kw["creationflags"] = 0x08000000
    try:
        r = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            **kw,
        )
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", "git not found"
    except subprocess.TimeoutExpired:
        return 124, "", "git timeout"
    except Exception as e:
        return 1, "", str(e)


def _sandbox_ok(path: Path) -> tuple[bool, str]:
    try:
        from core import sandbox
        if hasattr(sandbox, "is_allowed") and not sandbox.is_allowed(str(path)):
            return False, "path not allowed by sandbox"
        if hasattr(sandbox, "check_path"):
            ok = sandbox.check_path(str(path))
            if ok is False:
                return False, "path blocked by sandbox"
    except Exception:
        home = Path.home().resolve()
        try:
            path.resolve().relative_to(home)
        except Exception:
            root = Path(__file__).resolve().parents[1]
            try:
                path.resolve().relative_to(root)
            except Exception:
                return False, "path outside home/project"
    return True, "ok"


def _resolve_repo(path_s: str) -> tuple[Optional[Path], str]:
    if path_s:
        p = Path(path_s).expanduser()
    else:
        p = Path.cwd()
    p = p.resolve()
    ok, why = _sandbox_ok(p)
    if not ok:
        return None, why
    # find git root
    code, out, err = _run_git(["rev-parse", "--show-toplevel"], p)
    if code != 0:
        return None, err or "not a git repository"
    root = Path(out.strip()).resolve()
    ok, why = _sandbox_ok(root)
    if not ok:
        return None, why
    return root, "ok"


def _owner_ok(action: str) -> tuple[bool, str]:
    try:
        from core import owner_gate
        if hasattr(owner_gate, "require_unlocked_for_critical"):
            r = owner_gate.require_unlocked_for_critical("git_voice_copilot", action, camera=True)
            if isinstance(r, dict):
                return bool(r.get("accepted")), str(r.get("detail") or "")
        return True, "ok"
    except Exception as e:
        return False, f"owner_gate error: {e}"


def _audit(event: str, detail: dict) -> None:
    try:
        from core import audit
        audit.log_event(event, detail)
    except Exception:
        pass


def _llm_explain(diff: str, mode: str = "explain") -> str:
    diff = (diff or "")[:12000]
    if not diff.strip():
        return "(sem alterações)"
    prompt = (
        "Explique em português, de forma clara e curta, o que mudou neste git diff. "
        "Foque no impacto funcional.\n\n" + diff
        if mode == "explain"
        else
        "Gere UMA mensagem de commit semântica (conventional commits se possível), "
        "apenas a linha de subject, max 72 chars, em português ou inglês conforme o código.\n\n"
        + diff
    )
    try:
        from core.llm_client import call_llm_text
        text = call_llm_text(prompt, system="You are a senior software engineer.", timeout=45)
        if text:
            return text.strip().splitlines()[0][:200] if mode == "commit" else text.strip()[:2000]
    except Exception:
        pass
    try:
        from core import gemini as gem
        text = gem.text(prompt, timeout_ms=45_000)
        if text:
            return text.strip().splitlines()[0][:200] if mode == "commit" else text.strip()[:2000]
    except Exception:
        pass
    # heuristic fallback
    files = re.findall(r"^\+\+\+ b/(.+)$", diff, re.M)
    if mode == "commit":
        if files:
            return f"chore: update {', '.join(files[:3])}"
        return "chore: update files"
    return f"Arquivos tocados: {', '.join(files[:8]) or '(desconhecido)'}"


def run(parameters: Optional[dict] = None, player=None, **_ctx) -> str:
    p = dict(parameters or {})
    action = str(p.get("action") or p.get("mode") or "status_summary").strip().lower()
    path_s = str(p.get("path") or p.get("repo") or p.get("cwd") or "").strip()
    repo, why = _resolve_repo(path_s)
    if repo is None and action not in ("help",):
        return failed("git_voice_copilot", why or "invalid repo")

    if action in ("status_summary", "status"):
        code, branch, _ = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], repo)
        b = branch if code == 0 else "?"
        code, st, err = _run_git(["status", "--porcelain"], repo)
        if code != 0:
            return failed("git_voice_copilot", err or "status failed")
        lines = [ln for ln in st.splitlines() if ln.strip()]
        summary = f"Branch {b}. " + (
            f"{len(lines)} arquivo(s) modificados: " + "; ".join(lines[:12])
            if lines else "Working tree limpa."
        )
        return done("git_voice_copilot", op="status_summary", branch=b, changes=len(lines), summary=summary)

    if action in ("diff_explain", "diff"):
        code, diff, err = _run_git(["diff", "HEAD"], repo)
        if code != 0:
            # try unstaged + staged
            code, diff, err = _run_git(["diff"], repo)
        if code != 0:
            return failed("git_voice_copilot", err or "diff failed")
        explanation = _llm_explain(diff, mode="explain")
        return done("git_voice_copilot", op="diff_explain", explanation=explanation, diff_chars=len(diff))

    if action in ("smart_commit", "commit"):
        ok, detail = _owner_ok("commit")
        if not ok:
            return failed("git_voice_copilot", f"owner_gate denied: {detail}")
        code, diff, err = _run_git(["diff", "HEAD"], repo)
        if code != 0:
            code, diff, err = _run_git(["diff"], repo)
        msg = str(p.get("message") or "").strip() or _llm_explain(diff, mode="commit")
        msg = msg.strip().strip('"').strip("'")[:200]
        code, out, err = _run_git(["add", "-A"], repo)
        if code != 0:
            return failed("git_voice_copilot", f"git add failed: {err}")
        code, out, err = _run_git(["commit", "-m", msg], repo, timeout=60)
        if code != 0:
            return failed("git_voice_copilot", f"git commit failed: {err or out}")
        _audit("git_smart_commit", {"repo": str(repo), "message": msg})
        return done("git_voice_copilot", op="smart_commit", message=msg, repo=str(repo))

    if action in ("push",):
        ok, detail = _owner_ok("push")
        if not ok:
            return failed("git_voice_copilot", f"owner_gate denied: {detail}")
        remote = str(p.get("remote") or "origin").strip()
        code, branch, _ = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], repo)
        branch = branch if code == 0 else "HEAD"
        code, out, err = _run_git(["push", remote, branch], repo, timeout=120)
        if code != 0:
            return failed("git_voice_copilot", f"git push failed: {err or out}")
        _audit("git_push", {"repo": str(repo), "remote": remote, "branch": branch})
        return done("git_voice_copilot", op="push", remote=remote, branch=branch)

    if action in ("create_branch", "branch"):
        name = str(p.get("branch") or p.get("name") or "").strip()
        if not name:
            return ask("git_voice_copilot", "Qual o nome da nova branch?")
        if not re.match(r"^[A-Za-z0-9._/\-]+$", name):
            return failed("git_voice_copilot", "nome de branch inválido")
        code, out, err = _run_git(["checkout", "-b", name], repo)
        if code != 0:
            return failed("git_voice_copilot", f"create branch failed: {err or out}")
        return done("git_voice_copilot", op="create_branch", branch=name)

    return failed(
        "git_voice_copilot",
        f"action desconhecida: {action}. Use status_summary|diff_explain|smart_commit|push|create_branch",
    )
