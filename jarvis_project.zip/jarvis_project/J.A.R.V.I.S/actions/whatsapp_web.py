"""
Action: whatsapp_web — abrir WhatsApp Web, pesquisar contato e enviar mensagem.

Qualquer intenção envolvendo "WhatsApp" deve chamar esta tool (não open_app
isolado nem send_message genérico).

Modos:
  open            → abre https://whatsapp.com e pergunta o contato
  search_contact  → abre/foca, pesquisa o contato e abre a conversa
  send            → fluxo completo (contact + message); pergunta o que faltar

Método principal: Playwright (seletores da caixa de pesquisa e do campo de
mensagem). Fallback: pyautogui + pyperclip (atalho Ctrl/Cmd+Alt+/ e clipboard).
"""

from __future__ import annotations

import importlib.util
import sys
import time
from typing import Any, Optional

from core.outcome import ask, done, failed, unverified
from core.lazyimport import LazyModule, installed

_PYAUTOGUI = installed("pyautogui")
_PYPERCLIP = installed("pyperclip")
_HAS_PLAYWRIGHT = importlib.util.find_spec("playwright") is not None

_WA_URL = "https://whatsapp.com"
_WA_WEB_URL = "https://web.whatsapp.com"

_SEARCH_SELECTORS = [
    'div[contenteditable="true"][data-tab="3"]',
    'div[contenteditable="true"][title*="Pesquisar"]',
    'div[contenteditable="true"][title*="Search"]',
    '[aria-label*="Pesquisar"]',
    '[aria-label*="Search"]',
    'div[contenteditable="true"][data-tab="3"][role="textbox"]',
]
_MESSAGE_SELECTORS = [
    'div[contenteditable="true"][data-tab="10"]',
    'footer div[contenteditable="true"]',
    'div[contenteditable="true"][data-tab="10"][role="textbox"]',
    'div[contenteditable="true"][title*="Mensagem"]',
    'div[contenteditable="true"][title*="Type a message"]',
]


def _configure_pyautogui(module) -> None:
    module.FAILSAFE = True
    module.PAUSE = 0.06


pyautogui = LazyModule("pyautogui", _configure_pyautogui)
pyperclip = LazyModule("pyperclip")


def _log(player, msg: str) -> None:
    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass


def _open_whatsapp_url() -> bool:
    """Abre WhatsApp Web. Preferência: https://whatsapp.com (redireciona para a sessão Web).
    Fallback: https://web.whatsapp.com para automação direta no DOM.
    """
    import webbrowser
    try:
        webbrowser.open(_WA_URL)
        return True
    except Exception:
        try:
            webbrowser.open(_WA_WEB_URL)
            return True
        except Exception:
            return False


def _wait_whatsapp_web_ready_playwright(page, timeout_s: float = 45.0) -> str:
    """Espera interface do WhatsApp Web: caixa de pesquisa (logado) ou canvas/QR (não logado).
    Retorna "authenticated" | "qr" | "timeout".
    """
    deadline = time.time() + timeout_s
    qr_selectors = [
        'canvas[aria-label*="Scan"]',
        'canvas[aria-label*="QR"]',
        'div[data-ref]',
        'div[data-testid="qrcode"]',
        'canvas',
    ]
    while time.time() < deadline:
        for sel in _SEARCH_SELECTORS:
            try:
                loc = page.locator(sel).first
                if loc.count() > 0 and loc.is_visible(timeout=400):
                    return "authenticated"
            except Exception:
                continue
        for sel in qr_selectors:
            try:
                loc = page.locator(sel).first
                if loc.count() > 0 and loc.is_visible(timeout=300):
                    # Ainda no QR — continua esperando sessão
                    break
            except Exception:
                continue
        time.sleep(0.7)
    # Última checagem de pesquisa
    for sel in _SEARCH_SELECTORS:
        try:
            loc = page.locator(sel).first
            if loc.count() > 0 and loc.is_visible(timeout=500):
                return "authenticated"
        except Exception:
            continue
    return "timeout"


def _wait_gui_settle(seconds: float = 6.0, player=None) -> None:
    """Aguarda carregamento inicial do WhatsApp Web no navegador padrão (GUI path)."""
    _log(player, f"Aguardando interface do WhatsApp Web (~{seconds:.0f}s)…")
    time.sleep(max(3.0, float(seconds)))


def _paste(text: str) -> None:
    if not _PYAUTOGUI:
        raise RuntimeError("PyAutoGUI não instalado. Rode: pip install pyautogui pyperclip")
    if _PYPERCLIP:
        pyperclip.copy(text)
        time.sleep(0.12)
        if sys.platform == "darwin":
            pyautogui.hotkey("command", "v")
        else:
            pyautogui.hotkey("ctrl", "v")
    else:
        pyautogui.write(text, interval=0.03)
    time.sleep(0.15)


def _clear_field() -> None:
    if sys.platform == "darwin":
        pyautogui.hotkey("command", "a")
    else:
        pyautogui.hotkey("ctrl", "a")
    time.sleep(0.1)
    pyautogui.press("backspace")
    time.sleep(0.12)


def _focus_search_gui(player=None) -> None:
    if sys.platform == "darwin":
        pyautogui.hotkey("command", "alt", "/")
    else:
        pyautogui.hotkey("ctrl", "alt", "/")
    time.sleep(0.7)
    try:
        w, h = pyautogui.size()
        points = [
            (int(w * 0.14), int(h * 0.10)),
            (int(w * 0.12), int(h * 0.09)),
            (int(w * 0.18), int(h * 0.11)),
        ]
        for x, y in points:
            pyautogui.moveTo(x, y, duration=0.2)
            time.sleep(0.12)
            pyautogui.click()
            time.sleep(0.3)
        if sys.platform == "darwin":
            pyautogui.hotkey("command", "alt", "/")
        else:
            pyautogui.hotkey("ctrl", "alt", "/")
        time.sleep(0.45)
    except Exception:
        pass


def _search_and_open_contact_gui(contact: str, player=None) -> None:
    _focus_search_gui(player)
    _clear_field()
    _paste(contact)
    time.sleep(1.2)
    pyautogui.press("enter")
    time.sleep(1.0)
    try:
        _focus_search_gui(player)
        _clear_field()
        _paste(contact)
        time.sleep(1.1)
        pyautogui.press("enter")
        time.sleep(0.9)
    except Exception:
        pass


def _send_message_gui(message: str) -> None:
    _paste(message)
    time.sleep(0.25)
    pyautogui.press("enter")
    time.sleep(0.35)


def _run_playwright_send(contact: str, message: str, player=None, timeout_s: float = 45.0) -> str:
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = None
        for channel in ("chrome", "msedge", "chromium", None):
            try:
                kwargs: dict[str, Any] = {"headless": False}
                if channel:
                    kwargs["channel"] = channel
                browser = p.chromium.launch(**kwargs)
                break
            except Exception:
                continue
        if browser is None:
            raise RuntimeError("não foi possível lançar Chromium/Chrome/Edge via Playwright")

        try:
            context = browser.new_context()
            page = context.new_page()
            page.goto(_WA_WEB_URL, wait_until="domcontentloaded", timeout=int(timeout_s * 1000))
            _log(player, "Playwright: página WhatsApp Web carregando")
            ready = _wait_whatsapp_web_ready_playwright(page, timeout_s=min(40.0, timeout_s))
            if ready == "timeout":
                raise RuntimeError(
                    "WhatsApp Web não ficou pronto (QR ou caixa de pesquisa ausentes). "
                    "Escaneie o QR Code se necessário e tente de novo."
                )
            if ready == "qr":
                # Aguarda mais um ciclo após detecção de QR para login
                ready2 = _wait_whatsapp_web_ready_playwright(page, timeout_s=60.0)
                if ready2 != "authenticated":
                    raise RuntimeError(
                        "sessão WhatsApp Web não autenticada — escaneie o QR Code"
                    )
            _log(player, f"Playwright: interface pronta ({ready})")

            search = None
            deadline = time.time() + min(25.0, timeout_s)
            while time.time() < deadline and search is None:
                for sel in _SEARCH_SELECTORS:
                    try:
                        loc = page.locator(sel).first
                        if loc.count() > 0 and loc.is_visible(timeout=500):
                            search = loc
                            break
                    except Exception:
                        continue
                if search is None:
                    time.sleep(0.6)

            if search is None:
                raise RuntimeError(
                    "caixa de pesquisa do WhatsApp Web não apareceu — "
                    "verifique se a sessão está logada (QR)"
                )

            search.click()
            time.sleep(0.3)
            search.fill("")
            search.type(contact, delay=40)
            time.sleep(1.0)
            page.keyboard.press("Enter")
            time.sleep(1.2)

            msg_box = None
            deadline = time.time() + 12.0
            while time.time() < deadline and msg_box is None:
                for sel in _MESSAGE_SELECTORS:
                    try:
                        loc = page.locator(sel).first
                        if loc.count() > 0 and loc.is_visible(timeout=400):
                            msg_box = loc
                            break
                    except Exception:
                        continue
                if msg_box is None:
                    time.sleep(0.4)

            if msg_box is None:
                raise RuntimeError(
                    f"campo de mensagem não abriu para o contato {contact!r}"
                )

            msg_box.click()
            time.sleep(0.2)
            msg_box.type(message, delay=25)
            time.sleep(0.2)
            page.keyboard.press("Enter")
            time.sleep(0.5)
            _log(player, f"Playwright: mensagem enviada para {contact}")
            return done(
                "whatsapp_web",
                contact=contact,
                status="sent",
                method="playwright",
            )
        finally:
            try:
                browser.close()
            except Exception:
                pass


def _run_gui_send(contact: str, message: str, player=None, open_first: bool = True) -> str:
    if not _PYAUTOGUI:
        return failed(
            "whatsapp_web",
            "nem Playwright nem PyAutoGUI estão disponíveis — "
            "instale playwright ou pyautogui+pyperclip",
            contact=contact,
        )

    if open_first:
        if not _open_whatsapp_url():
            return failed(
                "whatsapp_web",
                "não foi possível abrir o navegador em https://whatsapp.com",
                contact=contact,
            )
        _wait_gui_settle(6.0, player)

    try:
        _search_and_open_contact_gui(contact, player)
        _send_message_gui(message)
    except Exception as exc:
        return failed(
            "whatsapp_web",
            f"automação GUI falhou: {exc}",
            contact=contact,
        )

    return unverified(
        "whatsapp_web",
        "a mensagem foi digitada e Enter foi pressionado via GUI, "
        "mas o envio não pode ser confirmado pelo navegador",
        contact=contact,
        status="typed",
        method="pyautogui",
    )


def _run_gui_search(contact: str, player=None, open_first: bool = True) -> str:
    if not _PYAUTOGUI:
        return failed(
            "whatsapp_web",
            "PyAutoGUI não instalado — não é possível focar a caixa de pesquisa",
            contact=contact,
        )
    if open_first:
        if not _open_whatsapp_url():
            return failed(
                "whatsapp_web",
                "não foi possível abrir https://whatsapp.com",
                contact=contact,
            )
        _wait_gui_settle(5.5, player)
    try:
        _search_and_open_contact_gui(contact, player)
    except Exception as exc:
        return failed("whatsapp_web", f"pesquisa GUI falhou: {exc}", contact=contact)
    return unverified(
        "whatsapp_web",
        "contato pesquisado e Enter pressionado; confirme se a conversa abriu",
        contact=contact,
        status="searched",
        method="pyautogui",
    )


def _normalize_params(params: dict) -> dict:
    p = dict(params or {})
    mode = (p.get("mode") or p.get("action") or "").strip().lower()
    contact = (
        p.get("contact")
        or p.get("receiver")
        or p.get("to")
        or p.get("name")
        or ""
    )
    contact = str(contact).strip()
    message = (
        p.get("message")
        or p.get("message_text")
        or p.get("text")
        or p.get("body")
        or ""
    )
    message = str(message).strip()
    if not mode:
        if contact and message:
            mode = "send"
        elif contact and not message:
            mode = "send"
        else:
            mode = "open"
    return {"mode": mode, "contact": contact, "message": message}


def whatsapp_web(
    parameters: Optional[dict] = None,
    player=None,
    session_memory=None,
    **_ctx: Any,
) -> str:
    try:
        p = _normalize_params(parameters if isinstance(parameters, dict) else {})
        mode = p["mode"]
        contact = p["contact"]
        message = p["message"]

        _log(player, f"whatsapp_web mode={mode} contact={contact!r} msg_len={len(message)}")

        if mode in ("open", "abrir", "launch"):
            ok = _open_whatsapp_url()
            if not ok:
                return failed(
                    "whatsapp_web",
                    "não foi possível abrir o navegador em https://whatsapp.com",
                )
            if contact and message:
                return _do_send(contact, message, player)
            if contact:
                return ask(
                    "whatsapp_web",
                    f"WhatsApp Web aberto. Qual mensagem você quer enviar para {contact}?",
                    contact=contact,
                    status="opened",
                )
            return ask(
                "whatsapp_web",
                "WhatsApp Web aberto. Para qual contato você quer enviar a mensagem?",
                status="opened",
            )

        if mode in ("search_contact", "search", "pesquisar", "open_chat"):
            if not contact:
                ok = _open_whatsapp_url()
                if not ok:
                    return failed(
                        "whatsapp_web",
                        "não foi possível abrir https://whatsapp.com",
                    )
                return ask(
                    "whatsapp_web",
                    "WhatsApp Web aberto. Para qual contato você quer pesquisar?",
                    status="opened",
                )
            return _run_gui_search(contact, player=player, open_first=True)

        if mode in ("send", "enviar", "message", ""):
            if not contact:
                ok = _open_whatsapp_url()
                if not ok:
                    return failed(
                        "whatsapp_web",
                        "não foi possível abrir https://whatsapp.com",
                    )
                return ask(
                    "whatsapp_web",
                    "WhatsApp Web aberto. Para qual contato você quer enviar a mensagem?",
                    status="opened",
                )
            if not message:
                try:
                    _run_gui_search(contact, player=player, open_first=True)
                except Exception:
                    _open_whatsapp_url()
                return ask(
                    "whatsapp_web",
                    f"Conversa com {contact} pronta (ou WhatsApp aberto). "
                    "Qual é o texto da mensagem?",
                    contact=contact,
                    status="awaiting_message",
                )
            return _do_send(contact, message, player)

        return failed(
            "whatsapp_web",
            f"mode desconhecido: {mode!r}. Use open, search_contact ou send.",
            mode=mode,
        )
    except Exception as exc:
        return failed("whatsapp_web", f"erro inesperado: {exc}")


def _do_send(contact: str, message: str, player=None) -> str:
    if _HAS_PLAYWRIGHT:
        try:
            return _run_playwright_send(contact, message, player=player)
        except Exception as exc:
            _log(player, f"Playwright falhou ({exc}); caindo para GUI")

    return _run_gui_send(contact, message, player=player, open_first=True)


TOOL = {
    "name": "whatsapp_web",
    "description": (
        "SEMPRE use esta tool quando o usuário mencionar WhatsApp "
        "(ex: 'abre o whatsapp', 'manda um whatsapp', 'manda mensagem no "
        "whatsapp pro João dizendo oi', 'whatsapp para a mãe'). "
        "Abre https://whatsapp.com no navegador, pesquisa o contato na caixa "
        "de pesquisa de contatos do WhatsApp Web e envia a mensagem. "
        "Modes: open (só abre e pergunta o contato), search_contact (pesquisa "
        "e abre a conversa), send (fluxo completo). Se faltar o nome do "
        "contato, abre o site e pergunta. Se faltar a mensagem, pergunta o "
        "texto. Preferência: Playwright; fallback: pyautogui + atalho "
        "Ctrl+Alt+/ (Cmd+Ctrl+/ no macOS)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {
                "type": "STRING",
                "description": (
                    "open | search_contact | send. "
                    "Omitir = send se houver contact+message, senão open."
                ),
                "enum": ["open", "search_contact", "send"],
            },
            "contact": {
                "type": "STRING",
                "description": (
                    "Nome do contato como aparece no WhatsApp "
                    "(ex: João, mãe, Talita). Alias: receiver."
                ),
            },
            "receiver": {
                "type": "STRING",
                "description": "Alias legado de contact.",
            },
            "message": {
                "type": "STRING",
                "description": "Texto da mensagem a enviar. Alias: message_text.",
            },
            "message_text": {
                "type": "STRING",
                "description": "Alias legado de message.",
            },
        },
        "required": [],
    },
    "handler": whatsapp_web,
    "tier": "core",
    "risk": "destructive",
}
