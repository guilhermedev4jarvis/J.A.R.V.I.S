"""Startup biometrics protocol — unit tests with mocks (no camera/mic)."""
from __future__ import annotations

import os
from pathlib import Path
from unittest import mock

import pytest

# Project root on path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core import boot_biometrics as bb


@pytest.fixture(autouse=True)
def _test_mode(monkeypatch, tmp_path):
    monkeypatch.setenv("MARK_BIOMETRICS_TEST_MODE", "1")
    monkeypatch.delenv("MARK_SKIP_BIOMETRICS", raising=False)
    # Redirect biometric dir to temp
    monkeypatch.setattr(bb, "_BIO", tmp_path / "biometrics")
    monkeypatch.setattr(bb, "VOICE_FILE", tmp_path / "biometrics" / "vozdono.mp3")
    monkeypatch.setattr(
        bb,
        "FACE_FILES",
        (
            tmp_path / "biometrics" / "fotobase1.jpg",
            tmp_path / "biometrics" / "fotobase2.jpg",
            tmp_path / "biometrics" / "fotobase3.jpg",
        ),
    )
    (tmp_path / "biometrics").mkdir(parents=True, exist_ok=True)
    # Mute TTS during tests
    monkeypatch.setattr(bb, "_speak_blocking", lambda *a, **k: None)
    yield


def test_required_files_missing():
    assert bb.all_present() is False
    st = bb.required_files()
    assert st["vozdono.mp3"] is False


def test_all_present_when_files_exist(tmp_path):
    for f in bb.FACE_FILES:
        f.write_bytes(b"\xff\xd8\xff")  # minimal jpeg-ish
    bb.VOICE_FILE.write_bytes(b"ID3")
    assert bb.all_present() is True


def test_face_fail_aborts_before_voice(monkeypatch):
    for f in bb.FACE_FILES:
        f.write_bytes(b"\xff\xd8\xff")
    bb.VOICE_FILE.write_bytes(b"ID3")

    class Score:
        accepted = False
        score = 0.1
        threshold = 0.7

    monkeypatch.setattr(
        "core.face_auth.verify_from_camera",
        lambda **kw: Score(),
    )
    voice_called = {"n": 0}

    def _voice(*a, **k):
        voice_called["n"] += 1
        raise AssertionError("voice must not run after face fail")

    monkeypatch.setattr("core.voice_auth.verify_wav", _voice)
    with pytest.raises(SystemExit) as ei:
        bb.authenticate(max_retries=0)
    assert ei.value.code == 1
    assert voice_called["n"] == 0


def test_voice_fail_exits(monkeypatch):
    for f in bb.FACE_FILES:
        f.write_bytes(b"\xff\xd8\xff")
    bb.VOICE_FILE.write_bytes(b"ID3")

    class FaceOK:
        accepted = True
        score = 0.99
        threshold = 0.7

    class VoiceBad:
        accepted = False
        score = 0.2
        threshold = 0.78

    monkeypatch.setattr("core.face_auth.verify_from_camera", lambda **kw: FaceOK())
    monkeypatch.setattr(bb, "_record_wav", lambda path, seconds=3.0, sr=16000: path.write_bytes(b"RIFFxxxx") or path)
    monkeypatch.setattr("core.voice_auth.verify_wav", lambda path, **kw: VoiceBad())
    monkeypatch.setattr("core.owner_gate.load_command_phrase", lambda: {"phrase": "ok jarvis"})
    monkeypatch.setattr("core.owner_gate.ensure_voice_wav", lambda: bb.VOICE_FILE)

    with pytest.raises(SystemExit) as ei:
        bb.authenticate(max_retries=0)
    assert ei.value.code == 1


def test_skip_env(monkeypatch):
    monkeypatch.setenv("MARK_SKIP_BIOMETRICS", "1")
    bb.enforce_startup_biometrics()  # must not raise


def test_setup_flags_help():
    from setup import main as setup_main
    # --help should exit 0
    with pytest.raises(SystemExit) as ei:
        setup_main(["--help"])
    assert ei.value.code == 0


def test_sequential_tts_and_phases(monkeypatch):
    """Face → voice order with TTS phrases and UI phase callbacks."""
    for f in bb.FACE_FILES:
        f.write_bytes(b"\xff\xd8\xff")
    bb.VOICE_FILE.write_bytes(b"ID3")

    class FaceOK:
        accepted = True
        score = 0.99
        threshold = 0.7

    class VoiceOK:
        accepted = True
        score = 0.95
        threshold = 0.78

    spoken = []
    phases = []

    def _speak(text, **kw):
        spoken.append(text)

    class FakeUI:
        def write_log(self, m):
            pass

        def set_biometrics_phase(self, phase, status, progress=0.0):
            phases.append((phase, status, progress))

        def show_biometrics_overlay(self):
            phases.append(("overlay", "show", 0))

        def hide_biometrics_overlay(self):
            phases.append(("overlay", "hide", 0))

    monkeypatch.setattr(bb, "_speak_blocking", _speak)
    monkeypatch.setattr("core.face_auth.verify_from_camera", lambda **kw: FaceOK())
    monkeypatch.setattr(
        bb, "_record_wav",
        lambda path, seconds=3.0, sr=16000: path.write_bytes(b"RIFFxxxx") or path,
    )
    monkeypatch.setattr("core.voice_auth.verify_wav", lambda path, **kw: VoiceOK())
    monkeypatch.setattr("core.owner_gate.load_command_phrase", lambda: {"phrase": "ok jarvis"})
    monkeypatch.setattr("core.owner_gate.ensure_voice_wav", lambda: bb.VOICE_FILE)
    monkeypatch.setattr("core.owner_gate.touch_activity", lambda: None)

    ui = FakeUI()
    bb.authenticate(ui=ui, max_retries=0)

    assert spoken[0] == bb.FACE_TTS
    assert spoken[1] == bb.VOICE_TTS
    assert spoken[2] == bb.WELCOME_TTS
    # face phase before voice phase
    phase_names = [p[0] for p in phases]
    assert "face" in phase_names
    assert "voice" in phase_names
    assert "done" in phase_names
    assert phase_names.index("face") < phase_names.index("voice")
    assert phase_names.index("voice") < phase_names.index("done")


def test_tts_phrases_constants():
    assert bb.FACE_TTS == "Começando biometria facial."
    assert bb.VOICE_TTS == "Começando biometria de voz."
