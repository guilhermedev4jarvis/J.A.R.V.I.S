"""MARK LXI: proactive autonomy ticks + dashboard API surface checks."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


@pytest.fixture()
def autonomy(tmp_path, monkeypatch):
    from actions import proactive as pro
    from actions import _context_triggers_impl as ct

    monkeypatch.setattr(pro, "_AUTONOMY_CFG", tmp_path / "proactive_autonomy.json")
    (tmp_path / "proactive_autonomy.json").write_text(json.dumps({
        "triggers_enabled": True,
        "triggers_interval_secs": 0,
        "trigger_cooldown_secs": 60,
        "timeline_enabled": True,
        "timeline_interval_secs": 0,
    }), encoding="utf-8")
    monkeypatch.setattr(ct, "_CFG", tmp_path / "context_triggers.json")
    (tmp_path / "context_triggers.json").write_text(json.dumps({
        "version": 1, "enabled": True, "rules": [{
            "id": "r1", "name": "low", "enabled": True,
            "condition": {"type": "battery_below", "percent": 20},
            "action": {"kind": "tool", "tool": "power_profile_manager", "name": "power_profile_manager"},
        }]
    }), encoding="utf-8")
    return pro, ct, pro.AutonomyController()


def test_trigger_tick_and_cooldown(autonomy, monkeypatch):
    pro, ct, ctrl = autonomy
    fired = []

    def fake_fire(action, player=None):
        fired.append(action)
        return "status=done"

    monkeypatch.setattr(ct, "_fire_action", fake_fire)
    monkeypatch.setattr(ct, "_battery_percent", lambda: 10)
    monkeypatch.setattr(ct, "_process_names", lambda: set())
    monkeypatch.setattr(ct, "_idle_seconds", lambda: None)

    r1 = ctrl.tick_triggers(force=True)
    assert r1.get("matched") == 1
    assert len(fired) == 1
    r2 = ctrl.tick_triggers(force=True)
    assert r2.get("matched") == 1
    assert "r1" in (r2.get("skipped_cooldown") or [])
    assert len(fired) == 1


def test_timeline_tick_skips_when_intruder(autonomy, monkeypatch):
    pro, ct, ctrl = autonomy
    monkeypatch.setattr(pro, "load_autonomy_config", lambda: {
        "timeline_enabled": True, "timeline_interval_secs": 0, "triggers_enabled": False,
    })
    import actions._intruder_alert_impl as ia
    monkeypatch.setattr(ia, "_state", {"active": True})
    r = ctrl.tick_timeline(force=True)
    assert r.get("captured") is False
    assert "intruder" in str(r.get("note") or "").lower()


def test_timeline_capture(autonomy, monkeypatch, tmp_path):
    pro, ct, ctrl = autonomy
    from actions import _screen_memory_timeline_impl as sm
    monkeypatch.setattr(sm, "_DB", tmp_path / "tl.db")
    monkeypatch.setattr(pro, "load_autonomy_config", lambda: {
        "timeline_enabled": True, "timeline_interval_secs": 0, "triggers_enabled": False,
    })
    import actions._intruder_alert_impl as ia
    monkeypatch.setattr(ia, "_state", {"active": False})
    monkeypatch.setattr(
        sm, "capture_now",
        lambda **k: {"id": 1, "ts": time.time(), "window_title": "t", "ocr_text": "x", "chars": 1},
    )
    r = ctrl.tick_timeline(force=True)
    assert r.get("ok") is True


def test_dashboard_server_source_has_lx_routes_and_auth():
    src = (ROOT / "dashboard" / "server.py").read_text(encoding="utf-8")
    for route in (
        '/api/missions',
        '/api/missions/resume',
        '/api/triggers',
        '/api/triggers/toggle',
        '/api/timeline',
        '/api/security/intruders',
        '/api/audio/apps',
        '/api/audio/volume',
    ):
        assert route in src, route
    # each block near these routes must call _auth
    assert src.count("if not _auth(req)") >= 6


def test_dashboard_html_has_lx_panels():
    html = (ROOT / "dashboard" / "static" / "app.html").read_text(encoding="utf-8")
    for token in ("lx-missions", "lx-triggers", "lx-timeline", "lx-audio", "lx-security", "lxLoadMissions"):
        assert token in html


def test_missions_list_logic(tmp_path):
    """Unit-level missions listing equivalent to /api/missions handler body."""
    d = tmp_path / "desktop_missions"
    d.mkdir()
    (d / "mission_x_abc.json").write_text(json.dumps({
        "id": "abc", "goal": "g", "status": "planned",
        "steps": [{"step_id": "s1", "tool_name": "web_search", "status": "pending", "description": "d"}],
    }), encoding="utf-8")
    items = []
    for f in sorted(d.glob("mission_*.json"), reverse=True)[:30]:
        data = json.loads(f.read_text(encoding="utf-8"))
        items.append({"id": data.get("id"), "status": data.get("status")})
    assert items and items[0]["id"] == "abc"


def test_triggers_toggle_logic(tmp_path, monkeypatch):
    from actions import _context_triggers_impl as ct
    from actions.context_triggers import context_triggers
    monkeypatch.setattr(ct, "_CFG", tmp_path / "t.json")
    (tmp_path / "t.json").write_text(json.dumps({
        "version": 1, "enabled": True,
        "rules": [{"id": "t1", "name": "demo", "enabled": True,
                   "condition": {"type": "battery_below", "percent": 15},
                   "action": {"kind": "routine", "name": "x"}}],
    }), encoding="utf-8")
    r = context_triggers(parameters={"action": "disable", "id": "t1"})
    assert "status=done" in r
    data = json.loads((tmp_path / "t.json").read_text(encoding="utf-8"))
    assert data["rules"][0]["enabled"] is False


def test_api_key_preserved():
    assert "YOUR_API_KEY_HERE" in (ROOT / ".env").read_text(encoding="utf-8")
    assert "YOUR_API_KEY_HERE" in (ROOT / "config" / "api_keys.json").read_text(encoding="utf-8")


def test_voice_threshold():
    from core import voice_auth
    assert voice_auth._DEFAULT_THRESHOLD == 0.75


def test_main_has_autonomy_loop():
    src = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "_run_autonomy_loop" in src
    assert "tick_autonomy" in src
