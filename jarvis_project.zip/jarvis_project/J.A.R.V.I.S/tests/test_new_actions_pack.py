"""Contract + behavioural smoke tests for the productivity/system/security pack."""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

NEW_ACTIONS = [
    "routine_orchestrator",
    "local_doc_rag",
    "meeting_transcriber",
    "app_audio_mixer",
    "power_profile_manager",
    "window_workspace_saver",
    "intruder_alert",
    "secure_vault_helper",
]

OUTCOME_KEYS = ("status=done", "status=failed", "status=ask", "status=unverified", "status=started")


@pytest.mark.parametrize("stem", NEW_ACTIONS)
def test_tool_contract_shape(stem):
    mod = importlib.import_module(f"actions.{stem}")
    tool = getattr(mod, "TOOL", None)
    assert tool is not None
    for key in ("name", "description", "parameters", "handler"):
        assert key in tool
    assert tool["name"] == stem
    assert callable(tool["handler"])
    assert tool["parameters"].get("type") == "OBJECT"
    assert tool.get("risk") in {None, "safe", "review", "destructive", "autonomous"}


@pytest.mark.parametrize("stem", NEW_ACTIONS)
def test_handler_empty_params_uses_outcome(stem):
    mod = importlib.import_module(f"actions.{stem}")
    result = mod.TOOL["handler"](parameters={})
    assert isinstance(result, str) and result
    assert any(k in result for k in OUTCOME_KEYS), result[:160]


def test_routine_list_and_create(tmp_path, monkeypatch):
    import actions._routine_orchestrator_impl as impl
    monkeypatch.setattr(impl, "_ROUTINES", tmp_path / "routines.json")
    r = impl.run({"action": "list"})
    assert "status=done" in r
    r2 = impl.run({
        "action": "create",
        "name": "demo",
        "steps": [{"tool": "clipboard", "params": {"mode": "basic"}, "speak": "ok"}],
    })
    assert "status=done" in r2
    r3 = impl.run({"action": "get", "name": "demo"})
    assert "status=done" in r3 and "demo" in r3


def test_local_doc_rag_read(tmp_path):
    import actions._local_doc_rag_impl as impl
    doc = tmp_path / "note.txt"
    doc.write_text("Hello JARVIS. Second sentence about quantum.", encoding="utf-8")
    r = impl.run({"action": "read", "path": str(doc)})
    assert "status=done" in r
    r2 = impl.run({"action": "summarize", "path": str(doc)})
    assert "status=done" in r2
    r3 = impl.run({"action": "search", "path": str(doc), "query": "quantum"})
    assert "status=done" in r3


def test_window_workspace_list(tmp_path, monkeypatch):
    import actions._window_workspace_saver_impl as impl
    monkeypatch.setattr(impl, "_STORE", tmp_path / "ws.json")
    r = impl.run({"action": "list"})
    assert "status=done" in r


def test_intruder_status_and_stop():
    import actions._intruder_alert_impl as impl
    r = impl.run({"action": "status"})
    assert "status=done" in r
    r2 = impl.run({"action": "stop"})
    assert "status=done" in r2


def test_secure_vault_asks_for_key(monkeypatch):
    import actions._secure_vault_helper_impl as impl
    monkeypatch.setattr(impl, "_owner_ok", lambda player=None: (True, "ok"))
    r = impl.run({"action": "get"})
    assert "status=ask" in r


def test_secure_vault_owner_denied(monkeypatch):
    import actions._secure_vault_helper_impl as impl
    monkeypatch.setattr(impl, "_owner_ok", lambda player=None: (False, "denied"))
    r = impl.run({"action": "get", "key": "openai"})
    assert "status=failed" in r


def test_meeting_status():
    import actions._meeting_transcriber_impl as impl
    r = impl.run({"action": "status"})
    assert "status=done" in r


def test_voice_threshold_still_075():
    from core import voice_auth
    assert voice_auth._DEFAULT_THRESHOLD == 0.75
