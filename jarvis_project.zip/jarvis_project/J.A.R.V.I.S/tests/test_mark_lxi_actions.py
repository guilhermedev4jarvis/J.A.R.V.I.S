"""MARK LXI identity + screen_context_advisor + git_voice_copilot tests."""
from __future__ import annotations

import base64
import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def test_product_identity_mark_lxi():
    from core.product import PRODUCT_NAME, ARMOR_MARK, FULL_TITLE
    assert PRODUCT_NAME == "J.A.R.V.I.S."
    assert "LXI" in ARMOR_MARK
    assert "LXI" in FULL_TITLE

    ui = (ROOT / "ui.py").read_text(encoding="utf-8")
    assert 'APP_NAME     = "J.A.R.V.I.S."' in ui or 'APP_NAME = "J.A.R.V.I.S."' in ui.replace(" ", "")
    assert "MARK LXI" in ui

    html = (ROOT / "dashboard" / "static" / "app.html").read_text(encoding="utf-8")
    assert "MARK LXI" in html or "J.A.R.V.I.S" in html

    prompt = (ROOT / "core" / "prompt.txt").read_text(encoding="utf-8")
    assert "screen_context_advisor" in prompt
    assert "git_voice_copilot" in prompt


def test_screen_context_tool_contract():
    from actions.screen_context_advisor import TOOL
    assert TOOL["name"] == "screen_context_advisor"
    assert callable(TOOL["handler"])
    r = TOOL["handler"](parameters={})
    assert "status=ask" in r


def test_screen_context_offline_fallback(monkeypatch):
    from actions import _screen_context_advisor_impl as impl

    # tiny 1x1 png
    png = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
    )
    monkeypatch.setattr(impl, "_capture_png", lambda region="full": png)

    def boom(*a, **k):
        raise RuntimeError("offline: no Gemini API key")

    monkeypatch.setattr(impl, "_gemini_vision", boom)
    r = impl.run({"question": "O que tem na tela?", "image_base64": base64.b64encode(png).decode()})
    assert "status=unverified" in r or "status=failed" in r


def test_screen_context_mock_success(monkeypatch):
    from actions import _screen_context_advisor_impl as impl
    png = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
    )
    monkeypatch.setattr(impl, "_gemini_vision", lambda q, b: "Vejo um botao Export no canto superior direito.")
    r = impl.run({"question": "Onde exporto?", "image_base64": base64.b64encode(png).decode()})
    assert "status=done" in r
    assert "Export" in r


def test_git_tool_contract():
    from actions.git_voice_copilot import TOOL
    assert TOOL["name"] == "git_voice_copilot"
    assert callable(TOOL["handler"])


def test_git_status_summary(tmp_path):
    from actions import _git_voice_copilot_impl as impl
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=repo, check=True, capture_output=True)
    (repo / "a.txt").write_text("hello\n", encoding="utf-8")
    subprocess.run(["git", "add", "a.txt"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=repo, check=True, capture_output=True)
    (repo / "a.txt").write_text("hello\nworld\n", encoding="utf-8")
    r = impl.run({"action": "status_summary", "path": str(repo)})
    assert "status=done" in r
    assert "Branch" in r or "branch=" in r.lower() or "modific" in r.lower() or "changes=" in r


def test_git_smart_commit_owner_gate(tmp_path, monkeypatch):
    from actions import _git_voice_copilot_impl as impl
    repo = tmp_path / "repo2"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=repo, check=True, capture_output=True)
    (repo / "b.txt").write_text("x\n", encoding="utf-8")
    subprocess.run(["git", "add", "b.txt"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=repo, check=True, capture_output=True)
    (repo / "b.txt").write_text("x\ny\n", encoding="utf-8")

    monkeypatch.setattr(impl, "_owner_ok", lambda action: (False, "denied"))
    r = impl.run({"action": "smart_commit", "path": str(repo)})
    assert "status=failed" in r
    assert "owner_gate" in r

    monkeypatch.setattr(impl, "_owner_ok", lambda action: (True, "ok"))
    monkeypatch.setattr(impl, "_llm_explain", lambda diff, mode="explain": "chore: test commit")
    r2 = impl.run({"action": "smart_commit", "path": str(repo), "message": "chore: test commit"})
    assert "status=done" in r2


def test_git_push_blocked_without_gate(tmp_path, monkeypatch):
    from actions import _git_voice_copilot_impl as impl
    repo = tmp_path / "repo3"
    repo.mkdir()
    subprocess.run(["git", "init"], cwd=repo, check=True, capture_output=True)
    monkeypatch.setattr(impl, "_owner_ok", lambda action: (False, "denied"))
    # still needs valid repo top-level - commit first optional; resolve works after init
    r = impl.run({"action": "push", "path": str(repo)})
    assert "status=failed" in r


def test_api_key_preserved():
    assert "YOUR_API_KEY_HERE" in (ROOT / ".env").read_text(encoding="utf-8")
    assert "YOUR_API_KEY_HERE" in (ROOT / "config" / "api_keys.json").read_text(encoding="utf-8")


def test_voice_threshold():
    from core import voice_auth
    assert voice_auth._DEFAULT_THRESHOLD == 0.75
