"""Tests for MARK LXI autonomous pack: context_triggers, screen_memory, webhook_bridge."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from actions import _context_triggers_impl as ct
from actions import _screen_memory_timeline_impl as sm
from actions import _webhook_bridge_impl as wh
from actions.context_triggers import TOOL as CT_TOOL
from actions.screen_memory_timeline import TOOL as SM_TOOL
from actions.webhook_bridge import TOOL as WH_TOOL


@pytest.fixture(autouse=True)
def _iso(tmp_path, monkeypatch):
    monkeypatch.setattr(ct, "_CFG", tmp_path / "context_triggers.json")
    monkeypatch.setattr(sm, "_DB", tmp_path / "screen_timeline.db")
    monkeypatch.setattr(wh, "_CFG", tmp_path / "webhooks.json")
    (tmp_path / "context_triggers.json").write_text(
        json.dumps({"version": 1, "enabled": True, "rules": []}), encoding="utf-8"
    )
    (tmp_path / "webhooks.json").write_text(
        json.dumps({"version": 1, "endpoints": {}}), encoding="utf-8"
    )
    yield


def test_tool_contracts():
    for tool, name in ((CT_TOOL, "context_triggers"), (SM_TOOL, "screen_memory_timeline"), (WH_TOOL, "webhook_bridge")):
        assert tool["name"] == name
        assert tool["parameters"]["type"] == "OBJECT"
        assert callable(tool["handler"])


def test_context_add_list_evaluate(monkeypatch):
    fired = []

    def fake_fire(action, player=None):
        fired.append(action)
        return "status=done action=routine_orchestrator"

    monkeypatch.setattr(ct, "_fire_action", fake_fire)

    r = ct.run({
        "action": "add",
        "name": "obs_stream",
        "condition_type": "app_opened",
        "app": "obs64.exe",
        "fire_kind": "routine",
        "fire_name": "modo_stream",
    })
    assert "status=done" in r and "op=add" in r

    r2 = ct.run({"action": "list"})
    assert "status=done" in r2 and "obs_stream" in r2

    r3 = ct.run({
        "action": "evaluate_now",
        "opened_apps": ["obs64.exe"],
        "dry_run": "false",
    })
    assert "status=done" in r3
    assert "matched=1" in r3
    assert len(fired) == 1

    r4 = ct.run({
        "action": "evaluate_now",
        "opened_apps": ["chrome.exe"],
    })
    assert "matched=0" in r4


def test_context_battery_rule(monkeypatch):
    monkeypatch.setattr(ct, "_fire_action", lambda *a, **k: "status=done")
    ct.run({
        "action": "add",
        "name": "low_bat",
        "condition_type": "battery_below",
        "percent": 20,
        "fire_kind": "tool",
        "fire_name": "power_profile_manager",
    })
    r = ct.run({"action": "evaluate_now", "battery": 15})
    assert "matched=1" in r
    r2 = ct.run({"action": "evaluate_now", "battery": 50})
    assert "matched=0" in r2


def test_screen_capture_redaction_and_search():
    secret = "AQ.YOUR_API_KEY_HERE"
    r = sm.run({
        "action": "capture_now",
        "title": "Terminal",
        "text": f"error stack api_key={secret} boom",
    })
    assert "status=done" in r

    # stored text must be redacted
    rows = sm.recent(limit=1)
    assert rows
    assert secret not in (rows[0].get("snippet") or "")
    assert secret not in (rows[0].get("window_title") or "")

    r2 = sm.run({"action": "search", "query": "error stack"})
    assert "status=done" in r2 and "hits=" in r2


def test_screen_clear_owner_gate(monkeypatch):
    sm.capture_now(title="x", text="y")
    monkeypatch.setattr(sm, "_owner_ok", lambda: (False, "denied"))
    r = sm.run({"action": "clear"})
    assert "status=failed" in r
    monkeypatch.setattr(sm, "_owner_ok", lambda: (True, "ok"))
    r2 = sm.run({"action": "clear"})
    assert "status=done" in r2


def test_webhook_register_list_trigger_mock(monkeypatch):
    monkeypatch.setattr(wh, "_owner_ok", lambda name: (True, "ok"))
    # validate_url: allow example.com
    r = wh.run({
        "action": "register",
        "name": "alerta_celular",
        "url": "https://example.com/hook",
        "method": "POST",
        "body_template": "{\"text\":\"{{message}}\"}",
        "requires_owner_gate": "true",
    })
    assert "status=done" in r

    r2 = wh.run({"action": "list"})
    assert "alerta_celular" in r2

    calls = []

    def fake_http(method, url, headers, body, timeout=15.0):
        calls.append({"method": method, "url": url, "body": body})
        return 200, "ok"

    r3 = wh.run({
        "action": "trigger",
        "name": "alerta_celular",
        "message": "bateria baixa",
        "_http_fn": fake_http,
    })
    assert "status=done" in r3
    assert calls and "bateria baixa" in calls[0]["body"]


def test_webhook_owner_gate_blocks(monkeypatch):
    monkeypatch.setattr(wh, "_owner_ok", lambda name: (False, "denied"))
    monkeypatch.setattr(wh, "_validate_url", lambda *a, **k: (True, "ok"))
    # seed endpoint
    data = {"version": 1, "endpoints": {
        "x": {
            "url": "https://example.com/h",
            "method": "POST",
            "headers": {},
            "body_template": "{{message}}",
            "requires_owner_gate": True,
        }
    }}
    wh._CFG.write_text(json.dumps(data), encoding="utf-8")
    r = wh.run({"action": "trigger", "name": "x", "message": "hi"})
    assert "status=failed" in r and "owner_gate" in r


def test_webhook_blocks_private_ip(monkeypatch):
    monkeypatch.setattr(wh, "_owner_ok", lambda name: (True, "ok"))
    r = wh.run({
        "action": "register",
        "name": "evil",
        "url": "http://127.0.0.1:8080/x",
    })
    assert "status=failed" in r


def test_api_key_still_present():
    env = (ROOT / ".env").read_text(encoding="utf-8")
    assert "YOUR_API_KEY_HERE" in env
    cfg = json.loads((ROOT / "config" / "api_keys.json").read_text(encoding="utf-8"))
    assert "YOUR_API_KEY_HERE" in str(cfg.get("gemini_api_key") or "")


def test_voice_threshold_still_075():
    from core import voice_auth
    assert voice_auth._DEFAULT_THRESHOLD == 0.75
