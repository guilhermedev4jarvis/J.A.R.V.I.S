"""Product identity — single source of truth for name and armor mark."""
from __future__ import annotations

PRODUCT_NAME = "J.A.R.V.I.S."
ARMOR_MARK = "MARK LXI (61)"
FULL_TITLE = f"{PRODUCT_NAME} ({ARMOR_MARK})"
DEFAULT_ASSISTANT_NAME = PRODUCT_NAME
APP_PROTOCOL = "LXI"
BUILD_NUMBER = 61
