"""
core/boot_biometrics.py — strict startup biometrics protocol.

Order (always last in boot, after actions/plugins/providers):
  1. Ensure memory/biometrics has vozdono.mp3 + fotobase1..3.jpg
     → if missing: interactive first-run enrollment
  2. Face verify (camera) — TTS: "Começando biometria facial."
  3. Only if face OK → voice verify — TTS: "Começando biometria de voz."
  4. Any failure / cancel → audit + hard process exit (os._exit(1))
     (UI may offer "Tentar Novamente" before the hard exit path)

Env escape for automated tests only:
  MARK_BIOMETRICS_TEST_MODE=1  → functions return without killing the process
  MARK_SKIP_BIOMETRICS=1       → skip entirely (CI)
"""
from __future__ import annotations

import os
import sys
import time
import wave
from pathlib import Path
from typing import Any, Callable, Optional

_BASE = Path(__file__).resolve().parents[1]
_BIO = _BASE / "memory" / "biometrics"

VOICE_FILE = _BIO / "vozdono.mp3"
FACE_FILES = (
    _BIO / "fotobase1.jpg",
    _BIO / "fotobase2.jpg",
    _BIO / "fotobase3.jpg",
)

FACE_TTS = "Começando biometria facial."
VOICE_TTS = "Começando biometria de voz."
WELCOME_TTS = "Acesso liberado. Bem-vindo."

LogFn = Callable[[str], None]
# UI callback: phase in {"face","voice","done","failed"}, status text, progress 0..1
UiPhaseFn = Callable[[str, str, float], None]


def required_files() -> dict[str, bool]:
    return {
        "vozdono.mp3": VOICE_FILE.is_file(),
        "fotobase1.jpg": FACE_FILES[0].is_file(),
        "fotobase2.jpg": FACE_FILES[1].is_file(),
        "fotobase3.jpg": FACE_FILES[2].is_file(),
    }


def all_present() -> bool:
    return all(required_files().values())


def _log(msg: str, ui: Any = None, log: Optional[LogFn] = None) -> None:
    line = f"[BIOMETRIA] {msg}"
    print(line)
    if log:
        try:
            log(line)
        except Exception:
            pass
    if ui is not None:
        try:
            ui.write_log("SYS: " + msg)
        except Exception:
            pass


def _ui_phase(ui: Any, phase: str, status: str, progress: float = 0.0) -> None:
    """Push phase/status to optional biometric overlay on the UI."""
    if ui is None:
        return
    for name in ("set_biometrics_phase", "update_biometrics", "on_biometrics_phase"):
        fn = getattr(ui, name, None)
        if callable(fn):
            try:
                fn(phase, status, float(progress))
                return
            except TypeError:
                try:
                    fn(phase, status)
                    return
                except Exception:
                    pass
            except Exception:
                pass


def _audit(event: str, detail: dict[str, Any]) -> None:
    try:
        from core import audit
        audit.log_event(event, detail)
    except Exception:
        pass


def hard_exit(reason: str, *, ui: Any = None, code: int = 1) -> None:
    """Kill the process and try to close the console window."""
    _log(f"BLOQUEADO: {reason} — encerrando.", ui=ui)
    _ui_phase(ui, "failed", f"Bloqueado: {reason}", 0.0)
    _audit("boot_biometrics_denied", {"reason": reason, "code": code})
    if os.environ.get("MARK_BIOMETRICS_TEST_MODE") == "1":
        raise SystemExit(code)
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            import ctypes
            hwnd = ctypes.windll.kernel32.GetConsoleWindow()
            if hwnd:
                ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
                time.sleep(0.15)
        except Exception:
            pass
    os._exit(code)


def _speak_blocking(text: str, *, ui: Any = None, log: Optional[LogFn] = None) -> None:
    """Speak exact phrase via core.tts if available; never fails the boot."""
    _log(f'TTS: "{text}"', ui=ui, log=log)
    if os.environ.get("MARK_BIOMETRICS_TEST_MODE") == "1":
        return
    try:
        from core import tts as tts_mod
        # Prefer a lightweight edge path when config is unavailable
        cfg = {}
        try:
            import json
            cfg_path = _BASE / "config" / "api_keys.json"
            if cfg_path.is_file():
                cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        except Exception:
            cfg = {}
        player = tts_mod.create_tts_player(cfg if isinstance(cfg, dict) else {})
        player.speak(text)
    except Exception as e:
        _log(f"TTS indisponível ({e}) — seguindo sem áudio.", ui=ui, log=log)


def _record_wav(path: Path, seconds: float = 3.0, sr: int = 16000) -> Path:
    """Record mono WAV from default mic via sounddevice."""
    import numpy as np
    import sounddevice as sd

    path.parent.mkdir(parents=True, exist_ok=True)
    frames = int(seconds * sr)
    audio = sd.rec(frames, samplerate=sr, channels=1, dtype="float32")
    sd.wait()
    pcm = np.clip(audio.reshape(-1) * 32767.0, -32768, 32767).astype(np.int16)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(pcm.tobytes())
    return path


def _wait_ui_retry(ui: Any, reason: str, *, log: Optional[LogFn] = None) -> bool:
    """If UI exposes wait_biometrics_retry, block until user clicks retry or cancel.
    Returns True to retry, False to abort. Without UI → no retry.
    """
    fn = getattr(ui, "wait_biometrics_retry", None) if ui is not None else None
    if not callable(fn):
        return False
    try:
        return bool(fn(reason))
    except Exception as e:
        _log(f"retry UI falhou: {e}", ui=ui, log=log)
        return False


def run_first_enrollment(*, ui: Any = None, log: Optional[LogFn] = None) -> None:
    """Capture 3 face bases + owner voice command into memory/biometrics/."""
    from core import owner_gate
    from core import face_auth

    _BIO.mkdir(parents=True, exist_ok=True)
    _log("Primeira execução — cadastro biométrico obrigatório.", ui=ui, log=log)
    _ui_phase(ui, "face", "Cadastro biométrico — posicione o rosto", 0.05)

    phrase = os.environ.get("MARK_OWNER_PHRASE", "").strip() or "ok jarvis"
    try:
        if ui is not None and hasattr(ui, "ask_text"):
            phrase = ui.ask_text("Frase de comando do dono:", default=phrase) or phrase
    except Exception:
        pass
    owner_gate.save_command_phrase(phrase)
    _log(f"Frase salva: {phrase!r}", ui=ui, log=log)

    labels = ("frente", "lado esquerdo", "lado direito")
    for slot, label in enumerate(labels, start=1):
        _log(f"Foto {slot}/3 ({label}) — olhe para a câmera…", ui=ui, log=log)
        _ui_phase(ui, "face", f"Cadastro facial {slot}/3 ({label})", slot / 4.0)
        try:
            time.sleep(0.8)
            frame = face_auth.capture_from_camera()
            import cv2
            dest = FACE_FILES[slot - 1]
            cv2.imwrite(str(dest), frame)
            owner_gate.register_face_slot(slot, dest)
            _log(f"fotobase{slot}.jpg salvo.", ui=ui, log=log)
        except Exception as e:
            hard_exit(f"falha no cadastro facial slot={slot}: {e}", ui=ui)

    _log(f"Grave a voz dizendo {phrase!r} (3s)…", ui=ui, log=log)
    _ui_phase(ui, "voice", f'Diga: "{phrase}"', 0.85)
    try:
        time.sleep(0.5)
        wav = _BIO / "_enroll_voice.wav"
        _record_wav(wav, seconds=3.0)
        owner_gate.register_voice_file(wav, phrase=phrase)
        import shutil
        if wav.is_file():
            shutil.copy2(wav, _BIO / "vozdono.wav")
            if not VOICE_FILE.is_file():
                shutil.copy2(wav, VOICE_FILE)
        _log("vozdono gravado e fingerprint criado.", ui=ui, log=log)
    except Exception as e:
        hard_exit(f"falha no cadastro de voz: {e}", ui=ui)

    if not all_present():
        missing = [k for k, ok in required_files().items() if not ok]
        hard_exit(f"cadastro incompleto — faltam: {missing}", ui=ui)
    _log("Cadastro biométrico concluído.", ui=ui, log=log)


def authenticate(
    *,
    ui: Any = None,
    log: Optional[LogFn] = None,
    max_retries: int = 2,
) -> None:
    """Strict face → voice with TTS announcements and optional UI overlay.

    Sequence:
      1) TTS FACE_TTS → camera verify (status: Analisando rosto…)
      2) on success → TTS VOICE_TTS → mic verify (status: Ouvindo assinatura vocal…)
      3) on success → TTS WELCOME_TTS → phase done
    Failures offer UI retry (if available) up to max_retries, then hard_exit.
    """
    from core import face_auth
    from core import voice_auth
    from core import owner_gate

    attempts = 0
    while True:
        attempts += 1
        # ── Etapa 1: Facial ──────────────────────────────────────────────
        _speak_blocking(FACE_TTS, ui=ui, log=log)
        _log("Autenticação facial…", ui=ui, log=log)
        _ui_phase(ui, "face", "Analisando rosto...", 0.15)
        try:
            # Optional live camera stream on UI
            start_cam = getattr(ui, "start_camera_stream", None) if ui else None
            if callable(start_cam):
                try:
                    start_cam()
                except Exception:
                    pass
            face = face_auth.verify_from_camera()
            _audit("boot_face_check", {"accepted": face.accepted, "score": face.score})
            stop_cam = getattr(ui, "stop_camera_stream", None) if ui else None
            if callable(stop_cam):
                try:
                    stop_cam()
                except Exception:
                    pass
            if not face.accepted:
                reason = (
                    f"rosto não reconhecido (score={face.score:.3f}, thr={face.threshold})"
                )
                _ui_phase(ui, "failed", "Biometria facial recusada", 0.0)
                if attempts <= max_retries and _wait_ui_retry(ui, reason, log=log):
                    continue
                hard_exit(reason, ui=ui)
        except Exception as e:
            stop_cam = getattr(ui, "stop_camera_stream", None) if ui else None
            if callable(stop_cam):
                try:
                    stop_cam()
                except Exception:
                    pass
            reason = f"erro na biometria facial: {e}"
            _ui_phase(ui, "failed", str(e), 0.0)
            if attempts <= max_retries and _wait_ui_retry(ui, reason, log=log):
                continue
            hard_exit(reason, ui=ui)

        _ui_phase(ui, "face", "Biometria facial aprovada", 0.55)
        _log("Rosto OK.", ui=ui, log=log)

        # ── Etapa 2: Voz (só após facial OK) ─────────────────────────────
        _speak_blocking(VOICE_TTS, ui=ui, log=log)
        # Aguarda o TTS terminar antes de abrir o microfone (já é blocking)
        try:
            phrase = (owner_gate.load_command_phrase() or {}).get("phrase") or "ok jarvis"
        except Exception:
            phrase = "ok jarvis"
        _log(f"Autenticação de voz — diga: {phrase!r} (3s)…", ui=ui, log=log)
        _ui_phase(ui, "voice", "Ouvindo assinatura vocal...", 0.7)
        try:
            try:
                owner_gate.ensure_voice_wav()
            except Exception:
                pass
            probe = _BIO / "_probe_voice.wav"
            _record_wav(probe, seconds=3.0)
            result = voice_auth.verify_wav(probe)
            _audit("boot_voice_check", {"accepted": result.accepted, "score": result.score})
            if not result.accepted:
                reason = (
                    f"voz não reconhecida (score={result.score:.3f}, thr={result.threshold})"
                )
                _ui_phase(ui, "failed", "Biometria de voz recusada", 0.0)
                if attempts <= max_retries and _wait_ui_retry(ui, reason, log=log):
                    continue
                hard_exit(reason, ui=ui)
        except Exception as e:
            reason = f"erro na biometria de voz: {e}"
            _ui_phase(ui, "failed", str(e), 0.0)
            if attempts <= max_retries and _wait_ui_retry(ui, reason, log=log):
                continue
            hard_exit(reason, ui=ui)

        # ── Sucesso ──────────────────────────────────────────────────────
        _ui_phase(ui, "done", "Acesso liberado", 1.0)
        _log("Biometria OK — acesso liberado.", ui=ui, log=log)
        _audit("boot_biometrics_ok", {"ts": time.time()})
        _speak_blocking(WELCOME_TTS, ui=ui, log=log)
        try:
            from core.owner_gate import touch_activity
            touch_activity()
        except Exception:
            pass
        return


def enforce_startup_biometrics(*, ui: Any = None, log: Optional[LogFn] = None) -> None:
    """
    Public entry — call as the LAST step of boot after actions/plugins load.
    Shows biometric overlay on UI when available.
    """
    if os.environ.get("MARK_SKIP_BIOMETRICS") == "1":
        _log("MARK_SKIP_BIOMETRICS=1 — protocolo ignorado (CI).", ui=ui, log=log)
        return

    show = getattr(ui, "show_biometrics_overlay", None) if ui is not None else None
    if callable(show):
        try:
            show()
        except Exception:
            pass

    try:
        if not all_present():
            status = required_files()
            _log(f"Arquivos biométricos: {status}", ui=ui, log=log)
            run_first_enrollment(ui=ui, log=log)
        authenticate(ui=ui, log=log)
    except SystemExit:
        raise
    except Exception as e:
        hard_exit(f"falha inesperada no protocolo biométrico: {e}", ui=ui)
    finally:
        hide = getattr(ui, "hide_biometrics_overlay", None) if ui is not None else None
        if callable(hide):
            try:
                hide()
            except Exception:
                pass
