"""
core/secrets.py — load secrets from environment / .env, then config/api_keys.json.

Priority (highest first):
  1. Process environment variables
  2. Project-root `.env` (via python-dotenv, if installed)
  3. config/api_keys.json  (non-secret UI settings still live here)

Never commit real keys. Use `.env.example` and `config/api_keys.json.example`
as templates. `.env` and `config/api_keys.json` are git-ignored.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

_dotenv_loaded = False


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = _base_dir()
ENV_FILE = BASE_DIR / ".env"
CONFIG_FILE = BASE_DIR / "config" / "api_keys.json"

# env var name → key inside api_keys.json / load_api_keys()
# Prefer MARK_* names; also accept common industry aliases.
_ENV_MAP: dict[str, tuple[str, ...]] = {
    "gemini_api_key": (
        "MARK_GEMINI_API_KEY",
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
    ),
    "elevenlabs_api_key": (
        "MARK_ELEVENLABS_API_KEY",
        "ELEVENLABS_API_KEY",
    ),
    "openai_api_key": (
        "MARK_OPENAI_API_KEY",
        "OPENAI_API_KEY",
    ),
    "llm_url": (
        "MARK_LLM_URL",
        "OLLAMA_HOST",
        "OPENAI_BASE_URL",
    ),
    "llm_model": (
        "MARK_LLM_MODEL",
        "OLLAMA_MODEL",
    ),
    "llm_provider": (
        "MARK_LLM_PROVIDER",
    ),
}


def load_dotenv_once() -> None:
    """Load BASE_DIR/.env into os.environ if python-dotenv is available.

    Does not override variables already set in the process environment.
    Safe to call many times.
    """
    global _dotenv_loaded
    if _dotenv_loaded:
        return
    _dotenv_loaded = True
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    if ENV_FILE.is_file():
        load_dotenv(ENV_FILE, override=False)


def _env_get(*names: str) -> str:
    for name in names:
        val = os.environ.get(name)
        if val is not None and str(val).strip() != "":
            return str(val).strip()
    return ""


def read_json_config() -> dict[str, Any]:
    """Raw api_keys.json only (no env overlay)."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[secrets] Failed to load api_keys.json: {e}")
        return {}


def apply_env_secrets(data: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return a copy of config with secret fields overridden by env / .env."""
    load_dotenv_once()
    out = dict(data or read_json_config())
    for json_key, env_names in _ENV_MAP.items():
        val = _env_get(*env_names)
        if val:
            out[json_key] = val
    return out


def get_secret(json_key: str, default: str = "") -> str:
    """One secret by api_keys.json field name, with env priority."""
    load_dotenv_once()
    env_names = _ENV_MAP.get(json_key)
    if env_names:
        val = _env_get(*env_names)
        if val:
            return val
    data = read_json_config()
    return str(data.get(json_key) or default).strip()


def gemini_api_key() -> str:
    return get_secret("gemini_api_key")


def elevenlabs_api_key() -> str:
    return get_secret("elevenlabs_api_key")
