"""
core/face_auth.py — local face unlock via camera snapshot.

Approach
--------
1. Enrollment: capture a frame (or load an image), detect the largest face,
   store a compact embedding under memory/biometrics/face_profile.json.
2. Verification: new frame → same embedding → cosine similarity.

Detector / embedder priority
----------------------------
a) OpenCV Haar cascade + LBPH-like histogram embedding (always available if
   opencv-python is installed — already in requirements.txt).
b) If `face_recognition` (dlib) is installed, use 128-d encodings instead.

No images of the user leave the machine. Raw enrollment photos are optional
and stored only if save_image=True.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Tuple

import numpy as np

_BASE = Path(__file__).resolve().parents[1]
_BIO_DIR = _BASE / "memory" / "biometrics"
_PROFILE = _BIO_DIR / "face_profile.json"
_DEFAULT_THRESHOLD = 0.82


@dataclass
class FaceScore:
    score: float
    accepted: bool
    threshold: float
    detail: str


def _ensure_dir() -> None:
    _BIO_DIR.mkdir(parents=True, exist_ok=True)


def _has_cv2() -> bool:
    try:
        import cv2  # noqa: F401
        return True
    except Exception:
        return False


def _has_face_recognition() -> bool:
    try:
        import face_recognition  # noqa: F401
        return True
    except Exception:
        return False


def _read_image(path: str | Path) -> np.ndarray:
    import cv2
    img = cv2.imread(str(path))
    if img is None:
        raise FileNotFoundError(f"cannot read image: {path}")
    return img


def _detect_face_bgr(img: np.ndarray) -> Optional[Tuple[int, int, int, int]]:
    """Return (x, y, w, h) of largest face or None."""
    import cv2
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    cascade = cv2.CascadeClassifier(cascade_path)
    faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))
    if len(faces) == 0:
        return None
    # largest area
    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
    return int(x), int(y), int(w), int(h)


def _embed_hist(img: np.ndarray, box: Tuple[int, int, int, int]) -> np.ndarray:
    """Simple robust embedding: grayscale resize + histogram + edges."""
    import cv2
    x, y, w, h = box
    face = img[y:y + h, x:x + w]
    gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, (64, 64))
    hist = cv2.calcHist([gray], [0], None, [32], [0, 256]).flatten()
    hist = hist / (hist.sum() + 1e-9)
    edges = cv2.Canny(gray, 80, 160)
    edge_hist = cv2.calcHist([edges], [0], None, [16], [0, 256]).flatten()
    edge_hist = edge_hist / (edge_hist.sum() + 1e-9)
    vec = np.concatenate([hist, edge_hist]).astype(np.float32)
    vec /= (np.linalg.norm(vec) + 1e-9)
    return vec


def _embed_dlib(img: np.ndarray) -> Optional[np.ndarray]:
    import face_recognition
    rgb = img[:, :, ::-1]
    locs = face_recognition.face_locations(rgb)
    if not locs:
        return None
    encs = face_recognition.face_encodings(rgb, known_face_locations=locs[:1])
    if not encs:
        return None
    vec = np.asarray(encs[0], dtype=np.float32)
    vec /= (np.linalg.norm(vec) + 1e-9)
    return vec


def _embed_image(img: np.ndarray, *, allow_fullframe: bool = False) -> tuple[np.ndarray, str]:
    if _has_face_recognition():
        vec = _embed_dlib(img)
        if vec is not None:
            return vec, "face_recognition"
    if not _has_cv2():
        raise RuntimeError("opencv-python is required for face_auth")
    box = _detect_face_bgr(img)
    if box is None:
        if not allow_fullframe:
            raise RuntimeError("no face detected in image")
        # Fallback for controlled tests / unusual lighting: whole frame histogram.
        h, w = img.shape[:2]
        box = (0, 0, w, h)
        return _embed_hist(img, box), "opencv_hist_fullframe"
    return _embed_hist(img, box), "opencv_hist"


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.dot(a, b) / ((np.linalg.norm(a) + 1e-9) * (np.linalg.norm(b) + 1e-9)))


def enroll_from_image(path: str | Path, *, label: str = "owner") -> dict[str, Any]:
    path = Path(path)
    img = _read_image(path)
    vec, method = _embed_image(img)
    _ensure_dir()
    profile = {
        "label": label,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "method": method,
        "dim": int(vec.size),
        "vector": vec.tolist(),
        "threshold": _DEFAULT_THRESHOLD,
        "source": path.name,
    }
    _PROFILE.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    return {
        "enrolled": True,
        "label": label,
        "method": method,
        "dim": profile["dim"],
        "path": str(_PROFILE),
    }


def has_profile() -> bool:
    return _PROFILE.is_file()


def load_profile() -> Optional[dict]:
    if not _PROFILE.is_file():
        return None
    try:
        return json.loads(_PROFILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def verify_image(path: str | Path, *, threshold: Optional[float] = None) -> FaceScore:
    profile = load_profile()
    if not profile or not profile.get("vector"):
        return FaceScore(0.0, False, _DEFAULT_THRESHOLD, "no_profile")
    thr = float(threshold if threshold is not None else profile.get("threshold", _DEFAULT_THRESHOLD))
    img = _read_image(path)
    try:
        vec, method = _embed_image(img)
    except Exception as e:
        return FaceScore(0.0, False, thr, f"embed_failed: {e}")
    ref = np.asarray(profile["vector"], dtype=np.float32)
    if ref.shape != vec.shape:
        return FaceScore(0.0, False, thr, f"dim_mismatch profile={ref.shape} probe={vec.shape} method={method}")
    score = _cosine(ref, vec)
    ok = score >= thr
    return FaceScore(score, ok, thr, "match" if ok else "below_threshold")


def capture_from_camera(index: int = 0, settle_frames: int = 8) -> np.ndarray:
    """Grab a single BGR frame from the default webcam."""
    import cv2
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"cannot open camera index={index}")
    try:
        frame = None
        for _ in range(max(1, settle_frames)):
            ok, frame = cap.read()
            if not ok:
                raise RuntimeError("camera read failed")
        assert frame is not None
        return frame
    finally:
        cap.release()


def enroll_from_camera(index: int = 0, *, label: str = "owner") -> dict[str, Any]:
    frame = capture_from_camera(index)
    tmp = _BIO_DIR / "_enroll_face.jpg"
    _ensure_dir()
    import cv2
    cv2.imwrite(str(tmp), frame)
    try:
        return enroll_from_image(tmp, label=label)
    finally:
        if tmp.is_file():
            tmp.unlink(missing_ok=True)


def verify_from_camera(index: int = 0, *, threshold: Optional[float] = None) -> FaceScore:
    frame = capture_from_camera(index)
    tmp = _BIO_DIR / "_probe_face.jpg"
    _ensure_dir()
    import cv2
    cv2.imwrite(str(tmp), frame)
    try:
        return verify_image(tmp, threshold=threshold)
    finally:
        if tmp.is_file():
            tmp.unlink(missing_ok=True)


def clear_profile() -> bool:
    if _PROFILE.is_file():
        _PROFILE.unlink()
        return True
    return False
