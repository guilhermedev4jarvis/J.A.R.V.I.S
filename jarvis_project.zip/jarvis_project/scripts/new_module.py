#!/usr/bin/env python3
"""Scaffold a new action or plugin with the correct TOOL/PLUGIN contract.

Examples:
  python scripts/new_module.py action weather_now
  python scripts/new_module.py plugin stock_quote --desc "Cotação de ação"
  python scripts/new_module.py action my_tool --risk safe
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

ACTION_TEMPLATE = '''"""
{name} — {description}
"""
from __future__ import annotations

from core.outcome import done, failed, ask


def {name}(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {{}}
    action = str(params.get("action") or "run").strip().lower()

    if action in ("status", "help"):
        return done("{name}", action="status", note="ready")

    # TODO: implement behaviour
    value = params.get("value") or params.get("query") or ""
    if not value and action == "run":
        return ask("{name}", "what should I do?", hint="pass value=...")

    try:
        result = f"handled {{value!r}}"
        return done("{name}", action=action or "run", result=result)
    except Exception as e:
        return failed("{name}", str(e))


TOOL = {{
    "name": "{name}",
    "description": (
        "{description}"
    ),
    "parameters": {{
        "type": "OBJECT",
        "properties": {{
            "action": {{"type": "STRING", "description": "status | run"}},
            "value": {{"type": "STRING", "description": "Main argument"}},
            "query": {{"type": "STRING", "description": "Alias for value"}},
        }},
        "required": [],
    }},
    "handler": {name},
    "tier": "core",
    "risk": "{risk}",
}}
'''

PLUGIN_TEMPLATE = '''"""
{name} — {description}
"""
from __future__ import annotations


PLUGIN = {{
    "name": "{name}",
    "description": (
        "{description}"
    ),
    "parameters": {{
        "type": "OBJECT",
        "properties": {{
            "query": {{"type": "STRING", "description": "What to process"}},
        }},
        "required": [],
    }},
    # Optional: "risk": "safe" | "review" | "destructive" | "autonomous"
}}


def run(parameters: dict, player=None, session_memory=None) -> str:
    query = (parameters or {{}}).get("query", "")
    try:
        text = f"{name} received: {{query}}"
    except Exception as e:
        return f"status=failed action={name} reason={{e}}"
    if player:
        try:
            player.write_log(f"JARVIS: {{text}}")
        except Exception:
            pass
    return f"status=done action={name} result={{text}}"
'''


def main() -> int:
    p = argparse.ArgumentParser(description="Create a new JARVIS action or plugin")
    p.add_argument("kind", choices=("action", "plugin"))
    p.add_argument("name", help="snake_case identifier")
    p.add_argument("--desc", default="", help="Short description for the model")
    p.add_argument(
        "--risk",
        default="review",
        choices=("safe", "review", "destructive", "autonomous"),
    )
    p.add_argument("-f", "--force", action="store_true", help="overwrite existing file")
    args = p.parse_args()

    name = args.name.strip().lower()
    if not NAME_RE.match(name):
        print(f"Invalid name {name!r} — use snake_case starting with a letter")
        return 1

    desc = args.desc or f"Tool {name} (edit description)"
    if args.kind == "action":
        path = ROOT / "actions" / f"{name}.py"
        body = ACTION_TEMPLATE.format(name=name, description=desc, risk=args.risk)
    else:
        path = ROOT / "plugins" / f"{name}.py"
        body = PLUGIN_TEMPLATE.format(name=name, description=desc)

    if path.exists() and not args.force:
        print(f"Already exists: {path} (use --force to overwrite)")
        return 1

    path.write_text(body, encoding="utf-8")
    print(f"Created {path.relative_to(ROOT)}")
    print("Next:")
    print("  1) Edit the handler / description")
    print("  2) python -c \"from actions.{n} import TOOL\"  # or plugins".format(n=name))
    print("  3) Restart JARVIS or call hot_reload action=actions")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
