"""
code_review_local — git diff / status summary for the current repository.

Does not invent review comments: it gathers facts (status, diff, recent log)
and returns them so the LLM can reason. Works only inside a git repo.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

from core.outcome import done, failed

_HOME = Path.home().resolve()


def _run_git(args: list[str], cwd: Path, timeout: float = 20.0) -> tuple[int, str, str]:
    try:
        r = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", "git is not installed"
    except subprocess.TimeoutExpired:
        return 124, "", "git timed out"
    except Exception as e:
        return 1, "", str(e)


def _find_repo(start: Path) -> Path | None:
    cur = start.resolve()
    for _ in range(12):
        if (cur / ".git").exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


def code_review_local(parameters=None, **_ctx) -> str:
    params = parameters or {}
    path = (params.get("path") or params.get("folder") or ".").strip()
    mode = (params.get("mode") or "summary").strip().lower()  # summary | diff | log

    try:
        root = Path(path).expanduser().resolve()
    except Exception:
        return failed("code_review_local", f"invalid path: {path}")

    # Stay under home unless it's clearly a repo path the user owns
    try:
        root.relative_to(_HOME)
    except ValueError:
        # Allow if it contains .git
        if not (root / ".git").exists() and not _find_repo(root):
            return failed("code_review_local", "path must be under your home directory")

    repo = _find_repo(root)
    if repo is None:
        return failed("code_review_local", "not a git repository", path=str(root))

    code, status, err = _run_git(["status", "--porcelain", "-b"], repo)
    if code != 0:
        return failed("code_review_local", err or "git status failed", path=str(repo))

    branch = "?"
    for line in status.splitlines():
        if line.startswith("## "):
            branch = line[3:].strip()
            break

    changed = [ln for ln in status.splitlines() if ln and not ln.startswith("## ")]
    code2, log, _ = _run_git(["log", "-5", "--oneline"], repo)
    recent = log if code2 == 0 else ""

    diff_text = ""
    if mode in ("diff", "full", "summary"):
        # Prefer staged+unstaged but keep size bounded
        code3, diff_text, _ = _run_git(["diff", "HEAD", "--stat"], repo)
        if mode == "diff":
            code4, full_diff, _ = _run_git(["diff", "HEAD"], repo)
            if code4 == 0:
                if len(full_diff) > 6000:
                    full_diff = full_diff[:6000] + "\n… [diff truncated]"
                diff_text = full_diff

    return done(
        "code_review_local",
        repo=str(repo),
        branch=branch,
        changed_count=len(changed),
        changed_files="; ".join(c[3:] if len(c) > 3 else c for c in changed[:20]) or "(clean)",
        recent_commits=recent.replace("\n", " | ") if recent else "(none)",
        diff_stat=diff_text[:3000] if diff_text else "(no diff)",
        note=(
            "Use these facts to review the changes. "
            "Do not invent files that are not listed."
        ),
    )


TOOL = {
    "name": "code_review_local",
    "description": (
        "Inspects the local git repository (status, branch, changed files, "
        "recent commits, diff). Use when the user asks for a code review, "
        "what changed, or a summary of the current branch. "
        "Modes: summary (default), diff. "
        "The tool only gathers facts — the model writes the actual review."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "path": {
                "type": "STRING",
                "description": "Path inside the repo (default: current/home project).",
            },
            "folder": {"type": "STRING", "description": "Alias for path."},
            "mode": {
                "type": "STRING",
                "description": "summary | diff",
            },
        },
        "required": [],
    },
    "handler": code_review_local,
    "tier": "core",
}
