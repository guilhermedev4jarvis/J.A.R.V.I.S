"""code_review_local — local static review via core.code_engine + optional git facts."""
from __future__ import annotations

import subprocess
from pathlib import Path
from core.code_engine import get_engine
from core.outcome import done, failed, ask


def code_review_local(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "review").strip().lower()
    path = str(params.get("path") or params.get("file") or "").strip()
    engine = get_engine()

    if action in ("status", "help"):
        return done("code_review_local", action="status", engine="core.code_engine")

    if action in ("git_status", "status_git"):
        try:
            proc = subprocess.run(
                ["git", "status", "--short"],
                capture_output=True, text=True, timeout=10,
                cwd=str(Path(path).parent) if path else None,
            )
            return done("code_review_local", action="git_status", output=proc.stdout[:3000])
        except Exception as e:
            return failed("code_review_local", str(e), action="git_status")

    if action in ("git_diff", "diff"):
        try:
            proc = subprocess.run(
                ["git", "diff"],
                capture_output=True, text=True, timeout=15,
                cwd=str(Path(path).parent) if path else None,
            )
            return done("code_review_local", action="git_diff", output=proc.stdout[:8000])
        except Exception as e:
            return failed("code_review_local", str(e), action="git_diff")

    if not path:
        return ask("code_review_local", "path do arquivo?")
    try:
        vr = engine.analyze(path=path)
    except Exception as e:
        return failed("code_review_local", str(e), action="review")
    if vr.ok:
        return done("code_review_local", action="review", path=path, syntax_ok=True)
    return failed("code_review_local", vr.message, action="review", path=path, stderr=vr.stderr[:800])


TOOL = {
    "name": "code_review_local",
    "description": (
        "Review local de codigo (AST/py_compile via code_engine) e fatos git "
        "(status/diff). Acoes: review | git_status | git_diff | status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING"},
            "path": {"type": "STRING"},
            "file": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_review_local,
    "tier": "core",
    "risk": "safe",
}
