"""
code_assist — ferramenta única de código do JARVIS.

Unifica:
  • code_helper        — write/edit/explain/run/build/optimize (multi-lang)
  • dev_agent          — projeto multi-arquivo do zero
  • code_review_local  — git status/diff para review
  • code_forge         — gerador Python + análise + auto-heal em loop

Roteamento:
  action explícita  → subsistema certo
  heurística        → se não houver action, escolhe pelo que veio nos params

Os quatro módulos originais permanecem no disco; este arquivo só orquestra.
"""
from __future__ import annotations

from core.outcome import done, failed, ask

from actions.code_helper import code_helper
from actions.dev_agent import dev_agent
from actions.code_review_local import code_review_local
from actions.code_forge import code_forge


# ── action → (subsystem, mapped action for that subsystem) ────────────────

_ROUTE: dict[str, tuple[str, str | None]] = {
    # forge (Python self-heal)
    "forge": ("forge", "forge"),
    "heal": ("forge", "fix"),
    "fix": ("forge", "fix"),
    "repair": ("forge", "fix"),
    "analyze": ("forge", "analyze"),
    "review_static": ("forge", "analyze"),
    "generate": ("forge", "generate"),
    "forge_run": ("forge", "run"),
    "forge_status": ("forge", "status"),
    # helper
    "write": ("helper", "write"),
    "edit": ("helper", "edit"),
    "explain": ("helper", "explain"),
    "run": ("helper", "run"),          # may re-route to forge if .py + heal intent
    "build": ("helper", "build"),
    "optimize": ("helper", "optimize"),
    "screen_debug": ("helper", "screen_debug"),
    "helper": ("helper", "auto"),
    "auto": ("helper", "auto"),
    # project
    "project": ("project", None),
    "scaffold": ("project", None),
    "dev": ("project", None),
    "dev_agent": ("project", None),
    # git review
    "git": ("git", None),
    "git_review": ("git", None),
    "review": ("git", None),
    "diff": ("git", "diff"),
    "git_status": ("git", "summary"),
    "git_diff": ("git", "diff"),
    # meta
    "status": ("meta", None),
}


def _clip(s: str, n: int = 350) -> str:
    s = (s or "").replace("\n", " ")
    return s if len(s) <= n else s[:n] + "…"


def _tag(result: str, via: str) -> str:
    if not result:
        return failed("code_assist", "empty subsystem result", via=via)
    if result.startswith("status=") and " via=" not in result:
        parts = result.split(" ", 2)
        if len(parts) >= 2:
            return f"{parts[0]} {parts[1]} via={via} " + (parts[2] if len(parts) > 2 else "")
        return result + f" via={via}"
    return result


def _to_helper(params: dict, action: str) -> dict:
    p = dict(params)
    p["action"] = action
    # normalize intent → description
    if not p.get("description") and p.get("intent"):
        p["description"] = p["intent"]
    if not p.get("description") and p.get("prompt"):
        p["description"] = p["prompt"]
    return p


def _to_forge(params: dict, action: str) -> dict:
    p = dict(params)
    p["action"] = action
    if not p.get("intent"):
        p["intent"] = p.get("description") or p.get("prompt") or ""
    if not p.get("file_path"):
        p["file_path"] = p.get("path") or p.get("output_path") or ""
    return p


def _to_git(params: dict, mode: str | None) -> dict:
    p = dict(params)
    if mode:
        p["mode"] = mode
    elif not p.get("mode"):
        # action was "diff" etc.
        pass
    if not p.get("path") and p.get("file_path"):
        p["path"] = p["file_path"]
    return p


def _to_project(params: dict) -> dict:
    p = dict(params)
    if not p.get("description"):
        p["description"] = p.get("intent") or p.get("prompt") or ""
    return p


def _auto_route(params: dict) -> str:
    """Pick subsystem when action is missing/blank."""
    intent = (
        params.get("intent")
        or params.get("description")
        or params.get("prompt")
        or ""
    ).strip()
    file_path = (params.get("file_path") or params.get("path") or params.get("output_path") or "").strip()
    code = (params.get("code") or "").strip()
    language = (params.get("language") or "python").strip().lower()
    project_dir = (params.get("project_dir") or params.get("project") or "").strip()

    low = intent.lower()

    # git cues
    if any(k in low for k in ("git status", "git diff", "code review", "o que mudou", "what changed", "pull request", "branch")):
        return "git"

    # multi-file project cues
    if project_dir or any(
        k in low
        for k in (
            "projeto completo",
            "full project",
            "multi-file",
            "multi file",
            "scaffold",
            "vários arquivos",
            "varios arquivos",
            "create a project",
            "cria um projeto",
            "app flask",
            "django project",
        )
    ):
        return "project"

    # forge cues: python + fix/heal/analyze or complex module
    if file_path.endswith(".py") and any(
        k in low for k in ("corrig", "fix", "heal", "erro", "error", "bug", "traceback", "analis")
    ):
        return "forge"
    if any(k in low for k in ("autocorrig", "self-heal", "até funcionar", "ate funcionar", "forge", "py_compile")):
        return "forge"
    if language in ("python", "py") and intent and any(
        k in low
        for k in (
            "módulo",
            "modulo",
            "classe",
            "class ",
            "api ",
            "script que",
            "implemente",
            "implementa",
            "escreva um",
            "write a",
        )
    ):
        return "forge"

    # default helper (fast write/edit/run)
    if intent or file_path or code:
        return "helper"

    return "ask"


def code_assist(parameters: dict | None = None, **_ctx) -> str:
    params = dict(parameters or {})
    action = (params.get("action") or params.get("mode") or "").strip().lower()

    # dotted form: forge.fix / helper.edit / git.diff
    if "." in action:
        left, right = action.split(".", 1)
        action = f"{left}_{right}" if left in ("forge", "helper", "git", "project") else action
        # also allow forge_fix style already in map
        alt = f"{left}_{right}"
        if alt in _ROUTE:
            action = alt
        elif right in _ROUTE:
            action = right

    # ── meta status ───────────────────────────────────────────────────────
    if action == "status":
        bits = {
            "forge": _clip(code_forge({"action": "status"})),
            "git": _clip(code_review_local({"mode": "summary"})),
        }
        return done(
            "code_assist",
            action="status",
            forge=bits["forge"],
            git=bits["git"],
            note=(
                "Subsystems: forge (Python heal), helper (write/edit/run), "
                "project (multi-file), git (review). "
                "Prefer explicit action=forge|write|edit|project|review."
            ),
        )

    # ── resolve route ─────────────────────────────────────────────────────
    if not action:
        system = _auto_route(params)
        if system == "ask":
            return ask(
                "code_assist",
                "what should I do with the code?",
                options=(
                    "forge (intent=... Python generate+heal) | "
                    "write/edit/run (helper) | "
                    "project (full multi-file) | "
                    "review/diff (git) | status"
                ),
            )
        mapped_action = {
            "forge": "forge",
            "helper": "auto",
            "project": None,
            "git": None,
        }.get(system)
    else:
        if action not in _ROUTE:
            return ask(
                "code_assist",
                f"unknown action '{action}'",
                options=(
                    "forge, fix, analyze, generate, write, edit, explain, run, "
                    "build, optimize, project, review, diff, status"
                ),
            )
        system, mapped_action = _ROUTE[action]

    # Special: run on .py with heal-ish description → forge
    if system == "helper" and mapped_action == "run":
        fp = (params.get("file_path") or params.get("path") or "").lower()
        desc = (params.get("description") or params.get("intent") or "").lower()
        if fp.endswith(".py") and any(k in desc for k in ("fix", "heal", "corrig", "until", "até")):
            system, mapped_action = "forge", "fix"

    # Special: build + python complex → forge unless project cues
    if system == "helper" and mapped_action == "build":
        lang = (params.get("language") or "python").lower()
        desc = (params.get("description") or params.get("intent") or "").lower()
        if lang in ("python", "py") and any(
            k in desc for k in ("autocorrig", "até passar", "heal", "forge", "testa e corrige")
        ):
            system, mapped_action = "forge", "forge"

    # ── dispatch ──────────────────────────────────────────────────────────
    try:
        if system == "forge":
            return _tag(code_forge(_to_forge(params, mapped_action or "forge")), "forge")
        if system == "helper":
            return _tag(code_helper(_to_helper(params, mapped_action or "auto")), "helper")
        if system == "project":
            return _tag(dev_agent(_to_project(params)), "project")
        if system == "git":
            return _tag(code_review_local(_to_git(params, mapped_action)), "git")
    except Exception as e:
        return failed("code_assist", f"{system} error: {e}", via=system)

    return failed("code_assist", f"unhandled system {system}")


TOOL = {
    "name": "code_assist",
    "description": (
        "Unified coding tool for JARVIS — use this instead of code_helper, "
        "dev_agent, code_review_local, or code_forge.\n"
        "PYTHON SELF-HEAL: action=forge (intent=...) generates a .py, analyzes, runs, "
        "and iteratively fixes errors it finds. action=fix file_path=... heals any existing .py.\n"
        "QUICK FILE OPS: write | edit | explain | run | build | optimize | screen_debug "
        "(multi-language via code_helper).\n"
        "FULL PROJECT: action=project description=... scaffolds multi-file apps, deps, run/fix "
        "(dev_agent).\n"
        "GIT REVIEW: action=review or diff — branch, status, changed files, diff facts "
        "(model writes the prose review).\n"
        "action=analyze for static Python check; action=status for subsystem health.\n"
        "If action is omitted, routes automatically from intent/path."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "forge|fix|analyze|generate|write|edit|explain|run|build|"
                    "optimize|project|review|diff|status"
                ),
            },
            "intent": {
                "type": "STRING",
                "description": "Natural language goal (alias: description/prompt)",
            },
            "description": {
                "type": "STRING",
                "description": "Same as intent — what to write, edit, or build",
            },
            "file_path": {
                "type": "STRING",
                "description": "Target file for edit/run/fix/analyze",
            },
            "path": {
                "type": "STRING",
                "description": "Alias for file_path, or repo path for git review",
            },
            "output_path": {
                "type": "STRING",
                "description": "Where to save generated code",
            },
            "code": {
                "type": "STRING",
                "description": "Inline source for analyze/explain/fix",
            },
            "language": {
                "type": "STRING",
                "description": "Programming language (default python)",
            },
            "project_dir": {
                "type": "STRING",
                "description": "Directory for action=project",
            },
            "mode": {
                "type": "STRING",
                "description": "For git: summary|diff",
            },
            "max_rounds": {
                "type": "NUMBER",
                "description": "Forge/fix iteration limit (default 3)",
            },
            "timeout": {
                "type": "NUMBER",
                "description": "Run timeout seconds",
            },
            "args": {
                "type": "STRING",
                "description": "CLI args when running a script",
            },
            "error": {
                "type": "STRING",
                "description": "Optional error text when fixing",
            },
        },
        "required": [],
    },
    "handler": code_assist,
    "tier": "core",
}
