"""code_assist — assistant wrapper → core.code_engine.pipeline."""
from __future__ import annotations

from core.code_engine import get_engine
from core.outcome import done, failed, ask


def code_assist(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "pipeline").strip().lower()
    goal = str(params.get("goal") or params.get("prompt") or params.get("description") or "").strip()
    engine = get_engine()

    if action in ("status", "help"):
        return done("code_assist", action="status", engine="core.code_engine")

    if action in ("pipeline", "implement", "build", "plan"):
        if not goal:
            return ask("code_assist", "goal?")
        write = str(params.get("write") or "true").lower() in ("1", "true", "yes", "")
        result = engine.pipeline(goal, write=write, run=False)
        return result.as_outcome("code_assist")

    return ask("code_assist", "action?", hint="pipeline|status")


TOOL = {
    "name": "code_assist",
    "description": (
        "Assistente de implementacao multi-arquivo via core.code_engine "
        "(Architect+Builder+Verifier+Healer). action=pipeline|status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
            "description": {"type": "STRING"},
            "write": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_assist,
    "tier": "core",
    "risk": "review",
}
