"""Alias legacy tool `background_monitor` → `system_monitor` (mode=watch)."""
from __future__ import annotations

from actions.system_monitor import system_monitor as _impl


def background_monitor(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "watch")
    params.setdefault("action", params.get("action") or "watch")
    return _impl(params, **ctx)


TOOL = {
    "name": "background_monitor",
    "description": 'Alias → system_monitor mode=watch',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": background_monitor,
    "tier": "core",
    "risk": "safe",
}
