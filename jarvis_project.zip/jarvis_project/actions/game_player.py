"""
game_player — JARVIS joga (ou ajuda a jogar) jogos simples.

Modos suportados:
  dino       — joga o Chrome Dinosaur (dino offline) com visão por pixels
  hold       — mantém teclas pressionadas (ex.: W + clique no Minecraft)
  macro      — grava / reproduz sequência simples de teclas
  reaction   — aperta uma tecla quando uma região da tela muda de cor
  stop       — para qualquer loop em andamento
  status     — estado atual do player

Limites conscientes:
  - NÃO implementa aimbot / triggerbot / recoil script para shooters online
    (Fortnite, Valorant, etc.) — viola ToS e fair play.
  - Para esses jogos use game_helper (coach) + macros manuais de build/edit
    que o próprio usuário dispara.
  - Dino e holds/macros são para single-player / offline / treino local.
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from core.outcome import done, failed, ask, started

_BASE = Path(__file__).resolve().parent.parent
_STATE_PATH = _BASE / "config" / "game_player.json"
_lock = threading.Lock()

# ── runtime state (in-memory; mirrored to disk for status) ────────────────
_worker: threading.Thread | None = None
_stop_event = threading.Event()
_runtime: dict[str, Any] = {
    "mode": None,
    "running": False,
    "started_at": None,
    "stats": {},
    "last_error": None,
}


def _has_pyautogui() -> bool:
    try:
        import pyautogui  # noqa: F401
        return True
    except ImportError:
        return False


def _has_capture() -> bool:
    try:
        import mss  # noqa: F401
        import numpy  # noqa: F401
        return True
    except ImportError:
        return False


def _load_disk() -> dict:
    try:
        return json.loads(_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {
            "macros": {},
            "dino_region": None,   # {left, top, width, height} optional override
            "last_mode": None,
        }


def _save_disk(data: dict) -> None:
    _STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _STATE_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _set_runtime(**kwargs) -> None:
    with _lock:
        _runtime.update(kwargs)


def _get_runtime() -> dict:
    with _lock:
        return dict(_runtime)


def _stop_worker() -> bool:
    """Signal the background loop to stop and wait briefly."""
    global _worker
    was = _get_runtime().get("running")
    _stop_event.set()
    if _worker and _worker.is_alive():
        _worker.join(timeout=2.5)
    _worker = None
    _set_runtime(running=False, mode=None)
    return bool(was)


# ═══════════════════════════════════════════════════════════════════════════
#  DINO — Chrome dinosaur (t-rex) pixel bot
# ═══════════════════════════════════════════════════════════════════════════

def _grab_gray(region: dict):
    """Capture a screen region as grayscale uint8 numpy array."""
    import mss
    import numpy as np

    with mss.mss() as sct:
        shot = sct.grab(region)
        # BGRA → gray approx (fast)
        img = np.frombuffer(shot.raw, dtype=np.uint8).reshape(shot.height, shot.width, 4)
        # luminosity
        gray = (0.299 * img[:, :, 2] + 0.587 * img[:, :, 1] + 0.114 * img[:, :, 0]).astype(np.uint8)
        return gray


def _dino_default_region() -> dict:
    """
    Heuristic region: lower-left-ish of the primary monitor where the dino
    usually runs. User can override via config dino_region.
    """
    import mss
    with mss.mss() as sct:
        mon = sct.monitors[1]  # primary
        # Game canvas is often centered; we sample a strip in the lower half
        w = min(900, mon["width"] - 80)
        h = 120
        left = mon["left"] + max(40, (mon["width"] - w) // 2)
        top = mon["top"] + int(mon["height"] * 0.55)
        return {"left": left, "top": top, "width": w, "height": h}


def _dino_obstacle(gray, look_ahead_ratio: float = 0.28) -> tuple[bool, str]:
    """
    Detect dark obstacle in a box ahead of the dino.
    Returns (should_jump, detail).
    Works on the classic white/light-gray day mode and dark mode (inverted).
    """
    import numpy as np

    h, w = gray.shape
    # Focus on the ground lane (middle band of our strip)
    y0, y1 = int(h * 0.35), int(h * 0.85)
    # Look a bit in front of the left side (where the dino stands)
    x0 = int(w * 0.12)
    x1 = int(w * (0.12 + look_ahead_ratio))
    roi = gray[y0:y1, x0:x1]
    if roi.size == 0:
        return False, "empty_roi"

    med = float(np.median(gray))
    # Day mode: background ~240, obstacles darker. Night: inverted.
    if med > 128:
        # day — obstacles are dark
        threshold = med - 40
        hit = int(np.sum(roi < threshold))
        kind = "day"
    else:
        # night — obstacles are bright
        threshold = med + 40
        hit = int(np.sum(roi > threshold))
        kind = "night"

    # Need a cluster of pixels, not noise
    area = roi.size
    density = hit / max(area, 1)
    should = density > 0.04 and hit > 25
    return should, f"{kind} hit={hit} dens={density:.3f}"


def _dino_loop(region: dict, jump_key: str, duck_key: str, poll_ms: int) -> None:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0

    jumps = 0
    frames = 0
    _set_runtime(
        mode="dino",
        running=True,
        started_at=datetime.now().isoformat(timespec="seconds"),
        stats={"jumps": 0, "frames": 0},
        last_error=None,
    )
    try:
        while not _stop_event.is_set():
            try:
                gray = _grab_gray(region)
                jump, detail = _dino_obstacle(gray)
                frames += 1
                if jump:
                    pyautogui.press(jump_key)
                    jumps += 1
                    # brief cooldown so we don't spam mid-air
                    time.sleep(0.12)
                _set_runtime(stats={"jumps": jumps, "frames": frames, "last": detail})
            except Exception as e:
                _set_runtime(last_error=str(e)[:200])
                time.sleep(0.3)
            time.sleep(max(poll_ms, 8) / 1000.0)
    finally:
        _set_runtime(running=False, mode=None, stats={"jumps": jumps, "frames": frames})


# ═══════════════════════════════════════════════════════════════════════════
#  HOLD — keep keys / mouse button down (Minecraft walk, mine, etc.)
# ═══════════════════════════════════════════════════════════════════════════

def _hold_loop(keys: list[str], mouse_button: str | None, duration_sec: float | None) -> None:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0

    _set_runtime(
        mode="hold",
        running=True,
        started_at=datetime.now().isoformat(timespec="seconds"),
        stats={"keys": keys, "mouse": mouse_button},
        last_error=None,
    )
    try:
        for k in keys:
            pyautogui.keyDown(k)
        if mouse_button in ("left", "right", "middle"):
            pyautogui.mouseDown(button=mouse_button)

        start = time.time()
        while not _stop_event.is_set():
            if duration_sec is not None and (time.time() - start) >= duration_sec:
                break
            time.sleep(0.05)
    except Exception as e:
        _set_runtime(last_error=str(e)[:200])
    finally:
        try:
            for k in keys:
                pyautogui.keyUp(k)
            if mouse_button in ("left", "right", "middle"):
                pyautogui.mouseUp(button=mouse_button)
        except Exception:
            pass
        _set_runtime(running=False, mode=None)


# ═══════════════════════════════════════════════════════════════════════════
#  MACRO — play a list of steps: key / wait / click
# ═══════════════════════════════════════════════════════════════════════════

def _play_macro(steps: list[dict], repeat: int) -> tuple[int, str | None]:
    """
    steps example:
      [{"type":"key","key":"w","duration":0.5},
       {"type":"press","key":"space"},
       {"type":"wait","seconds":0.2},
       {"type":"click","button":"left"}]
    """
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.02

    played = 0
    err = None
    try:
        for _ in range(max(1, repeat)):
            if _stop_event.is_set():
                break
            for step in steps:
                if _stop_event.is_set():
                    break
                st = (step.get("type") or "").lower()
                if st == "key":
                    k = step.get("key") or "w"
                    dur = float(step.get("duration") or 0.1)
                    pyautogui.keyDown(k)
                    time.sleep(max(0.01, dur))
                    pyautogui.keyUp(k)
                elif st == "press":
                    pyautogui.press(step.get("key") or "space")
                elif st == "wait":
                    time.sleep(float(step.get("seconds") or 0.1))
                elif st == "click":
                    btn = step.get("button") or "left"
                    pyautogui.click(button=btn)
                elif st == "hotkey":
                    keys = step.get("keys") or []
                    if keys:
                        pyautogui.hotkey(*keys)
                played += 1
    except Exception as e:
        err = str(e)[:200]
    return played, err


# ═══════════════════════════════════════════════════════════════════════════
#  REACTION — press key when ROI average brightness changes beyond delta
# ═══════════════════════════════════════════════════════════════════════════

def _reaction_loop(region: dict, key: str, delta: float, poll_ms: int) -> None:
    import pyautogui
    import numpy as np
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0

    baseline = None
    triggers = 0
    _set_runtime(
        mode="reaction",
        running=True,
        started_at=datetime.now().isoformat(timespec="seconds"),
        stats={"triggers": 0},
        last_error=None,
    )
    try:
        while not _stop_event.is_set():
            gray = _grab_gray(region)
            mean = float(np.mean(gray))
            if baseline is None:
                baseline = mean
            elif abs(mean - baseline) >= delta:
                pyautogui.press(key)
                triggers += 1
                baseline = mean  # re-arm
                _set_runtime(stats={"triggers": triggers, "mean": round(mean, 1)})
                time.sleep(0.15)
            time.sleep(max(poll_ms, 10) / 1000.0)
    except Exception as e:
        _set_runtime(last_error=str(e)[:200])
    finally:
        _set_runtime(running=False, mode=None)


# ═══════════════════════════════════════════════════════════════════════════
#  Handler
# ═══════════════════════════════════════════════════════════════════════════

def game_player(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = (params.get("action") or params.get("mode") or "status").strip().lower()

    # ── status ────────────────────────────────────────────────────────────
    if action in ("status", "state", "report"):
        rt = _get_runtime()
        disk = _load_disk()
        macros = list((disk.get("macros") or {}).keys())
        return done(
            "game_player",
            action="status",
            running=bool(rt.get("running")),
            mode=rt.get("mode") or "idle",
            started_at=rt.get("started_at"),
            stats=rt.get("stats") or {},
            last_error=rt.get("last_error"),
            saved_macros=", ".join(macros) if macros else "(none)",
            note=(
                "Modes: dino (Chrome T-Rex), hold (keys/mouse), macro, reaction, stop. "
                "No aimbot for online shooters."
            ),
        )

    # ── stop ──────────────────────────────────────────────────────────────
    if action in ("stop", "halt", "cancel", "quit"):
        was = _stop_worker()
        return done(
            "game_player",
            action="stop",
            was_running=was,
            note="player stopped" if was else "nothing was running",
        )

    # ── refuse competitive aiming ─────────────────────────────────────────
    if action in ("aimbot", "fortnite", "valorant", "cs2", "aim", "triggerbot"):
        return failed(
            "game_player",
            "aimbot/triggerbot for online competitive shooters is not supported "
            "(ToS + fair play). Use game_helper for tips, or macro/hold for "
            "offline single-player assists only.",
            suggestion="action=dino | hold | macro | reaction",
        )

    # ── dino ──────────────────────────────────────────────────────────────
    if action in ("dino", "trex", "chrome_dino", "dinosaur"):
        if not _has_pyautogui():
            return failed("game_player", "pyautogui is required — pip install pyautogui")
        if not _has_capture():
            return failed(
                "game_player",
                "dino needs mss and numpy — pip install mss numpy",
            )
        if _get_runtime().get("running"):
            return failed(
                "game_player",
                "already running — call action=stop first",
                mode=_get_runtime().get("mode"),
            )

        disk = _load_disk()
        region = params.get("region") or disk.get("dino_region")
        if isinstance(region, str):
            # "left,top,width,height"
            try:
                parts = [int(x.strip()) for x in region.split(",")]
                region = {
                    "left": parts[0], "top": parts[1],
                    "width": parts[2], "height": parts[3],
                }
            except Exception:
                region = None
        if not isinstance(region, dict):
            region = _dino_default_region()

        # persist optional region override
        if params.get("save_region"):
            disk["dino_region"] = region
            _save_disk(disk)

        jump_key = (params.get("jump_key") or "space").strip() or "space"
        duck_key = (params.get("duck_key") or "down").strip() or "down"
        try:
            poll_ms = int(params.get("poll_ms") or 25)
        except (TypeError, ValueError):
            poll_ms = 25

        _stop_event.clear()
        global _worker
        _worker = threading.Thread(
            target=_dino_loop,
            args=(region, jump_key, duck_key, poll_ms),
            name="jarvis-dino",
            daemon=True,
        )
        _worker.start()
        disk["last_mode"] = "dino"
        _save_disk(disk)

        return started(
            "game_player",
            mode="dino",
            region=f"{region['left']},{region['top']} {region['width']}x{region['height']}",
            jump_key=jump_key,
            note=(
                "Open chrome://dino (or play offline), click the game so it has focus, "
                "then the bot jumps on obstacles. action=stop to halt. "
                "Move mouse to a screen corner for pyautogui FAILSAFE emergency stop."
            ),
        )

    # ── hold ──────────────────────────────────────────────────────────────
    if action in ("hold", "walk", "mine", "keep"):
        if not _has_pyautogui():
            return failed("game_player", "pyautogui is required — pip install pyautogui")
        if _get_runtime().get("running"):
            return failed("game_player", "already running — stop first")

        keys_raw = params.get("keys") or params.get("key") or "w"
        if isinstance(keys_raw, str):
            keys = [k.strip() for k in keys_raw.replace("+", " ").split() if k.strip()]
        elif isinstance(keys_raw, list):
            keys = [str(k).strip() for k in keys_raw if str(k).strip()]
        else:
            keys = ["w"]
        if not keys:
            return ask("game_player", "which keys to hold?", hint="keys=w or keys=w a")

        mouse = (params.get("mouse") or params.get("mouse_button") or "").strip().lower() or None
        if mouse not in (None, "left", "right", "middle"):
            return failed("game_player", "mouse must be left|right|middle")

        duration = params.get("duration") or params.get("seconds")
        try:
            duration_sec = float(duration) if duration is not None else None
        except (TypeError, ValueError):
            duration_sec = None

        _stop_event.clear()
        _worker = threading.Thread(
            target=_hold_loop,
            args=(keys, mouse, duration_sec),
            name="jarvis-hold",
            daemon=True,
        )
        _worker.start()
        return started(
            "game_player",
            mode="hold",
            keys="+".join(keys),
            mouse=mouse or "none",
            duration_sec=duration_sec if duration_sec is not None else "until_stop",
            note="action=stop to release keys. FAILSAFE: mouse to screen corner.",
        )

    # ── macro play / save / list ──────────────────────────────────────────
    if action in ("macro", "play_macro", "run_macro"):
        disk = _load_disk()
        name = (params.get("name") or "").strip()
        steps = params.get("steps")

        # list
        if (params.get("list") or str(params.get("action_detail") or "").lower() == "list"
                or (not name and not steps and not params.get("save"))):
            names = list((disk.get("macros") or {}).keys())
            return done(
                "game_player",
                action="macro_list",
                macros=", ".join(names) if names else "(none)",
                note="Play with name=... or pass steps=[{type,key,...}]",
            )

        # save (no input devices needed)
        if params.get("save") and name and steps:
            if not isinstance(steps, list):
                return failed("game_player", "steps must be a list of step objects")
            disk.setdefault("macros", {})[name] = steps
            _save_disk(disk)
            return done("game_player", action="macro_save", name=name, steps=len(steps))

        # play needs pyautogui
        if not _has_pyautogui():
            return failed("game_player", "pyautogui is required — pip install pyautogui")

        # resolve steps
        if name and not steps:
            steps = (disk.get("macros") or {}).get(name)
            if not steps:
                return failed("game_player", f"macro '{name}' not found")
        if not isinstance(steps, list) or not steps:
            return ask(
                "game_player",
                "need steps or a saved macro name",
                hint='steps=[{"type":"press","key":"space"}] or name=my_macro',
            )

        try:
            repeat = int(params.get("repeat") or 1)
        except (TypeError, ValueError):
            repeat = 1
        repeat = max(1, min(repeat, 50))

        if _get_runtime().get("running"):
            return failed("game_player", "already running — stop first")

        _stop_event.clear()
        _set_runtime(mode="macro", running=True, started_at=datetime.now().isoformat(timespec="seconds"))

        def _run():
            played, err = _play_macro(steps, repeat)
            _set_runtime(
                running=False,
                mode=None,
                stats={"steps_played": played},
                last_error=err,
            )

        _worker = threading.Thread(target=_run, name="jarvis-macro", daemon=True)
        _worker.start()
        return started(
            "game_player",
            mode="macro",
            name=name or "(inline)",
            steps=len(steps),
            repeat=repeat,
        )

    # ── reaction ──────────────────────────────────────────────────────────
    if action in ("reaction", "react", "pixel_watch"):
        if not _has_pyautogui():
            return failed("game_player", "pyautogui is required — pip install pyautogui")
        if not _has_capture():
            return failed("game_player", "reaction needs mss and numpy")
        if _get_runtime().get("running"):
            return failed("game_player", "already running — stop first")

        region = params.get("region")
        if isinstance(region, str):
            try:
                parts = [int(x.strip()) for x in region.split(",")]
                region = {
                    "left": parts[0], "top": parts[1],
                    "width": parts[2], "height": parts[3],
                }
            except Exception:
                region = None
        if not isinstance(region, dict):
            # small center patch
            import mss
            with mss.mss() as sct:
                mon = sct.monitors[1]
                region = {
                    "left": mon["left"] + mon["width"] // 2 - 40,
                    "top": mon["top"] + mon["height"] // 2 - 40,
                    "width": 80,
                    "height": 80,
                }

        key = (params.get("key") or "space").strip() or "space"
        try:
            delta = float(params.get("delta") or 18)
        except (TypeError, ValueError):
            delta = 18.0
        try:
            poll_ms = int(params.get("poll_ms") or 30)
        except (TypeError, ValueError):
            poll_ms = 30

        _stop_event.clear()
        _worker = threading.Thread(
            target=_reaction_loop,
            args=(region, key, delta, poll_ms),
            name="jarvis-reaction",
            daemon=True,
        )
        _worker.start()
        return started(
            "game_player",
            mode="reaction",
            key=key,
            delta=delta,
            region=f"{region['left']},{region['top']} {region['width']}x{region['height']}",
            note="Presses key when the watched region brightness changes. action=stop to halt.",
        )

    return ask(
        "game_player",
        "what should I play or assist?",
        options=(
            "dino (Chrome T-Rex), hold (keys=w mouse=left), "
            "macro (name=... or steps=...), reaction, stop, status"
        ),
    )


TOOL = {
    "name": "game_player",
    "description": (
        "Play or assist simple games from the keyboard/mouse. "
        "Modes: "
        "dino — plays the Chrome dinosaur game (chrome://dino) by watching pixels and jumping; "
        "hold — keeps movement/mine keys down (e.g. Minecraft walk/mine) until stop; "
        "macro — save/play short key sequences; "
        "reaction — press a key when a screen region changes; "
        "stop / status. "
        "Does NOT provide aimbot or triggerbot for online competitive shooters "
        "(Fortnite, Valorant, etc.). For those games use game_helper for coaching only. "
        "Emergency stop: move mouse to a screen corner (pyautogui FAILSAFE) or action=stop."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "dino | hold | macro | reaction | stop | status"
                ),
            },
            "keys": {
                "type": "STRING",
                "description": "For hold: keys to keep down, e.g. 'w' or 'w a'",
            },
            "mouse": {
                "type": "STRING",
                "description": "For hold: left | right | middle mouse button to hold",
            },
            "duration": {
                "type": "NUMBER",
                "description": "For hold: seconds before auto-release (omit = until stop)",
            },
            "name": {
                "type": "STRING",
                "description": "For macro: saved macro name",
            },
            "steps": {
                "type": "ARRAY",
                "description": (
                    "For macro: list of {type:key|press|wait|click|hotkey, key, duration, seconds, button, keys}"
                ),
            },
            "save": {
                "type": "BOOLEAN",
                "description": "For macro: save steps under name",
            },
            "repeat": {
                "type": "NUMBER",
                "description": "For macro: how many times to play (max 50)",
            },
            "region": {
                "type": "STRING",
                "description": "left,top,width,height for dino/reaction capture region",
            },
            "jump_key": {
                "type": "STRING",
                "description": "Dino jump key (default space)",
            },
            "key": {
                "type": "STRING",
                "description": "Reaction key to press (default space)",
            },
            "delta": {
                "type": "NUMBER",
                "description": "Reaction brightness change threshold (default 18)",
            },
            "poll_ms": {
                "type": "NUMBER",
                "description": "Polling interval in ms for dino/reaction",
            },
        },
        "required": [],
    },
    "handler": game_player,
    "tier": "core",
}
