"""Unified system monitoring (status/health/sensors/governor/watch/resources)."""
from __future__ import annotations

from core.outcome import done, failed, ask


def _dispatch(impl: str, fn_candidates: list[str], params: dict, **ctx) -> str:
    import importlib
    mod = importlib.import_module(f"actions.{impl}")
    for fn in fn_candidates:
        h = getattr(mod, fn, None)
        if callable(h):
            try:
                return h(params, **ctx)
            except TypeError:
                try:
                    return h(parameters=params, **ctx)
                except TypeError:
                    try:
                        return h(params)
                    except TypeError:
                        return h()
    return failed("system_monitor", f"no handler in {impl}")


def system_monitor(parameters=None, **ctx) -> str:
    params = dict(parameters or {})
    mode = str(params.get("mode") or params.get("action") or "status").strip().lower()
    if mode in ("status", "sys", "system_status", "help") and mode != "help":
        try:
            from actions._system_monitor_impl import get_system_status
            data = get_system_status()
            return done("system_monitor", action="status", result=str(data)[:2500])
        except Exception as e:
            return _dispatch("_system_resources_monitor_impl", ["system_resources_monitor", "run"], params, **ctx)
    if mode == "help":
        return done("system_monitor", modes=["status", "health", "hardware_sensors", "governor", "watch", "resources"])
    if mode in ("health", "system_health"):
        return _dispatch("_system_health_impl", ["system_health", "run"], params, **ctx)
    if mode in ("governor", "resource_governor", "resource"):
        return _dispatch("_resource_governor_impl", ["resource_governor", "run"], params, **ctx)
    if mode in ("watch", "background", "background_monitor"):
        return _dispatch("_background_monitor_impl", ["background_monitor", "run"], params, **ctx)
    if mode in ("hardware_sensors", "hardware", "hw", "hwmonitor", "sensors"):
        return _dispatch("_hwmonitor_integration_impl", ["hwmonitor_integration", "run"], params, **ctx)
    if mode in ("resources", "system_resources", "system_resources_monitor"):
        return _dispatch("_system_resources_monitor_impl", ["system_resources_monitor", "run"], params, **ctx)
    if mode in ("monitor_tool", "add", "remove", "list", "list_topics"):
        if mode in ("add", "remove", "list"):
            params["action"] = mode
        elif mode == "list_topics":
            params["action"] = "list"
        return _dispatch("_monitor_tool_impl", ["monitor_tool", "run"], params, **ctx)
    return ask("system_monitor", "mode?", hint="status|health|hardware_sensors|governor|watch|resources")


TOOL = {
    "name": "system_monitor",
    "description": "Monitoramento unificado: mode=status|health|hardware_sensors|governor|watch|resources.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "topic": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": system_monitor,
    "tier": "core",
    "risk": "safe",
}
