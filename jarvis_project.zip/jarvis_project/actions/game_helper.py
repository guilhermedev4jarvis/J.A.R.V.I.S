"""
Action: game_helper — ajudante de games (dicas, builds, counters, checklist).

Modos:
  tips      — dicas gerais / early game / progressão
  counter   — como enfrentar um personagem/chefão/estratégia
  build     — sugestão de build/loadout (educativa, genérica)
  checklist — preparação antes de rank/raid/evento
  lookup    — pergunta livre sobre um jogo

Usa Gemini quando a chave existe; senão devolve um template estruturado
honesto (sem inventar patch notes).
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional

from core import outcome

_MODES = ("tips", "counter", "build", "checklist", "lookup")


def _log(msg: str, player=None) -> None:
    print(f"[Game] {msg}")
    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass


def _api_key() -> str:
    p = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("gemini_api_key") or ""
    except Exception:
        return ""


def _clean_game(name: str) -> str:
    return re.sub(r"\s+", " ", (name or "").strip())[:80]


def _fallback(mode: str, game: str, topic: str) -> str:
    g = game or "seu jogo"
    t = topic or "o objetivo atual"
    if mode == "tips":
        return (
            f"Dicas gerais para {g} (sem patch notes online neste momento):\n"
            f"1. Foque o objetivo principal: {t}.\n"
            "2. Domine 1–2 rotas/classes antes de expandir o pool.\n"
            "3. Ajuste gráficos/ping: estabilidade vale mais que ultra settings.\n"
            "4. Veja o replay da última derrota — um erro recorrente costuma explicar o elo.\n"
            "5. Faça pausas: tilt aumenta morte boba mais que falta de skill."
        )
    if mode == "counter":
        return (
            f"Para enfrentar '{t}' em {g}:\n"
            "1. Identifique a janela de poder (early/mid/late) do oponente.\n"
            "2. Negue o recurso que ele precisa (espaço, cooldown, visão, farm).\n"
            "3. Troque só quando a skill-chave dele estiver fora.\n"
            "4. Traga utilitário (slow, silence, burst) em vez de só DPS cru.\n"
            "5. Confirme no patch atual — counters mudam; isto é framework, não lista fixa."
        )
    if mode == "build":
        return (
            f"Build educativa para {g} / foco '{t}':\n"
            "1. 1 item de sobrevivência cedo se você está morrendo antes de bater.\n"
            "2. 1 spike de dano no pico do seu power spike.\n"
            "3. Utilitário (mobilidade/resistência) se o meta for controle.\n"
            "4. Não copie build de pro sem olhar seu elo e seu time.\n"
            "5. Valide no treino/custom antes de ranqueada."
        )
    if mode == "checklist":
        return (
            f"Checklist pré-sessão — {g}:\n"
            "□ Atualização/patch aplicada\n"
            "□ Drivers GPU e áudio de chat ok\n"
            "□ Aquecimento 1–2 partidas leves ou aim trainer\n"
            "□ Meta/objetivo da sessão definido (ex.: só farm, só vision)\n"
            "□ Hidratação + pausa a cada 3–4 partidas\n"
            f"□ Foco de hoje: {t}"
        )
    return (
        f"Sobre '{t}' em {g}: não tenho patch notes ao vivo sem API. "
        "Diga o modo (tips/counter/build/checklist) e o detalhe que você quer "
        "(personagem, fase, rank) para eu estruturar melhor — ou configure a "
        "chave Gemini para respostas mais específicas."
    )


def _gemini_answer(mode: str, game: str, topic: str, rank: str) -> Optional[str]:
    if not _api_key():
        return None
    try:
        from core import gemini
        prompt = (
            "Você é um coach de games objetivo e atualizado até onde o conhecimento "
            "permitir. Responda em português do Brasil, em tópicos curtos (máx. 12 "
            "linhas). Se não tiver certeza do patch atual, diga isso explicitamente "
            "e dê princípios que continuam válidos. Não invente números de dano.\n\n"
            f"Modo: {mode}\nJogo: {game or 'não informado'}\n"
            f"Tópico: {topic or 'geral'}\nRank/nível: {rank or 'não informado'}\n"
        )
        if mode == "tips":
            prompt += "Peça: dicas práticas de melhoria e progressão.\n"
        elif mode == "counter":
            prompt += "Peça: como enfrentar esse oponente/estratégia (passos acionáveis).\n"
        elif mode == "build":
            prompt += "Peça: direção de build/loadout e ordem de prioridade (educativa).\n"
        elif mode == "checklist":
            prompt += "Peça: checklist curto antes de jogar rank/raid/evento.\n"
        else:
            prompt += "Peça: resposta direta à dúvida do jogador.\n"

        text = gemini.text(prompt, tier=getattr(gemini, "FAST", "FAST"), timeout_ms=45_000)
        text = (text or "").strip()
        return text or None
    except Exception as e:
        _log(f"gemini coach failed: {e}")
        return None


def game_helper(parameters: dict, player=None, session_memory=None) -> str:
    params = parameters or {}
    mode = str(params.get("mode") or "lookup").strip().lower()
    if mode not in _MODES:
        mode = "lookup"
    game = _clean_game(str(params.get("game") or params.get("title") or ""))
    topic = str(params.get("topic") or params.get("query") or params.get("enemy")
                or params.get("question") or "").strip()[:200]
    rank = str(params.get("rank") or params.get("level") or "").strip()[:40]

    if not game and not topic:
        return outcome.ask(
            "game_helper",
            "Qual jogo e o que você precisa — dicas, counter, build ou checklist?",
        )

    answer = _gemini_answer(mode, game, topic, rank)
    engine = "gemini" if answer else "local"
    if not answer:
        answer = _fallback(mode, game, topic)

    _log(f"{engine} mode={mode} game={game or '-'} topic={topic[:40]}", player)
    return outcome.done(
        "game_helper",
        mode=mode,
        game=game or "unspecified",
        topic=topic or "general",
        engine=engine,
        advice=answer[:3500],
    )


TOOL = {
    "name": "game_helper",
    "description": (
        "Gaming coach: tips, how to counter an enemy/strategy, educational builds, "
        "pre-session checklist, or a free-form question about a game. "
        "Use when the user asks for help in a game, counters, builds, how to improve, "
        "or a ranked/raid checklist. Works offline with solid frameworks; richer "
        "answers when Gemini API key is configured."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {
                "type": "STRING",
                "description": "tips | counter | build | checklist | lookup",
            },
            "game": {
                "type": "STRING",
                "description": "Game title, e.g. 'Valorant', 'Dead Rails', 'LoL'.",
            },
            "topic": {
                "type": "STRING",
                "description": "Focus: character, boss, rank goal, or free question.",
            },
            "rank": {
                "type": "STRING",
                "description": "Optional rank or level context.",
            },
        },
        "required": [],
    },
    "handler": game_helper,
}
