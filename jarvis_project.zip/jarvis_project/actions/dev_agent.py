"""dev_agent — multi-file project agent wrapper → core.code_engine.pipeline."""
from __future__ import annotations

from core.code_engine import get_engine
from core.outcome import done, failed, ask


def dev_agent(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "implement").strip().lower()
    goal = str(params.get("goal") or params.get("prompt") or params.get("task") or "").strip()
    engine = get_engine()

    if action in ("status", "help"):
        return done("dev_agent", action="status", engine="core.code_engine")

    if action in ("implement", "plan", "build", "pipeline"):
        if not goal:
            return ask("dev_agent", "goal/task?")
        result = engine.pipeline(goal, write=True, run=False)
        return result.as_outcome("dev_agent")

    return ask("dev_agent", "action?", hint="implement|plan|status")


TOOL = {
    "name": "dev_agent",
    "description": (
        "Agente de projeto multi-arquivo (plano+codigo+verificacao) via "
        "core.code_engine. action=implement|plan|status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
            "task": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": dev_agent,
    "tier": "core",
    "risk": "autonomous",
}
