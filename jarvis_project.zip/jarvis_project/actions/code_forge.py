"""
code_forge — thin wrapper over core.code_engine (generate/analyze/run/fix/forge).

Full pipeline lives in core.code_engine. This module preserves the legacy TOOL
surface so existing prompts and hot_reload keep working.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from core.code_engine import get_engine
from core.outcome import done, failed, ask

_BASE = Path(__file__).resolve().parent.parent


def code_forge(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "forge").strip().lower()
    engine = get_engine()

    if action in ("status", "help"):
        return done("code_forge", action="status", engine="core.code_engine", note="wrappers ok")

    if action == "generate":
        prompt = str(params.get("prompt") or params.get("goal") or params.get("description") or "").strip()
        if not prompt:
            return ask("code_forge", "prompt?", hint="prompt=escreva um parser CSV")
        dest = params.get("path") or params.get("dest")
        result = engine.generate_python(prompt, dest=str(dest) if dest else None)
        return result.as_outcome("code_forge")

    if action == "analyze":
        path = str(params.get("path") or "").strip()
        source = str(params.get("source") or params.get("code") or "")
        if not path and not source:
            return ask("code_forge", "path or source?")
        try:
            vr = engine.analyze(source=source, path=path)
        except Exception as e:
            return failed("code_forge", str(e), action="analyze")
        if vr.ok:
            return done("code_forge", action="analyze", ok=True, stage=vr.stage)
        return failed("code_forge", vr.message, action="analyze", stage=vr.stage, stderr=vr.stderr[:500])

    if action == "fix":
        path = str(params.get("path") or "").strip()
        source = str(params.get("source") or params.get("code") or "")
        error = str(params.get("error") or params.get("error_report") or "").strip()
        if path and not source:
            source = Path(path).read_text(encoding="utf-8", errors="replace")
        if not source or not error:
            return ask("code_forge", "source/path and error required")
        try:
            fixed = engine.fix(source, error, path=path)
            if path and str(params.get("write") or "true").lower() in ("1", "true", "yes", ""):
                Path(path).write_text(fixed, encoding="utf-8")
            return done("code_forge", action="fix", path=path or "", chars=len(fixed))
        except Exception as e:
            return failed("code_forge", str(e), action="fix")

    if action in ("forge", "run", "build"):
        prompt = str(params.get("prompt") or params.get("goal") or params.get("description") or "").strip()
        if not prompt:
            return ask("code_forge", "prompt?", hint="prompt=script that lists processes")
        dest = params.get("path") or params.get("dest")
        try:
            rounds = int(params.get("max_rounds") or 3)
        except (TypeError, ValueError):
            rounds = 3
        run = str(params.get("run") or "true").lower() in ("1", "true", "yes", "")
        result = engine.forge(prompt, dest=str(dest) if dest else None, max_rounds=rounds, run=run)
        return result.as_outcome("code_forge")

    if action == "review":
        path = str(params.get("path") or "").strip()
        if not path:
            return ask("code_forge", "path?")
        try:
            vr = engine.analyze(path=path)
        except Exception as e:
            return failed("code_forge", str(e), action="review")
        if vr.ok:
            return done("code_forge", action="review", ok=True, path=path)
        return failed("code_forge", vr.message, action="review", path=path)

    return ask(
        "code_forge",
        "action?",
        hint="generate|analyze|fix|forge|review|status",
    )


TOOL = {
    "name": "code_forge",
    "description": (
        "Gera, analisa, executa e corrige codigo Python via core.code_engine "
        "(Architect→Builder→SandboxVerifier→AutoHealer). "
        "Acoes: generate | analyze | fix | forge | review | status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "generate|analyze|fix|forge|review|status"},
            "prompt": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "path": {"type": "STRING"},
            "source": {"type": "STRING"},
            "code": {"type": "STRING"},
            "error": {"type": "STRING"},
            "error_report": {"type": "STRING"},
            "max_rounds": {"type": "NUMBER"},
            "run": {"type": "STRING"},
            "write": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_forge,
    "tier": "core",
    "risk": "review",
}
