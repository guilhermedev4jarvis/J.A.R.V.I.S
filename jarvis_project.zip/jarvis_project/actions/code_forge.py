"""
code_forge — gerador e autocorretor de código Python.

Ciclo completo:
  generate  → cria .py a partir de linguagem natural
  analyze   → AST + py_compile + checagens estáticas
  run       → executa e captura stdout/stderr/traceback
  fix       → LLM corrige com base no erro (qualquer .py)
  forge     → generate → analyze → run → fix em loop até OK ou max_rounds
  review    → análise estática + resumo de problemas sem gravar

Focado em Python. Para projetos multi-arquivo use dev_agent;
para edições rápidas multilanguage use code_helper.
"""
from __future__ import annotations

import ast
import json
import py_compile
import re
import subprocess
import sys
import tempfile
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from core.outcome import done, failed, ask

_BASE = Path(__file__).resolve().parent.parent
_OUT_DIR = _BASE / "cache" / "code_forge"
_HISTORY = _BASE / "config" / "code_forge_history.json"

_MAX_ROUNDS_DEFAULT = 3
_MAX_FILE_CHARS = 120_000

_SYSTEM_GEN = """You are an expert Python 3.10+ engineer.
Output ONLY valid Python source code. No markdown fences, no prose.
Requirements:
- Complete, runnable module when appropriate (if __name__ == '__main__' only if useful).
- Type hints where natural; clear docstrings on public functions.
- Explicit error handling for I/O and external calls.
- No placeholder TODOs that leave the code broken.
- Prefer stdlib; if a third-party import is essential, use it and note it in a top comment: # requires: package
"""

_SYSTEM_FIX = """You are an expert Python debugger.
Given broken source and an error report, return ONLY the full corrected Python file.
No markdown fences, no explanations.
Keep the original intent and public API unless the bug forces a change.
Fix the root cause, not only the symptom.
"""


def _out_dir() -> Path:
    _OUT_DIR.mkdir(parents=True, exist_ok=True)
    return _OUT_DIR


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _append_hist(entry: dict) -> None:
    try:
        hist: list = []
        if _HISTORY.exists():
            hist = json.loads(_HISTORY.read_text(encoding="utf-8"))
            if not isinstance(hist, list):
                hist = []
        hist.append(entry)
        _HISTORY.parent.mkdir(parents=True, exist_ok=True)
        _HISTORY.write_text(
            json.dumps(hist[-50:], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        pass


def _strip_fences(text: str) -> str:
    t = (text or "").strip()
    if not t:
        return ""
    m = re.search(r"```(?:python|py)?\s*([\s\S]*?)```", t, re.I)
    if m:
        return m.group(1).strip()
    # drop leading prose until a Python-looking line
    lines = t.splitlines()
    start = 0
    for i, line in enumerate(lines):
        s = line.strip()
        if not s:
            continue
        if s.startswith("#") or re.match(
            r"^(from |import |def |class |@|async def |if __name__|try:|with )",
            s,
        ):
            start = i
            break
    return "\n".join(lines[start:]).strip()


def _llm(prompt: str, system: str, max_tokens: int = 4096) -> str:
    """Local LLM first, Gemini fallback."""
    err_llm = err_gem = "n/a"
    try:
        from core.llm_client import call_llm_text
        # call_llm_text uses num_predict ~600 by default — too small for full files.
        # Prefer a direct call with larger budget when possible.
        try:
            from core.llm_client import get_llm_settings, get_llm_provider, ensure_ollama_running
            import requests
            url, model = get_llm_settings()
            provider = get_llm_provider()
            messages = [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ]
            if provider == "openai":
                endpoint = f"{url}/v1/chat/completions"
                payload = {
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "max_tokens": max_tokens,
                    "temperature": 0.2,
                }
            else:
                endpoint = f"{url}/api/chat"
                payload = {
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "keep_alive": -1,
                    "options": {"num_predict": max_tokens, "temperature": 0.2},
                }
            try:
                resp = requests.post(endpoint, json=payload, timeout=180)
                resp.raise_for_status()
                data = resp.json()
                if provider == "openai":
                    text = (data.get("choices") or [{}])[0].get("message", {}).get("content") or ""
                else:
                    text = (data.get("message") or {}).get("content") or ""
                cleaned = _strip_fences(text)
                if cleaned and len(cleaned) > 20:
                    return cleaned
            except Exception as e:
                err_llm = str(e)[:180]
                ensure_ollama_running()
        except Exception as e:
            err_llm = str(e)[:180]
            text = call_llm_text(prompt=prompt, system=system, timeout=120)
            cleaned = _strip_fences(text)
            if cleaned and len(cleaned) > 20:
                return cleaned
    except Exception as e:
        err_llm = str(e)[:180]

    try:
        key = ""
        cfg = _BASE / "config" / "api_keys.json"
        if cfg.exists():
            key = json.loads(cfg.read_text(encoding="utf-8")).get("gemini_api_key") or ""
        if key:
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=key)
            resp = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=f"{system}\n\n{prompt}",
                config=types.GenerateContentConfig(
                    temperature=0.2,
                    max_output_tokens=max_tokens,
                ),
            )
            cleaned = _strip_fences(getattr(resp, "text", None) or "")
            if cleaned and len(cleaned) > 20:
                return cleaned
            err_gem = "empty"
        else:
            err_gem = "no gemini key"
    except Exception as e:
        err_gem = str(e)[:180]

    raise RuntimeError(f"LLM generation failed (local: {err_llm}; gemini: {err_gem})")


def _resolve_path(file_path: str | None, default_name: str = "module.py") -> Path:
    if not file_path or not str(file_path).strip():
        return _out_dir() / f"{default_name.rsplit('.', 1)[0]}_{_stamp()}.py"
    p = Path(file_path).expanduser()
    if not p.is_absolute():
        # Prefer project-relative, then cwd
        cand = (_BASE / p).resolve()
        p = cand
    if p.suffix.lower() != ".py":
        p = p.with_suffix(".py")
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _read_py(path: Path) -> str:
    if not path.exists():
        raise FileNotFoundError(str(path))
    text = path.read_text(encoding="utf-8", errors="replace")
    if len(text) > _MAX_FILE_CHARS:
        raise ValueError(f"file too large ({len(text)} chars, max {_MAX_FILE_CHARS})")
    return text


def _write_py(path: Path, code: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(code, encoding="utf-8")


def _analyze(code: str, path: Path | None = None) -> dict[str, Any]:
    """Static checks: syntax (ast), compile, basic smells."""
    problems: list[str] = []
    warnings: list[str] = []
    tree = None

    try:
        tree = ast.parse(code, filename=str(path or "<forge>"))
    except SyntaxError as e:
        problems.append(
            f"SyntaxError line {e.lineno}: {e.msg}"
            + (f" (text: {e.text.strip()})" if e.text else "")
        )
        return {
            "ok": False,
            "problems": problems,
            "warnings": warnings,
            "functions": [],
            "classes": [],
            "imports": [],
        }

    # compile to bytecode (catches some issues ast doesn't)
    try:
        with tempfile.NamedTemporaryFile(suffix=".py", mode="w", encoding="utf-8", delete=False) as tf:
            tf.write(code)
            tf.flush()
            tmp = Path(tf.name)
        try:
            py_compile.compile(str(tmp), doraise=True)
        finally:
            try:
                tmp.unlink()
            except Exception:
                pass
    except py_compile.PyCompileError as e:
        problems.append(f"CompileError: {e}")
    except Exception as e:
        warnings.append(f"compile check skipped: {e}")

    funcs, classes, imports = [], [], []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
            funcs.append(node.name)
        elif isinstance(node, ast.ClassDef):
            classes.append(node.name)
        elif isinstance(node, ast.Import):
            for a in node.names:
                imports.append(a.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module.split(".")[0])

    # simple smells
    if "TODO" in code or "NotImplementedError" in code:
        warnings.append("contains TODO or NotImplementedError")
    if re.search(r"\bexcept:\s*$|\bexcept\s*:\s*pass\b", code, re.M):
        warnings.append("bare except or silent pass in except")

    return {
        "ok": len(problems) == 0,
        "problems": problems,
        "warnings": warnings,
        "functions": funcs[:40],
        "classes": classes[:20],
        "imports": sorted(set(imports))[:40],
    }


def _run_py(path: Path, args: list[str] | None, timeout: float) -> dict[str, Any]:
    cmd = [sys.executable, str(path)] + list(args or [])
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(path.parent),
            encoding="utf-8",
            errors="replace",
        )
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        return {
            "exit_code": r.returncode,
            "stdout": out[:4000],
            "stderr": err[:4000],
            "ok": r.returncode == 0,
            "error_summary": _summarize_error(err, out) if r.returncode != 0 else None,
        }
    except subprocess.TimeoutExpired:
        return {
            "exit_code": 124,
            "stdout": "",
            "stderr": f"timeout after {timeout}s",
            "ok": False,
            "error_summary": f"TimeoutError: exceeded {timeout}s",
        }
    except Exception as e:
        return {
            "exit_code": 1,
            "stdout": "",
            "stderr": str(e),
            "ok": False,
            "error_summary": str(e),
        }


def _summarize_error(stderr: str, stdout: str = "") -> str:
    text = stderr or stdout or ""
    # last traceback block
    if "Traceback (most recent call last)" in text:
        idx = text.rfind("Traceback (most recent call last)")
        return text[idx:][:2500]
    lines = [ln for ln in text.splitlines() if ln.strip()]
    return "\n".join(lines[-30:])[:2500] if lines else "unknown error"


def _generate_code(intent: str, context_files: dict[str, str] | None = None) -> str:
    extra = ""
    if context_files:
        parts = []
        for name, body in list(context_files.items())[:5]:
            parts.append(f"# --- {name} ---\n{body[:4000]}")
        extra = "\n\nRelated files for context:\n" + "\n\n".join(parts)
    prompt = f"Write Python code for this request:\n{intent}{extra}\n\nPython code:"
    return _llm(prompt, _SYSTEM_GEN, max_tokens=4096)


def _fix_code(code: str, error_report: str, intent: str = "") -> str:
    prompt = (
        f"Original intent: {intent or '(not provided)'}\n\n"
        f"Error report:\n{error_report[:3500]}\n\n"
        f"Broken source:\n{code[:90000]}\n\n"
        f"Corrected Python source:"
    )
    return _llm(prompt, _SYSTEM_FIX, max_tokens=4096)


def _analysis_blob(a: dict) -> str:
    bits = []
    if a.get("problems"):
        bits.append("PROBLEMS:\n- " + "\n- ".join(a["problems"]))
    if a.get("warnings"):
        bits.append("WARNINGS:\n- " + "\n- ".join(a["warnings"]))
    return "\n".join(bits) or "no issues"


def code_forge(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = (params.get("action") or "forge").strip().lower()
    intent = (params.get("intent") or params.get("description") or params.get("prompt") or "").strip()
    file_path = (params.get("file_path") or params.get("path") or params.get("output_path") or "").strip()
    code_in = (params.get("code") or "").strip()
    try:
        max_rounds = int(params.get("max_rounds") or _MAX_ROUNDS_DEFAULT)
    except (TypeError, ValueError):
        max_rounds = _MAX_ROUNDS_DEFAULT
    max_rounds = max(1, min(max_rounds, 6))
    try:
        timeout = float(params.get("timeout") or 30)
    except (TypeError, ValueError):
        timeout = 30.0
    timeout = max(5.0, min(timeout, 180.0))
    args = params.get("args") or []
    if isinstance(args, str):
        args = [a for a in args.split() if a]
    run_after = str(params.get("run") or params.get("execute") or "true").lower() not in (
        "0", "false", "no",
    )
    save = str(params.get("save") or "true").lower() not in ("0", "false", "no")

    # ── status ────────────────────────────────────────────────────────────
    if action in ("status", "history"):
        hist = []
        try:
            if _HISTORY.exists():
                hist = json.loads(_HISTORY.read_text(encoding="utf-8"))[-8:]
        except Exception:
            pass
        summary = "; ".join(
            f"{h.get('at','?')[:16]} {h.get('action')} ok={h.get('ok')}"
            for h in hist
        ) or "(empty)"
        return done(
            "code_forge",
            action="status",
            cache=str(_OUT_DIR),
            recent=summary,
        )

    # ── analyze only ──────────────────────────────────────────────────────
    if action in ("analyze", "review", "check"):
        try:
            if code_in:
                code = _strip_fences(code_in)
                path = Path(file_path) if file_path else Path("<memory>")
            elif file_path:
                path = _resolve_path(file_path)
                code = _read_py(path)
            else:
                return failed("code_forge", "file_path or code is required for analyze")
            a = _analyze(code, path if path.name != "<memory>" else None)
            return done(
                "code_forge",
                action="analyze",
                ok=a["ok"],
                problems="; ".join(a["problems"]) if a["problems"] else "none",
                warnings="; ".join(a["warnings"]) if a["warnings"] else "none",
                functions=", ".join(a["functions"]) or "(none)",
                classes=", ".join(a["classes"]) or "(none)",
                imports=", ".join(a["imports"]) or "(none)",
                path=str(path) if file_path else "inline",
            )
        except Exception as e:
            return failed("code_forge", str(e))

    # ── run only ──────────────────────────────────────────────────────────
    if action in ("run", "execute"):
        if not file_path:
            return failed("code_forge", "file_path is required for run")
        path = _resolve_path(file_path)
        if not path.exists():
            return failed("code_forge", f"file not found: {path}")
        result = _run_py(path, args, timeout)
        if result["ok"]:
            return done(
                "code_forge",
                action="run",
                path=str(path),
                exit_code=0,
                output=result["stdout"] or "(no output)",
            )
        return failed(
            "code_forge",
            result["error_summary"] or result["stderr"] or "run failed",
            path=str(path),
            exit_code=result["exit_code"],
            stdout=result["stdout"] or "",
        )

    # ── generate only ─────────────────────────────────────────────────────
    if action in ("generate", "write", "create"):
        if not intent:
            return failed("code_forge", "intent is required for generate")
        try:
            code = _generate_code(intent)
        except Exception as e:
            return failed("code_forge", f"generation failed: {e}")
        a = _analyze(code)
        path = _resolve_path(file_path, default_name="generated.py") if save else None
        if save and path:
            _write_py(path, code)
        _append_hist({
            "at": datetime.now().isoformat(timespec="seconds"),
            "action": "generate",
            "ok": a["ok"],
            "path": str(path) if path else None,
        })
        return done(
            "code_forge",
            action="generate",
            path=str(path) if path else "not_saved",
            analysis_ok=a["ok"],
            problems="; ".join(a["problems"]) if a["problems"] else "none",
            functions=", ".join(a["functions"]) or "(none)",
            preview=code[:1200] + ("…" if len(code) > 1200 else ""),
            note="Use action=forge for generate+run+auto-fix loop, or fix if analysis failed.",
        )

    # ── fix existing file or code ─────────────────────────────────────────
    if action in ("fix", "repair", "heal"):
        error_report = (params.get("error") or params.get("error_report") or "").strip()
        try:
            if code_in:
                code = _strip_fences(code_in)
                path = _resolve_path(file_path, "fixed.py") if file_path or save else None
            elif file_path:
                path = _resolve_path(file_path)
                code = _read_py(path)
            else:
                return failed("code_forge", "file_path or code required for fix")

            if not error_report:
                # self-diagnose
                a = _analyze(code, path)
                if not a["ok"]:
                    error_report = _analysis_blob(a)
                elif path and path.exists() and path.name != "<memory>":
                    run = _run_py(path, args, timeout)
                    if run["ok"]:
                        return done(
                            "code_forge",
                            action="fix",
                            path=str(path) if path else "inline",
                            note="no static or runtime errors found — nothing to fix",
                        )
                    error_report = run["error_summary"] or run["stderr"]
                else:
                    return ask(
                        "code_forge",
                        "no error found statically; provide error=... or a runnable file_path",
                    )

            fixed = _fix_code(code, error_report, intent)
            a = _analyze(fixed)
            rounds_done = 1
            # iterative fix if still broken statically
            while not a["ok"] and rounds_done < max_rounds:
                fixed = _fix_code(fixed, _analysis_blob(a), intent)
                a = _analyze(fixed)
                rounds_done += 1

            if path and save:
                _write_py(path, fixed)
            elif save and not path:
                path = _resolve_path(None, "fixed.py")
                _write_py(path, fixed)

            run_info = None
            if run_after and path and path.exists() and a["ok"]:
                run_info = _run_py(path, args, timeout)
                if not run_info["ok"] and rounds_done < max_rounds:
                    # runtime fix rounds
                    while not run_info["ok"] and rounds_done < max_rounds:
                        fixed = _fix_code(
                            fixed,
                            run_info["error_summary"] or run_info["stderr"],
                            intent,
                        )
                        a = _analyze(fixed)
                        if not a["ok"]:
                            rounds_done += 1
                            continue
                        _write_py(path, fixed)
                        run_info = _run_py(path, args, timeout)
                        rounds_done += 1

            ok = a["ok"] and (run_info is None or run_info.get("ok"))
            _append_hist({
                "at": datetime.now().isoformat(timespec="seconds"),
                "action": "fix",
                "ok": ok,
                "path": str(path) if path else None,
                "rounds": rounds_done,
            })
            return done(
                "code_forge",
                action="fix",
                ok=ok,
                rounds=rounds_done,
                path=str(path) if path else "inline",
                analysis_ok=a["ok"],
                problems="; ".join(a["problems"]) if a["problems"] else "none",
                run_ok=None if run_info is None else run_info.get("ok"),
                run_error=(run_info or {}).get("error_summary") if run_info and not run_info.get("ok") else None,
                output=(run_info or {}).get("stdout") if run_info else None,
                preview=fixed[:1000] + ("…" if len(fixed) > 1000 else ""),
            )
        except Exception as e:
            return failed("code_forge", f"fix failed: {e}")

    # ── forge: full pipeline ──────────────────────────────────────────────
    if action in ("forge", "build", "auto"):
        if not intent and not file_path and not code_in:
            return failed(
                "code_forge",
                "intent (new code) or file_path (fix existing) is required for forge",
            )

        # Existing file → fix pipeline
        if file_path and not intent:
            return code_forge({
                **params,
                "action": "fix",
                "file_path": file_path,
                "max_rounds": max_rounds,
                "timeout": timeout,
                "run": run_after,
            })

        if not intent:
            return failed("code_forge", "intent is required to forge new code")

        try:
            code = _generate_code(intent)
        except Exception as e:
            return failed("code_forge", f"generation failed: {e}")

        path = _resolve_path(file_path, default_name="forged.py")
        a = _analyze(code)
        rounds = 0
        log: list[str] = []

        # static fix loop
        while not a["ok"] and rounds < max_rounds:
            log.append(f"static_round_{rounds+1}: {a['problems'][:2]}")
            code = _fix_code(code, _analysis_blob(a), intent)
            a = _analyze(code)
            rounds += 1

        if not a["ok"]:
            if save:
                _write_py(path, code)
            return failed(
                "code_forge",
                "could not fix static errors",
                rounds=rounds,
                problems="; ".join(a["problems"]),
                path=str(path),
                preview=code[:800],
            )

        _write_py(path, code)
        run_info = {"ok": True, "stdout": "", "error_summary": None}
        if run_after:
            run_info = _run_py(path, args, timeout)
            while not run_info["ok"] and rounds < max_rounds:
                log.append(f"runtime_round_{rounds+1}")
                code = _fix_code(
                    code,
                    run_info["error_summary"] or run_info["stderr"],
                    intent,
                )
                a = _analyze(code)
                rounds += 1
                if not a["ok"]:
                    continue
                _write_py(path, code)
                run_info = _run_py(path, args, timeout)

        ok = a["ok"] and run_info.get("ok", True)
        _append_hist({
            "at": datetime.now().isoformat(timespec="seconds"),
            "action": "forge",
            "ok": ok,
            "path": str(path),
            "rounds": rounds,
            "intent": intent[:200],
        })

        if ok:
            return done(
                "code_forge",
                action="forge",
                path=str(path),
                rounds=rounds,
                functions=", ".join(a["functions"]) or "(none)",
                output=run_info.get("stdout") or "(no output)",
                log="; ".join(log) if log else "clean_first_try",
            )
        return failed(
            "code_forge",
            run_info.get("error_summary") or "forge failed after max rounds",
            path=str(path),
            rounds=rounds,
            problems="; ".join(a["problems"]) if a["problems"] else "none",
            log="; ".join(log) if log else "",
        )

    return ask(
        "code_forge",
        "what should I do?",
        options=(
            "forge (intent=... full generate+fix loop) | "
            "generate | analyze | fix (file_path=...) | run | status"
        ),
    )


TOOL = {
    "name": "code_forge",
    "description": (
        "Complex Python code generator and self-healing fixer. "
        "forge: from natural language intent, generate a .py file, run static analysis "
        "(ast/py_compile), execute it, and iteratively fix any errors the forge itself "
        "detects (syntax or runtime) up to max_rounds. "
        "fix: load any existing .py, diagnose (analyze and/or run), and rewrite until clean. "
        "analyze: static review only. generate: write without run loop. run: execute a file. "
        "Use for non-trivial Python modules that must actually work. "
        "For multi-file project scaffolding prefer dev_agent; for quick multi-language edits prefer code_helper."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "forge | generate | analyze | fix | run | status",
            },
            "intent": {
                "type": "STRING",
                "description": "Natural language description of the code to build or the goal when fixing",
            },
            "file_path": {
                "type": "STRING",
                "description": "Target .py path (existing for fix/run, destination for generate/forge)",
            },
            "code": {
                "type": "STRING",
                "description": "Inline Python source (analyze/fix without a file)",
            },
            "error": {
                "type": "STRING",
                "description": "Optional error text for fix; if omitted, forge diagnoses itself",
            },
            "max_rounds": {
                "type": "NUMBER",
                "description": "Max generate/fix iterations (1–6, default 3)",
            },
            "timeout": {
                "type": "NUMBER",
                "description": "Seconds for test runs (default 30)",
            },
            "args": {
                "type": "STRING",
                "description": "CLI args when running the script",
            },
            "run": {
                "type": "BOOLEAN",
                "description": "After static OK, execute the file (default true for forge/fix)",
            },
            "save": {
                "type": "BOOLEAN",
                "description": "Write result to disk (default true)",
            },
        },
        "required": [],
    },
    "handler": code_forge,
    "tier": "core",
}
