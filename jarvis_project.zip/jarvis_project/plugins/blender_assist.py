"""
blender_assist — control and script Blender (3D modeling) from JARVIS.

Does NOT replace artistic judgment. It:
  • finds/opens Blender
  • runs short bpy snippets (foreground or --background)
  • scaffolds common ops (cube, UV sphere, export FBX/GLTF, render still)
  • lists objects in a .blend via a one-shot background query

Uses core.engine_bridge when available. Requires Blender on PATH or BLENDER_PATH / standard install locations.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

PLUGIN = {
    "name": "blender_assist",
    "description": (
        "Ajuda a modelar e automatizar o Blender (3D). "
        "Use quando o usuário pedir para abrir o Blender, criar mesh básico "
        "(cubo, esfera), rodar um script bpy, exportar FBX/GLTF, renderizar "
        "um frame ou listar objetos de um .blend. "
        "NÃO use para jogos Roblox (use roblox_assist) nem para editar foto 2D. "
        "Ações: status | open | run_script | add_mesh | export | render | list_objects."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "status | open | run_script | add_mesh | export | render | list_objects"
                ),
            },
            "script": {
                "type": "STRING",
                "description": "Código Python bpy para action=run_script",
            },
            "mesh": {
                "type": "STRING",
                "description": "cube | uv_sphere | plane | cylinder | monkey (add_mesh)",
            },
            "blend_path": {
                "type": "STRING",
                "description": "Caminho de arquivo .blend (opcional)",
            },
            "output": {
                "type": "STRING",
                "description": "Caminho de saída para export/render",
            },
            "format": {
                "type": "STRING",
                "description": "fbx | gltf | obj | stl (export)",
            },
            "background": {
                "type": "STRING",
                "description": "true = rodar sem UI (batch)",
            },
        },
        "required": [],
    },
}


def _log(player, msg: str) -> None:
    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass


def _blender_bin() -> Optional[str]:
    env = os.environ.get("BLENDER_PATH") or os.environ.get("BLENDER")
    if env and Path(env).is_file():
        return env
    which = shutil.which("blender")
    if which:
        return which
    system = platform.system()
    candidates: list[Path] = []
    if system == "Windows":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        candidates += list(Path(pf).glob("Blender Foundation/Blender */blender.exe"))
        candidates += list(Path(pf).glob("Blender Foundation/Blender/blender.exe"))
    elif system == "Darwin":
        candidates += [
            Path("/Applications/Blender.app/Contents/MacOS/Blender"),
            Path.home() / "Applications/Blender.app/Contents/MacOS/Blender",
        ]
    else:
        candidates += [
            Path("/usr/bin/blender"),
            Path("/usr/local/bin/blender"),
            Path("/snap/bin/blender"),
        ]
    for c in candidates:
        if c.is_file():
            return str(c)
    return None


def _run_blender(
    args: list[str],
    *,
    background: bool = True,
    timeout: int = 120,
) -> tuple[int, str, str]:
    bin_path = _blender_bin()
    if not bin_path:
        return 127, "", "Blender not found (install it or set BLENDER_PATH)"
    cmd = [bin_path]
    if background:
        cmd.append("--background")
    cmd += args
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"
    except Exception as e:
        return 1, "", f"{type(e).__name__}: {e}"


def _write_temp_script(code: str) -> Path:
    fd, name = tempfile.mkstemp(prefix="jarvis_bpy_", suffix=".py")
    os.close(fd)
    path = Path(name)
    path.write_text(code, encoding="utf-8")
    return path


_MESH_OPS = {
    "cube": "bpy.ops.mesh.primitive_cube_add()",
    "uv_sphere": "bpy.ops.mesh.primitive_uv_sphere_add()",
    "plane": "bpy.ops.mesh.primitive_plane_add()",
    "cylinder": "bpy.ops.mesh.primitive_cylinder_add()",
    "monkey": "bpy.ops.mesh.primitive_monkey_add()",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    params = parameters or {}
    action = str(params.get("action") or "status").strip().lower()
    background = str(params.get("background") or "true").lower() in ("1", "true", "yes", "")

    if action in ("status", "info", ""):
        bin_path = _blender_bin()
        return (
            f"status=done action=blender_assist detail=status "
            f"blender={'found:' + bin_path if bin_path else 'not_found'} "
            f"hint=set BLENDER_PATH if needed"
        )

    if action == "open":
        bin_path = _blender_bin()
        if not bin_path:
            return "status=failed action=blender_assist reason=blender_not_found"
        blend = params.get("blend_path") or ""
        cmd = [bin_path]
        if blend:
            cmd.append(str(blend))
        try:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            _log(player, f"Blender opened ({blend or 'empty scene'})")
            return f"status=started action=blender_assist detail=open path={blend or 'empty'}"
        except Exception as e:
            return f"status=failed action=blender_assist reason={e}"

    if action == "run_script":
        script = params.get("script") or ""
        if not script.strip():
            return "status=ask action=blender_assist question=script bpy code?"
        # Safety: refuse obvious destructive filesystem ops outside blender API surface
        lowered = script.lower()
        if any(x in lowered for x in ("os.remove(", "shutil.rmtree", "subprocess", "socket")):
            return (
                "status=failed action=blender_assist "
                "reason=script_blocked_unsafe_calls"
            )
        wrapped = (
            "import bpy\n"
            + script
            + "\nprint('JARVIS_BPY_OK')\n"
        )
        path = _write_temp_script(wrapped)
        try:
            args = []
            if params.get("blend_path"):
                args.append(str(params["blend_path"]))
            args += ["--python", str(path)]
            code, out, err = _run_blender(args, background=True, timeout=180)
            if code != 0 or "JARVIS_BPY_OK" not in out + err:
                return (
                    f"status=failed action=blender_assist reason=script_failed "
                    f"code={code} err={err[-400:]!r}"
                )
            return "status=done action=blender_assist detail=run_script"
        finally:
            path.unlink(missing_ok=True)

    if action == "add_mesh":
        mesh = str(params.get("mesh") or "cube").strip().lower()
        op = _MESH_OPS.get(mesh)
        if not op:
            return (
                "status=ask action=blender_assist question=mesh? "
                "options=cube|uv_sphere|plane|cylinder|monkey"
            )
        script = (
            "import bpy\n"
            f"{op}\n"
            "obj = bpy.context.active_object\n"
            "print('ADDED', obj.name if obj else 'none')\n"
        )
        if params.get("blend_path"):
            # open, add, save
            blend = Path(params["blend_path"])
            script += f"bpy.ops.wm.save_as_mainfile(filepath=r'{blend}')\n"
        path = _write_temp_script(script)
        try:
            args = []
            if params.get("blend_path") and Path(params["blend_path"]).is_file():
                args.append(str(params["blend_path"]))
            args += ["--python", str(path)]
            code, out, err = _run_blender(args, background=True)
            if code != 0:
                return f"status=failed action=blender_assist reason=add_mesh code={code}"
            return f"status=done action=blender_assist detail=add_mesh mesh={mesh}"
        finally:
            path.unlink(missing_ok=True)

    if action == "export":
        out_path = params.get("output")
        fmt = str(params.get("format") or "gltf").lower()
        blend = params.get("blend_path")
        if not out_path or not blend:
            return "status=ask action=blender_assist question=blend_path and output required"
        exporters = {
            "fbx": f"bpy.ops.export_scene.fbx(filepath=r'{out_path}')",
            "gltf": f"bpy.ops.export_scene.gltf(filepath=r'{out_path}')",
            "obj": f"bpy.ops.wm.obj_export(filepath=r'{out_path}')",
            "stl": f"bpy.ops.export_mesh.stl(filepath=r'{out_path}')",
        }
        exp = exporters.get(fmt)
        if not exp:
            return "status=ask action=blender_assist question=format=fbx|gltf|obj|stl"
        script = "import bpy\n" + exp + "\nprint('EXPORTED')\n"
        path = _write_temp_script(script)
        try:
            code, out, err = _run_blender(
                [str(blend), "--python", str(path)], background=True, timeout=180
            )
            if code != 0:
                return f"status=failed action=blender_assist reason=export err={err[-300:]!r}"
            return f"status=done action=blender_assist detail=export format={fmt} output={out_path}"
        finally:
            path.unlink(missing_ok=True)

    if action == "render":
        out_path = params.get("output") or str(Path.home() / "jarvis_blender_render.png")
        blend = params.get("blend_path")
        script = (
            "import bpy\n"
            f"bpy.context.scene.render.filepath = r'{out_path}'\n"
            "bpy.ops.render.render(write_still=True)\n"
            "print('RENDERED')\n"
        )
        path = _write_temp_script(script)
        try:
            args = []
            if blend:
                args.append(str(blend))
            args += ["--python", str(path)]
            code, out, err = _run_blender(args, background=True, timeout=300)
            if code != 0:
                return f"status=failed action=blender_assist reason=render code={code}"
            return f"status=done action=blender_assist detail=render output={out_path}"
        finally:
            path.unlink(missing_ok=True)

    if action == "list_objects":
        blend = params.get("blend_path")
        if not blend:
            return "status=ask action=blender_assist question=blend_path?"
        script = (
            "import bpy\n"
            "names = [o.name + ':' + o.type for o in bpy.data.objects]\n"
            "print('OBJECTS_JSON=' + str(names))\n"
        )
        path = _write_temp_script(script)
        try:
            code, out, err = _run_blender(
                [str(blend), "--python", str(path)], background=True
            )
            blob = out + err
            marker = "OBJECTS_JSON="
            if marker not in blob:
                return f"status=failed action=blender_assist reason=list_failed code={code}"
            line = [ln for ln in blob.splitlines() if marker in ln][-1]
            data = line.split(marker, 1)[1]
            return f"status=done action=blender_assist detail=list_objects objects={data}"
        finally:
            path.unlink(missing_ok=True)

    return (
        "status=ask action=blender_assist "
        "question=action? options=status|open|run_script|add_mesh|export|render|list_objects"
    )
