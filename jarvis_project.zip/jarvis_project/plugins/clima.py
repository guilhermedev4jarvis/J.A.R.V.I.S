"""
Plugin: clima — previsão do tempo falada (sem abrir navegador).

Exemplos de fala:
- "como está o tempo em São Paulo?"
- "vai chover amanhã em Curitiba?"
- "previsão do tempo para o Rio esta semana"
- "qual a temperatura agora?"
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Optional
from urllib.parse import quote_plus

import requests

PLUGIN = {
    "name": "clima",
    "description": (
        "Retorna a previsão do tempo FALADA (temperatura, condição, chance de chuva, vento). "
        "Use SEMPRE esta ferramenta quando o usuário quiser OUIR o clima, "
        "em vez de weather_report (que só abre o navegador). "
        "Aceita cidade + período (hoje, agora, amanhã, esta semana). "
        "Se a cidade não for dita, tenta usar a última cidade mencionada na conversa."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "cidade": {
                "type": "STRING",
                "description": (
                    "Nome da cidade (ex: 'São Paulo', 'Curitiba', 'Rio de Janeiro'). "
                    "Se vazio, tenta inferir da conversa."
                ),
            },
            "quando": {
                "type": "STRING",
                "description": (
                    "Período desejado: 'agora', 'hoje', 'amanhã', 'esta semana' ou "
                    "uma data no formato YYYY-MM-DD. Padrão: 'hoje'."
                ),
            },
        },
        "required": [],
    },
}

# ── Constantes ──────────────────────────────────────────────────────────────

_WMO = {
    0: "céu limpo",
    1: "principalmente limpo",
    2: "parcialmente nublado",
    3: "nublado",
    45: "neblina",
    48: "neblina com geada",
    51: "garoa leve",
    53: "garoa moderada",
    55: "garoa intensa",
    56: "garoa gelada leve",
    57: "garoa gelada intensa",
    61: "chuva leve",
    63: "chuva moderada",
    65: "chuva forte",
    66: "chuva gelada leve",
    67: "chuva gelada forte",
    71: "neve leve",
    73: "neve moderada",
    75: "neve intensa",
    77: "grãos de neve",
    80: "pancadas de chuva leves",
    81: "pancadas de chuva moderadas",
    82: "pancadas de chuva fortes",
    85: "pancadas de neve leves",
    86: "pancadas de neve fortes",
    95: "tempestade",
    96: "tempestade com granizo leve",
    99: "tempestade com granizo forte",
}

_GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
_TIMEOUT = 8


# ── Helpers ─────────────────────────────────────────────────────────────────

def _geocode(cidade: str) -> Optional[dict]:
    """Retorna {name, latitude, longitude, admin1, country} ou None."""
    try:
        r = requests.get(
            _GEOCODE_URL,
            params={
                "name": cidade,
                "count": 5,
                "language": "pt",
                "format": "json",
            },
            timeout=_TIMEOUT,
        )
        r.raise_for_status()
        results = r.json().get("results") or []
        if not results:
            return None

        # Preferência: Brasil > outros
        for item in results:
            if (item.get("country_code") or "").upper() == "BR":
                return item
        return results[0]
    except Exception:
        return None


def _fetch_forecast(lat: float, lon: float) -> Optional[dict]:
    try:
        r = requests.get(
            _FORECAST_URL,
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation",
                "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max",
                "timezone": "auto",
                "forecast_days": 7,
            },
            timeout=_TIMEOUT,
        )
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


def _condicao(code: int) -> str:
    return _WMO.get(int(code), "condição desconhecida")


def _normaliza_quando(quando: str) -> str:
    q = (quando or "hoje").strip().lower()
    mapa = {
        "agora": "agora",
        "hoje": "hoje",
        "amanha": "amanhã",
        "amanhã": "amanhã",
        "essa semana": "semana",
        "esta semana": "semana",
        "semana": "semana",
        "proximos dias": "semana",
        "próximos dias": "semana",
    }
    return mapa.get(q, q)


def _formata_agora(current: dict, nome_cidade: str) -> str:
    temp = current.get("temperature_2m")
    sensacao = current.get("apparent_temperature")
    umid = current.get("relative_humidity_2m")
    vento = current.get("wind_speed_10m")
    precip = current.get("precipitation") or 0
    code = current.get("weather_code", 0)

    partes = [f"Em {nome_cidade} agora está {_condicao(code)}"]
    if temp is not None:
        partes.append(f"com {temp:.0f} graus")
    if sensacao is not None and abs(sensacao - (temp or 0)) >= 2:
        partes.append(f"(sensação de {sensacao:.0f})")
    if umid is not None:
        partes.append(f"umidade de {umid:.0f}%")
    if vento is not None and vento >= 15:
        partes.append(f"vento de {vento:.0f} km/h")
    if precip and precip > 0.1:
        partes.append(f"e chovendo ({precip:.1f} mm)")

    texto = ", ".join(partes) + "."
    return texto[0].upper() + texto[1:]


def _formata_dia(daily: dict, idx: int, nome_cidade: str, rotulo: str) -> str:
    try:
        tmax = daily["temperature_2m_max"][idx]
        tmin = daily["temperature_2m_min"][idx]
        code = daily["weather_code"][idx]
        chance = daily.get("precipitation_probability_max", [None])[idx]
        chuva = daily.get("precipitation_sum", [0])[idx] or 0
    except (IndexError, KeyError, TypeError):
        return f"Não consegui a previsão de {rotulo} para {nome_cidade}."

    partes = [f"{rotulo} em {nome_cidade}: {_condicao(code)}"]
    partes.append(f"máxima de {tmax:.0f} e mínima de {tmin:.0f} graus")

    if chance is not None and chance >= 30:
        partes.append(f"chance de chuva de {chance:.0f}%")
    if chuva and chuva >= 1:
        partes.append(f"com previsão de {chuva:.1f} mm")

    texto = ", ".join(partes) + "."
    return texto[0].upper() + texto[1:]


def _formata_semana(daily: dict, nome_cidade: str) -> str:
    dias = daily.get("time") or []
    if not dias:
        return f"Não consegui a previsão semanal para {nome_cidade}."

    linhas = [f"Previsão para os próximos dias em {nome_cidade}:"]
    nomes_dia = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo"]

    for i, data_str in enumerate(dias[:5]):  # até 5 dias
        try:
            dt = datetime.strptime(data_str, "%Y-%m-%d")
            nome = nomes_dia[dt.weekday()]
            tmax = daily["temperature_2m_max"][i]
            tmin = daily["temperature_2m_min"][i]
            code = daily["weather_code"][i]
            chance = (daily.get("precipitation_probability_max") or [None])[i]

            trecho = f"{nome}: {_condicao(code)}, {tmin:.0f} a {tmax:.0f}°"
            if chance is not None and chance >= 40:
                trecho += f", {chance:.0f}% de chuva"
            linhas.append(trecho)
        except Exception:
            continue

    return ". ".join(linhas) + "."


# ── Entry point ─────────────────────────────────────────────────────────────

def run(parameters: dict, player=None, session_memory=None) -> str:
    cidade = (parameters.get("cidade") or "").strip()
    quando_raw = parameters.get("quando") or "hoje"
    quando = _normaliza_quando(quando_raw)

    if not cidade:
        return (
            "Sir, preciso saber a cidade. "
            "Pode dizer, por exemplo: clima em São Paulo, ou previsão para Curitiba amanhã."
        )

    geo = _geocode(cidade)
    if not geo:
        return f"Sir, não encontrei a cidade '{cidade}'. Pode tentar com o nome completo?"

    nome = geo.get("name") or cidade
    admin = geo.get("admin1") or ""
    if admin and admin.lower() not in nome.lower():
        nome_completo = f"{nome}, {admin}"
    else:
        nome_completo = nome

    lat = geo["latitude"]
    lon = geo["longitude"]

    data = _fetch_forecast(lat, lon)
    if not data:
        return f"Sir, não consegui buscar o clima de {nome_completo} no momento. Tente novamente em instantes."

    current = data.get("current") or {}
    daily = data.get("daily") or {}

    try:
        if quando in ("agora", "hoje"):
            # Se for "hoje" e ainda for manhã/tarde, dá o atual + resumo do dia
            if quando == "agora":
                msg = _formata_agora(current, nome_completo)
            else:
                atual = _formata_agora(current, nome_completo)
                resumo = _formata_dia(daily, 0, nome_completo, "Para o restante do dia")
                msg = f"{atual} {resumo}"
        elif quando == "amanhã":
            msg = _formata_dia(daily, 1, nome_completo, "Amanhã")
        elif quando == "semana":
            msg = _formata_semana(daily, nome_completo)
        else:
            # Tenta interpretar como data YYYY-MM-DD
            try:
                alvo = datetime.strptime(quando, "%Y-%m-%d").date()
                datas = [datetime.strptime(d, "%Y-%m-%d").date() for d in (daily.get("time") or [])]
                if alvo in datas:
                    idx = datas.index(alvo)
                    rotulo = "Nesse dia" if idx > 1 else ("Amanhã" if idx == 1 else "Hoje")
                    msg = _formata_dia(daily, idx, nome_completo, rotulo)
                else:
                    msg = f"Sir, só tenho previsão para os próximos 7 dias. Pediu {quando}."
            except ValueError:
                msg = _formata_agora(current, nome_completo)
    except Exception as e:
        return f"Sir, ocorreu um erro ao montar a previsão: {e}"

    if player:
        try:
            player.write_log(f"JARVIS: {msg}")
        except Exception:
            pass

    return msg
