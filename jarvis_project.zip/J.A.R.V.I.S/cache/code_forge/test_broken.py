def broken(
    pass
