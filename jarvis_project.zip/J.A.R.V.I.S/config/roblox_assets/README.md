# Roblox Studio Bridge (JARVIS)

## Instalar o plugin Luau

1. Abra a pasta de plugins do Studio:
   - Windows: `%LOCALAPPDATA%\Roblox\Plugins`
   - macOS: `~/Documents/Roblox/Plugins` (ou via Studio → Plugins → Plugins Folder)
2. Copie `studio_bridge_plugin.lua` para essa pasta (renomeie se quiser).
3. Reinicie o Roblox Studio.
4. No JARVIS: `roblox_assist action=bridge_start`
5. No Studio, clique **Connect** na toolbar **JARVIS Bridge**.
6. HttpService precisa permitir pedidos locais (em jogo/plugin conforme politica do Studio).

## Fluxo de modelagem

```text
roblox_assist action=bridge_start
roblox_assist action=build_live structure=house width=30 height=14
roblox_assist action=export_rbxmx structure=tower floors=4 output=~/RobloxProjects/t.rbxmx
roblox_assist action=blender_mesh name=PropA prompt="low poly crate" format=fbx
```
