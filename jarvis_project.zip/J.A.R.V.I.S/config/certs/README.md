# Generated at runtime by dashboard/server.py (_ensure_certs).
# Never commit jarvis.key or jarvis.crt — they are machine-specific.
