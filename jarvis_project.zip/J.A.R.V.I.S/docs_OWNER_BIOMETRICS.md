# Cadastro do dono e ações críticas

## Primeira inicialização

Se faltar qualquer um destes arquivos em `memory/biometrics/`, o JARVIS considera o cadastro incompleto:

| Arquivo | Conteúdo |
|---------|----------|
| `vozdono.mp3` | Sua voz dizendo o comando (ex.: “ok jarvis”, “acorda jarvis”) |
| `fotobase1.jpg` | Rosto de **frente** |
| `fotobase2.jpg` | Rosto de **um lado** |
| `fotobase3.jpg` | Rosto do **outro lado** |
| `owner_command.json` | Frase escolhida (`{"phrase": "ok jarvis"}`) |

Na subida, o terminal/HUD avisa o que falta.

### Via tool

```text
owner_setup action=set_phrase phrase="ok jarvis"
owner_setup action=enroll_voice path=/caminho/sua_gravacao.wav
owner_setup action=enroll_face slot=1 image_path=/fotos/frente.jpg
owner_setup action=enroll_face slot=2 image_path=/fotos/lado_a.jpg
owner_setup action=enroll_face slot=3 image_path=/fotos/lado_b.jpg
owner_setup action=status
```

Webcam (se OpenCV + câmera):

```text
owner_setup action=enroll_face slot=1 camera=true
```

Você também pode **copiar** os arquivos prontos para `memory/biometrics/` com esses nomes; na próxima verificação a tool reconstrói o perfil.

## Ações críticas (shutdown / restart / reset)

Fluxo:

1. Biometria do dono — **voz OU câmera/foto** (não precisa dos dois)
2. Banner CONFIRM no HUD (como antes)
3. Só então executa

Exemplos:

```text
computer_settings action=shutdown owner_voice_path=/tmp/probe.wav
computer_settings action=restart owner_camera=true
computer_settings action=shutdown owner_image_path=/tmp/selfie.jpg
```

Sem biometria a tool responde `status=ask` e **não desliga nada**.

## Dependências

- Voz: `numpy` (+ `ffmpeg` no PATH se o áudio for MP3)
- Face: `opencv-python` (4.x) e/ou `face_recognition`
- Confirmação na tela: UI ligada (`core.confirm`)
