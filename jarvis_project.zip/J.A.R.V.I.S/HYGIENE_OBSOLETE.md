# Arquivos candidatos a remoção segura (Frente 5)

Não removidos automaticamente — revise antes de apagar:

| Caminho | Motivo |
|---------|--------|
| `readme.md.bak_en` | Backup de README em inglês |
| `updates/` (artefatos antigos de patch, se houver) | Revisar conteúdo |
| `plugins/pending/*` após promoção | `monitor_tool.py` e `hwmonitor_integration.py` já copiados para `plugins/` |
| `cache/**` gerado | Regenerável |
| `memory/backups/long_term_*.json` além dos 8 mais recentes | Já podado pelo compactor |

Módulos estáveis promovidos:
- `plugins/monitor_tool.py`
- `plugins/hwmonitor_integration.py`
