# Novas actions — MARK LVI

## Implementadas neste pacote

| Action | Arquivo | O que faz |
|--------|---------|-----------|
| `network_status` | `actions/network_status.py` | Hostname, IP local, IP público, se há internet |
| `unit_convert` | `actions/unit_convert.py` | Converte comprimento, massa, temperatura, volume, velocidade, dados |
| `quick_note` | `actions/quick_note.py` | Notas em `~/.jarvis/notes/*.md` (+ opcional memória de longo prazo) |

São descobertas automaticamente pelo `core.action_loader` (dict `TOOL` + handler).


## Implementadas a pedido (extrato / OCR / games)

| Action | Arquivo | O que faz |
|--------|---------|-----------|
| `bank_statement` | `actions/bank_statement.py` | Analisa extrato CSV/OFX/texto/PDF: categorias, economia, reserva/investir (educativo) |
| `screenshot_ocr` | `actions/screenshot_ocr.py` | Print da tela ou imagem → texto (Tesseract local ou Gemini vision) |
| `game_helper` | `actions/game_helper.py` | Coach de games: tips, counter, build, checklist, lookup |

## Ideias para as próximas

1. **`calendar_today`** — agenda do dia (Google Calendar OAuth ou `.ics` local).
2. **`pomodoro`** — ciclos 25/5 com notificação OS (complementa `focus_timer` / `timer`).
3. **`clipboard_history`** — últimas N entradas do clipboard (com cuidado de privacidade).
4. **`wifi_control`** — listar redes / status (Windows `netsh`, Linux `nmcli`).
5. **`screenshot_ocr`** — captura + OCR (Tesseract) para “o que está escrito na tela”.
6. **`expense_log`** — registrar gasto rápido em CSV/SQLite (“gastei 40 no almoço”).
7. **`git_status_summary`** — `git status` + diff resumido no repo atual.
8. **`translate_text`** — traduzir trecho (API ou modelo local pipeline).
9. **`volume_mixer`** — volume por app (Windows Core Audio / Pulse `pactl`).
10. **`smart_home_toggle`** — ligar/desligar dispositivo Tuya/MQTT (há deps opcionais no requirements).
11. **`meeting_join`** — abrir link Zoom/Meet a partir da agenda ou clipboard.
12. **`disk_hog`** — top pastas que mais ocupam espaço em um diretório.
13. **`speedtest_lite`** — estimativa de latência/download sem instalar speedtest-cli.
14. **`password_gen`** — gerar senha forte e (opcional) copiar para o clipboard.
15. **`read_aloud_selection`** — ler a seleção atual do SO / último clipboard.

Prioridade sugerida se o foco for produtividade diária: **calendar_today**, **git_status_summary**, **expense_log**, **screenshot_ocr**.
