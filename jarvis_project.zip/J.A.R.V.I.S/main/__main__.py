"""python -m main"""
from main.lifecycle import main

if __name__ == "__main__":
    main()
