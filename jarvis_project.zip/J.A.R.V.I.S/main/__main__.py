"""python -m main

Stage-1 pre-boot password gate runs BEFORE importing the heavy lifecycle /
app stack (Gemini, providers, actions, dashboard, camera).
"""
from __future__ import annotations

# ── Stage 1: password gate (minimal imports only) ────────────────────────────
from core.preboot_gate import run_preboot_gate

run_preboot_gate()

# ── Stage 2+: full system ────────────────────────────────────────────────────
from main.lifecycle import main

if __name__ == "__main__":
    main()
