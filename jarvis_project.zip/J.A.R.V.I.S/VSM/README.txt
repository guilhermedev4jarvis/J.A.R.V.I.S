Place VSM.exe here (house camera client). JARVIS looks for VSM/VSM.exe relative to the project root.
