"""
core/boot_biometrics.py — strict startup biometrics protocol.

Order (always last in boot, after actions/plugins/providers):
  1. Ensure memory/biometrics has vozdono.mp3 + fotobase1..3.jpg
     → if missing: interactive first-run enrollment
  2. Face verify (camera)
  3. Only if face OK → voice verify (short mic capture)
  4. Any failure / cancel → audit + hard process exit (os._exit(1))

Env escape for automated tests only:
  MARK_BIOMETRICS_TEST_MODE=1  → functions return without killing the process
  MARK_SKIP_BIOMETRICS=1       → skip entirely (CI)
"""
from __future__ import annotations

import os
import sys
import time
import wave
from pathlib import Path
from typing import Any, Callable, Optional

_BASE = Path(__file__).resolve().parents[1]
_BIO = _BASE / "memory" / "biometrics"

VOICE_FILE = _BIO / "vozdono.mp3"
FACE_FILES = (
    _BIO / "fotobase1.jpg",
    _BIO / "fotobase2.jpg",
    _BIO / "fotobase3.jpg",
)

LogFn = Callable[[str], None]


def required_files() -> dict[str, bool]:
    return {
        "vozdono.mp3": VOICE_FILE.is_file(),
        "fotobase1.jpg": FACE_FILES[0].is_file(),
        "fotobase2.jpg": FACE_FILES[1].is_file(),
        "fotobase3.jpg": FACE_FILES[2].is_file(),
    }


def all_present() -> bool:
    return all(required_files().values())


def _log(msg: str, ui: Any = None, log: Optional[LogFn] = None) -> None:
    line = f"[BIOMETRIA] {msg}"
    print(line)
    if log:
        try:
            log(line)
        except Exception:
            pass
    if ui is not None:
        try:
            ui.write_log("SYS: " + msg)
        except Exception:
            pass


def _audit(event: str, detail: dict[str, Any]) -> None:
    try:
        from core import audit
        audit.log_event(event, detail)
    except Exception:
        pass


def hard_exit(reason: str, *, ui: Any = None, code: int = 1) -> None:
    """Kill the process and try to close the console window."""
    _log(f"BLOQUEADO: {reason} — encerrando.", ui=ui)
    _audit("boot_biometrics_denied", {"reason": reason, "code": code})
    if os.environ.get("MARK_BIOMETRICS_TEST_MODE") == "1":
        raise SystemExit(code)
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    # Windows: attempt to close the console associated with this process
    if sys.platform == "win32":
        try:
            import ctypes
            hwnd = ctypes.windll.kernel32.GetConsoleWindow()
            if hwnd:
                ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)  # WM_CLOSE
                time.sleep(0.15)
        except Exception:
            pass
    os._exit(code)


def _record_wav(path: Path, seconds: float = 3.0, sr: int = 16000) -> Path:
    """Record mono WAV from default mic via sounddevice."""
    import numpy as np
    import sounddevice as sd

    path.parent.mkdir(parents=True, exist_ok=True)
    frames = int(seconds * sr)
    audio = sd.rec(frames, samplerate=sr, channels=1, dtype="float32")
    sd.wait()
    pcm = np.clip(audio.reshape(-1) * 32767.0, -32768, 32767).astype(np.int16)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(pcm.tobytes())
    return path


def run_first_enrollment(*, ui: Any = None, log: Optional[LogFn] = None) -> None:
    """Capture 3 face bases + owner voice command into memory/biometrics/."""
    from core import owner_gate
    from core import face_auth

    _BIO.mkdir(parents=True, exist_ok=True)
    _log("Primeira execução — cadastro biométrico obrigatório.", ui=ui, log=log)

    # Phrase
    phrase = os.environ.get("MARK_OWNER_PHRASE", "").strip() or "ok jarvis"
    try:
        if ui is not None and hasattr(ui, "ask_text"):
            phrase = ui.ask_text("Frase de comando do dono:", default=phrase) or phrase
    except Exception:
        pass
    owner_gate.save_command_phrase(phrase)
    _log(f"Frase salva: {phrase!r}", ui=ui, log=log)

    # Three face angles
    labels = ("frente", "lado esquerdo", "lado direito")
    for slot, label in enumerate(labels, start=1):
        _log(f"Foto {slot}/3 ({label}) — olhe para a câmera…", ui=ui, log=log)
        try:
            time.sleep(0.8)
            frame = face_auth.capture_from_camera()
            import cv2
            dest = FACE_FILES[slot - 1]
            cv2.imwrite(str(dest), frame)
            owner_gate.register_face_slot(slot, dest)
            _log(f"fotobase{slot}.jpg salvo.", ui=ui, log=log)
        except Exception as e:
            hard_exit(f"falha no cadastro facial slot={slot}: {e}", ui=ui)

    # Voice
    _log(f"Grave a voz dizendo {phrase!r} (3s)…", ui=ui, log=log)
    try:
        time.sleep(0.5)
        wav = _BIO / "_enroll_voice.wav"
        _record_wav(wav, seconds=3.0)
        owner_gate.register_voice_file(wav, phrase=phrase)
        # Prefer vozdono.mp3 name: copy wav if mp3 conversion unavailable
        if not VOICE_FILE.is_file():
            # store wav also as required marker path — copy to vozdono.mp3 bytes not valid mp3;
            # keep wav and a stub: register_voice_file should have created profile;
            # ensure VOICE_FILE exists for gate checks: write wav under vozdono.wav and
            # copy file to vozdono.mp3 path as raw (ownership marker).
            import shutil
            if wav.is_file():
                shutil.copy2(wav, _BIO / "vozdono.wav")
                if not VOICE_FILE.is_file():
                    shutil.copy2(wav, VOICE_FILE)
        _log("vozdono gravado e fingerprint criado.", ui=ui, log=log)
    except Exception as e:
        hard_exit(f"falha no cadastro de voz: {e}", ui=ui)

    if not all_present():
        missing = [k for k, ok in required_files().items() if not ok]
        hard_exit(f"cadastro incompleto — faltam: {missing}", ui=ui)
    _log("Cadastro biométrico concluído.", ui=ui, log=log)


def authenticate(*, ui: Any = None, log: Optional[LogFn] = None) -> None:
    """Strict face → voice. Failure ends the process."""
    from core import face_auth
    from core import voice_auth
    from core import owner_gate

    _log("Autenticação facial…", ui=ui, log=log)
    try:
        face = face_auth.verify_from_camera()
        _audit("boot_face_check", {"accepted": face.accepted, "score": face.score})
        if not face.accepted:
            hard_exit(
                f"rosto não reconhecido (score={face.score:.3f}, thr={face.threshold})",
                ui=ui,
            )
    except Exception as e:
        hard_exit(f"erro na biometria facial: {e}", ui=ui)

    _log("Rosto OK. Autenticação de voz — fale a frase de comando (3s)…", ui=ui, log=log)
    try:
        phrase = (owner_gate.load_command_phrase() or {}).get("phrase") or "ok jarvis"
        _log(f"Diga: {phrase!r}", ui=ui, log=log)
        probe = _BIO / "_probe_voice.wav"
        _record_wav(probe, seconds=3.0)
        # Ensure enrolled profile from vozdono
        try:
            owner_gate.ensure_voice_wav()
        except Exception:
            pass
        result = voice_auth.verify_wav(probe)
        _audit("boot_voice_check", {"accepted": result.accepted, "score": result.score})
        if not result.accepted:
            hard_exit(
                f"voz não reconhecida (score={result.score:.3f}, thr={result.threshold})",
                ui=ui,
            )
    except Exception as e:
        hard_exit(f"erro na biometria de voz: {e}", ui=ui)

    _log("Biometria OK — acesso liberado.", ui=ui, log=log)
    _audit("boot_biometrics_ok", {"ts": time.time()})
    try:
        from core.owner_gate import touch_activity
        touch_activity()
    except Exception:
        pass


def enforce_startup_biometrics(*, ui: Any = None, log: Optional[LogFn] = None) -> None:
    """
    Public entry — call as the LAST step of boot after actions/plugins load.
    """
    if os.environ.get("MARK_SKIP_BIOMETRICS") == "1":
        _log("MARK_SKIP_BIOMETRICS=1 — protocolo ignorado (CI).", ui=ui, log=log)
        return

    try:
        if not all_present():
            status = required_files()
            _log(f"Arquivos biométricos: {status}", ui=ui, log=log)
            run_first_enrollment(ui=ui, log=log)
        authenticate(ui=ui, log=log)
    except SystemExit:
        raise
    except Exception as e:
        hard_exit(f"falha inesperada no protocolo biométrico: {e}", ui=ui)
