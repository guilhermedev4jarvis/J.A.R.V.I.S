"""boot_biometrics — MASTER PASSWORD mode (biometrics disabled at startup).

Default password: 123jarvis834 (env JARVIS_MASTER_PASSWORD).
Startup never blocks on face/voice capture.
"""
from __future__ import annotations

import os
from typing import Any, Callable, Optional

LogFn = Callable[[str], None]

DEFAULT_PASSWORD = "123jarvis834"


def master_password() -> str:
    return (os.getenv("JARVIS_MASTER_PASSWORD") or DEFAULT_PASSWORD).strip()


def password_ok(candidate: str) -> bool:
    return (candidate or "").strip() == master_password()


def required_files() -> dict[str, bool]:
    return {}


def all_present() -> bool:
    return True


def hard_exit(reason: str = "denied", ui: Any = None) -> None:
    import os as _os
    print(f"[BOOT] hard_exit: {reason}")
    try:
        if ui is not None and hasattr(ui, "write_log"):
            ui.write_log(f"SYS: exit — {reason}")
    except Exception:
        pass
    _os._exit(1)


def enforce_startup_biometrics(ui: Any = None, log: Optional[LogFn] = None) -> bool:
    """Boot is immediate — password gate is only for critical owner actions."""
    msg = "Boot liberado (senha mestra). Biometria de startup desativada."
    print(f"[BOOT] {msg}")
    if log:
        try:
            log(msg)
        except Exception:
            pass
    if ui is not None:
        try:
            ui.write_log("SYS: " + msg)
        except Exception:
            pass
        for name in ("set_biometrics_phase", "update_biometrics", "on_biometrics_phase"):
            fn = getattr(ui, name, None)
            if callable(fn):
                try:
                    fn("done", "Acesso liberado", 1.0)
                except Exception:
                    pass
    return True
