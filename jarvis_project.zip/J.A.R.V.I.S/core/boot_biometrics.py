"""boot_biometrics — Stage-3 facial biometrics after system load.

Stage-1 (pre-boot password) lives in ``core.preboot_gate``.
This module runs only AFTER the UI, providers and actions are loaded.

Flow
----
1. Show biometrics overlay on the HUD.
2. Ensure face profile exists (rebuild from fotobase1/2/3.jpg if needed).
3. Capture camera frame and compare against enrolled profile.
4. On failure → expose "Tentar novamente" without re-asking the pre-boot password.
5. On success → hide overlay and release the HUD.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any, Callable, Optional

LogFn = Callable[[str], None]

# Re-export password helpers from preboot_gate for backward compatibility
from core.preboot_gate import (  # noqa: E402
    DEFAULT_PLAIN as DEFAULT_PASSWORD,
    DEFAULT_HASH,
    expected_hash,
    password_ok,
)

_BASE = Path(__file__).resolve().parents[1]
_BIO = _BASE / "memory" / "biometrics"
FACE_FILES = (
    _BIO / "fotobase1.jpg",
    _BIO / "fotobase2.jpg",
    _BIO / "fotobase3.jpg",
)


def master_password() -> str:
    """Plain master password (env JARVIS_BOOT_PASSWORD or default 123gui834).

    Prefer hash comparison via ``password_ok`` / ``preboot_gate.password_ok``.
    """
    return (os.getenv("JARVIS_BOOT_PASSWORD") or DEFAULT_PASSWORD).strip()


def required_files() -> dict[str, bool]:
    return {p.name: p.is_file() for p in FACE_FILES}


def all_present() -> bool:
    return all(p.is_file() for p in FACE_FILES)


def hard_exit(reason: str = "denied", ui: Any = None) -> None:
    import os as _os
    print(f"[BOOT] hard_exit: {reason}", flush=True)
    try:
        if ui is not None and hasattr(ui, "write_log"):
            ui.write_log(f"SYS: exit — {reason}")
    except Exception:
        pass
    _os._exit(1)


def _log(msg: str, ui: Any = None, log: Optional[LogFn] = None) -> None:
    print(f"[BOOT] {msg}", flush=True)
    if log:
        try:
            log(msg)
        except Exception:
            pass
    if ui is not None:
        try:
            ui.write_log("SYS: " + msg)
        except Exception:
            pass


def _set_phase(ui: Any, phase: str, status: str, progress: float) -> None:
    if ui is None:
        return
    for name in ("set_biometrics_phase", "update_biometrics", "on_biometrics_phase"):
        fn = getattr(ui, name, None)
        if callable(fn):
            try:
                fn(phase, status, progress)
            except Exception:
                pass


def _show_overlay(ui: Any) -> None:
    if ui is None:
        return
    fn = getattr(ui, "show_biometrics_overlay", None)
    if callable(fn):
        try:
            fn()
        except Exception:
            pass


def _hide_overlay(ui: Any) -> None:
    if ui is None:
        return
    fn = getattr(ui, "hide_biometrics_overlay", None)
    if callable(fn):
        try:
            fn()
        except Exception:
            pass


def _wait_retry(ui: Any, reason: str) -> bool:
    if ui is None:
        return False
    fn = getattr(ui, "wait_biometrics_retry", None)
    if callable(fn):
        try:
            return bool(fn(reason))
        except Exception:
            return False
    return False


def _ensure_face_profile() -> bool:
    """Build face_profile.json from fotobase images if missing."""
    from core import face_auth
    from core import owner_gate

    if face_auth.has_profile():
        return True
    if not any(p.is_file() for p in FACE_FILES):
        return False
    try:
        owner_gate._rebuild_face_profile()
    except Exception as e:
        print(f"[BOOT] rebuild face profile failed: {e}", flush=True)
    return face_auth.has_profile()


def _run_face_check(*, require_liveness: bool = False) -> dict[str, Any]:
    """Attempt one facial verification against enrolled profile."""
    from core import face_auth
    from core import owner_gate

    if not face_auth.has_profile():
        if not _ensure_face_profile():
            return {
                "ok": False,
                "accepted": False,
                "detail": "no_face_profile_and_no_fotobase",
                "score": 0.0,
            }

    # Prefer camera path; fall back to static fotobase comparison in headless/test
    skip_cam = (os.getenv("JARVIS_SKIP_CAMERA") or "").strip().lower() in (
        "1", "true", "yes",
    )
    if skip_cam:
        # Offline/test path: verify against fotobase1 itself (should match profile)
        probe = next((p for p in FACE_FILES if p.is_file()), None)
        if probe is None:
            return {"ok": False, "accepted": False, "detail": "no_probe", "score": 0.0}
        score = face_auth.verify_image(probe)
        return {
            "ok": bool(score.accepted),
            "accepted": bool(score.accepted),
            "score": float(score.score),
            "threshold": float(score.threshold),
            "detail": score.detail,
            "method": "face_offline",
        }

    try:
        score = face_auth.verify_from_camera(
            require_liveness=require_liveness,
            liveness_frames=8,
        )
        return {
            "ok": bool(score.accepted),
            "accepted": bool(score.accepted),
            "score": float(score.score),
            "threshold": float(score.threshold),
            "detail": score.detail,
            "method": "face_camera",
        }
    except Exception as e:
        # Last resort: owner_gate helper
        try:
            r = owner_gate.verify_face(camera=True)
            ok = bool(r.get("accepted") or r.get("ok"))
            return {
                "ok": ok,
                "accepted": ok,
                "score": float(r.get("score") or 0.0),
                "detail": r.get("detail") or str(e),
                "method": "face_owner_gate",
            }
        except Exception as e2:
            return {
                "ok": False,
                "accepted": False,
                "detail": f"camera_error: {e2}",
                "score": 0.0,
            }


def enforce_startup_biometrics(ui: Any = None, log: Optional[LogFn] = None) -> bool:
    """Stage-3: facial biometrics after full system load.

    Password was already validated in preboot_gate. This only runs face check
    with retry. Returns True on success; hard-exits only if user abandons after
    repeated failures and the UI offers no retry path.
    """
    # Allow tests / air-gapped CI to skip face gate
    if (os.getenv("JARVIS_SKIP_FACE_BOOT") or "").strip().lower() in (
        "1", "true", "yes", "on",
    ):
        _log("Biometria facial de boot ignorada (JARVIS_SKIP_FACE_BOOT).", ui, log)
        _set_phase(ui, "done", "Acesso liberado (face skip)", 1.0)
        _hide_overlay(ui)
        return True

    _show_overlay(ui)
    _set_phase(ui, "face", "Começando biometria facial.", 0.15)
    _log("Começando biometria facial.", ui, log)

    if not _ensure_face_profile():
        _set_phase(
            ui,
            "failed",
            "Perfil facial ausente (fotobase1/2/3.jpg). Coloque as imagens em memory/biometrics/.",
            0.0,
        )
        _log("Perfil facial ausente — aguardando retry ou abort.", ui, log)
        if _wait_retry(ui, "perfil facial ausente"):
            return enforce_startup_biometrics(ui=ui, log=log)
        # Without a profile we cannot unlock; leave overlay and return False
        # so the caller can decide. Do not hard-exit if UI is interactive.
        if ui is None:
            hard_exit("no_face_profile", ui=ui)
        return False

    max_rounds = 5
    for round_i in range(1, max_rounds + 1):
        _set_phase(
            ui,
            "face",
            f"Posicione o rosto na câmera… (tentativa {round_i}/{max_rounds})",
            0.2 + 0.1 * round_i,
        )
        result = _run_face_check(require_liveness=False)
        if result.get("ok") or result.get("accepted"):
            score = result.get("score", 0.0)
            _set_phase(
                ui,
                "done",
                f"Rosto reconhecido (score={score:.3f}). Acesso liberado.",
                1.0,
            )
            _log(
                f"Biometria facial OK — score={score:.3f} detail={result.get('detail')}",
                ui,
                log,
            )
            try:
                from core import audit
                audit.log_event(
                    "boot_face_ok",
                    tool="boot_biometrics",
                    extra={"score": score, "detail": result.get("detail")},
                )
            except Exception:
                pass
            time.sleep(0.6)
            _hide_overlay(ui)
            return True

        detail = result.get("detail") or "não reconhecido"
        _set_phase(
            ui,
            "failed",
            f"Falha na biometria facial: {detail}",
            0.0,
        )
        _log(f"Face falhou: {detail}", ui, log)
        try:
            from core import audit
            audit.log_event(
                "boot_face_fail",
                tool="boot_biometrics",
                extra={"detail": str(detail), "round": round_i},
            )
        except Exception:
            pass

        if not _wait_retry(ui, str(detail)):
            # User did not click retry (timeout / no UI) → deny
            if ui is None:
                hard_exit(f"face_denied:{detail}", ui=ui)
            _log("Retry não solicitado — mantendo HUD bloqueado.", ui, log)
            return False

    hard_exit("face_max_rounds", ui=ui)
    return False


__all__ = [
    "DEFAULT_PASSWORD",
    "DEFAULT_HASH",
    "master_password",
    "password_ok",
    "expected_hash",
    "required_files",
    "all_present",
    "hard_exit",
    "enforce_startup_biometrics",
]
