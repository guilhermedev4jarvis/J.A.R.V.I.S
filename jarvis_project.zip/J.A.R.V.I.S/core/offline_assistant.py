"""Offline voice-and-tools loop used when Gemini Live cannot be reached.

The local path is deliberately explicit: Llama 3.1 8B handles text and tool
selection, Whisper transcribes Portuguese speech, and Kokoro speaks it locally.
Internet-dependent tools may still be offered by the model, but their failures
are returned to it so it can explain the limit instead of inventing a result.
"""
from __future__ import annotations

import asyncio
import json
import queue
import socket
import time
import uuid
from collections import deque
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import sounddevice as sd


MODEL_NAME = "qwen2.5-coder:7b"
VOICE_NAME = "pf_dora"
SAMPLE_RATE = 16_000
CHANNELS = 1
CHUNK_SIZE = 1024
SPEECH_RMS = 0.012
END_SILENCE_SECONDS = 0.75
MIN_UTTERANCE_SECONDS = 0.30
ONLINE_RETRY_SECONDS = 20


def _config() -> dict:
    path = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def internet_available() -> bool:
    """A lightweight connectivity check; an HTTP response is not required."""
    try:
        with socket.create_connection(("generativelanguage.googleapis.com", 443), timeout=2.0):
            return True
    except OSError:
        return False


def _plain(value):
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if hasattr(value, "model_dump"):
        return _plain(value.model_dump(exclude_none=True))
    if hasattr(value, "to_dict"):
        return _plain(value.to_dict())
    return value


def _lower_schema(schema):
    schema = _plain(schema or {})
    if isinstance(schema, dict):
        out = {}
        for key, value in schema.items():
            if key == "type" and isinstance(value, str):
                out[key] = value.lower()
            else:
                out[key] = _lower_schema(value) if isinstance(value, (dict, list, tuple)) else value
        return out
    if isinstance(schema, list):
        return [_lower_schema(item) for item in schema]
    return schema


def _ollama_tools(owner) -> list[dict]:
    from main import TOOL_DECLARATIONS

    declarations = (
        list(TOOL_DECLARATIONS)
        + owner._action_registry.get_tool_declarations()
        + owner._plugin_registry.get_tool_declarations()
    )
    tools = []
    # Llama 3.1 8B is text-only. Do not let it claim to see a webcam or screen.
    for raw in declarations:
        decl = _plain(raw)
        if not isinstance(decl, dict):
            continue
        name = str(decl.get("name") or "").strip()
        if not name or name in ("screen_process", "ai_collaboration"):
            continue
        parameters = _lower_schema(decl.get("parameters") or {
            "type": "object", "properties": {},
        })
        if not isinstance(parameters, dict):
            parameters = {"type": "object", "properties": {}}
        parameters.setdefault("type", "object")
        parameters.setdefault("properties", {})
        tools.append({
            "type": "function",
            "function": {
                "name": name,
                "description": str(decl.get("description") or ""),
                "parameters": parameters,
            },
        })
    return tools


class OfflineAssistant:
    """Local audio loop attached to a ``JarvisLive`` instance."""

    def __init__(self, owner):
        self.owner = owner
        self.cfg = _config()
        from core.llm_client import get_offline_ollama_settings
        _, self.model = get_offline_ollama_settings()
        self.stt_model = str(self.cfg.get("offline_stt_model") or "base")
        self.stt_language = str(self.cfg.get("offline_stt_language") or "pt")
        self.voice = str(self.cfg.get("offline_tts_voice") or VOICE_NAME)
        self.tts = None
        self.stt = None
        self._audio = queue.Queue(maxsize=128)
        self._speech_lock = getattr(owner, "_offline_speech_lock", None)
        if self._speech_lock is None:
            import threading
            self._speech_lock = threading.Lock()
            owner._offline_speech_lock = self._speech_lock
        self._speaking = False
        self._history: list[dict] = []
        self._tools = _ollama_tools(owner)
        self._commands: asyncio.Queue = asyncio.Queue()

    async def _prepare(self) -> bool:
        from core.llm_client import ensure_offline_ollama_running, offline_model_available

        self.owner.ui.write_log("SYS: Preparando o modo local…")
        if not await asyncio.to_thread(ensure_offline_ollama_running, 8):
            self.owner.ui.write_log(
                "ERR: Ollama não está disponível. Instale o Ollama e execute "
                f"ollama pull {self.model}."
            )
            return False
        if not await asyncio.to_thread(offline_model_available):
            self.owner.ui.write_log(
                f"ERR: O modelo {self.model} não foi baixado. Execute: ollama pull {self.model}"
            )
            return False

        def load_models():
            from core.stt import WhisperSTT
            from core.tts import KokoroTTSEngine
            stt = WhisperSTT(model_name=self.stt_model, language=self.stt_language)
            tts = KokoroTTSEngine(voice=self.voice)
            return stt, tts

        try:
            self.stt, self.tts = await asyncio.to_thread(load_models)
        except Exception as exc:
            self.owner.ui.write_log(
                "ERR: Voz local não preparada. Rode prepare_offline.py enquanto "
                f"a internet estiver disponível. ({str(exc)[:140]})"
            )
            return False
        return True

    def _callback(self, indata, frames, time_info, status):
        owner = self.owner
        if owner.ui.muted or self._speaking:
            return
        if owner._ptt_enabled and not owner._ptt_held:
            return
        if owner._wake_enabled and not owner._awake:
            detector = getattr(owner, "_wake_detector", None)
            if detector is not None:
                detector.feed(indata)
            return
        try:
            self._audio.put_nowait(indata.copy())
        except queue.Full:
            pass
        try:
            samples = np.asarray(indata, dtype=np.float32)
            rms = float(np.sqrt(np.mean(samples * samples))) if samples.size else 0.0
            owner.ui.set_audio_level(max(0.0, min(1.0, (rms - 60) / (2600 - 60))))
        except Exception:
            pass

    def _open_input(self):
        from memory.config_manager import get_input_device
        from core import audio_devices

        name = get_input_device()
        device = audio_devices.resolve(name, "input") if name else None
        return sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=CHANNELS,
            dtype="int16",
            blocksize=CHUNK_SIZE,
            device=device,
            callback=self._callback,
        )

    async def _system_prompt(self) -> str:
        from main import _load_system_prompt, _render_prompt
        from memory.memory_manager import format_memory_for_prompt, load_memory
        from datetime import datetime

        owner = self.owner
        declarations = (
            list(__import__("main").TOOL_DECLARATIONS)
            + owner._action_registry.get_tool_declarations()
            + owner._plugin_registry.get_tool_declarations()
        )
        prompt = _render_prompt(_load_system_prompt(), {
            "assistant_name": owner._asst_name,
            "platform": f"{__import__('platform').system()} {__import__('platform').release()}".strip(),
            "capabilities": "\n".join(
                f"- {_plain(d).get('name')}: {_plain(d).get('description', '')}"
                for d in declarations if isinstance(_plain(d), dict)
            ),
            "limits": "Este modo local não tem visão de tela/webcam. Tarefas que exigem internet ficam indisponíveis.",
        })
        memory = format_memory_for_prompt(load_memory())
        date_line = datetime.now().strftime("%A, %d de %B de %Y, %H:%M")
        return "\n\n".join(part for part in (
            f"Você é {owner._asst_name}, assistente de voz. Responda em português brasileiro, "
            "exceto se a pessoa pedir ou falar outro idioma. Este é o modo local sem internet. "
            "Use as ferramentas para ações locais. Não invente resultados de busca, clima, "
            "mensagens enviadas ou qualquer dado que dependa da rede. Diga claramente quando "
            "uma tarefa exigir internet. Este modelo não consegue interpretar imagens.",
            f"Data e hora local: {date_line}.",
            memory,
            prompt,
        ) if part)

    async def _speak(self, text: str) -> None:
        if not text or self.owner.ui.muted:
            return
        self._speaking = True
        self.owner.set_speaking(True)
        try:
            await asyncio.to_thread(self._speak_blocking, text)
        finally:
            self._speaking = False
            self.owner.set_speaking(False)

    def _speak_blocking(self, text: str) -> None:
        with self._speech_lock:
            if self.tts:
                self.tts.speak(text)

    async def _turn(self, text: str) -> str:
        from core.llm_client import call_ollama

        self._history.append({"role": "user", "content": text})
        # Keep a bounded conversation; the system prompt and saved memory remain.
        self._history = self._history[-20:]
        messages = [{"role": "system", "content": self._system}]
        messages.extend(self._history)
        answer = ""
        for _ in range(6):
            reply = await asyncio.to_thread(call_ollama, messages, self._tools, 180, self.model)
            content = str(reply.get("content") or "").strip()
            calls = reply.get("tool_calls") or []
            if not calls:
                answer = content or "Não consegui gerar uma resposta agora."
                messages.append({"role": "assistant", "content": answer})
                break
            messages.append({
                "role": "assistant",
                "content": content,
                "tool_calls": calls,
            })
            for call in calls:
                fn = call.get("function") or {}
                name = str(fn.get("name") or "")
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                if not name:
                    continue
                self.owner.ui.set_state("THINKING")
                self.owner.ui.write_log(f"SYS: Executando {name} no modo local…")
                # Screen/camera analysis is intentionally unavailable to Llama 3.1 8B.
                if name == "screen_process":
                    result = "Análise de tela e câmera não está disponível com este modelo local."
                else:
                    fc = SimpleNamespace(
                        id=str(call.get("id") or uuid.uuid4()),
                        name=name,
                        args=args if isinstance(args, dict) else {},
                    )
                    tool_reply = await self.owner._execute_tool(fc)
                    response = getattr(tool_reply, "response", {}) or {}
                    result = response.get("result", response) if isinstance(response, dict) else response
                messages.append({
                    "role": "tool",
                    "name": name,
                    "tool_name": name,
                    "content": str(result),
                })
        self._history = messages[1:][-20:]
        return answer or "Concluí as ações locais solicitadas."

    async def _handle_utterance(self, audio: np.ndarray) -> None:
        if audio.size < int(SAMPLE_RATE * MIN_UTTERANCE_SECONDS):
            return
        try:
            text = await asyncio.to_thread(self.stt.transcribe, audio.astype(np.float32) / 32768.0)
        except Exception as exc:
            self.owner.ui.write_log(f"ERR: Falha ao transcrever áudio local: {str(exc)[:120]}")
            return
        text = " ".join((text or "").split())
        if not text:
            return
        self.owner._last_user_speech = time.monotonic()
        self.owner.ui.write_log(f"Você: {text}")
        self.owner._session_log.append(f"User: {text}")
        self.owner.ui.set_state("THINKING")
        try:
            answer = await self._turn(text)
        except Exception as exc:
            answer = (
                "O modelo local não respondeu. Confira se o Ollama está ativo e se "
                f"{self.model} está instalado."
            )
            self.owner.ui.write_log(f"ERR: Ollama: {str(exc)[:140]}")
        self.owner.ui.write_log(f"{self.owner._asst_name}: {answer}")
        self.owner._session_log.append(f"{self.owner._asst_name}: {answer}")
        if self.owner._dashboard:
            try:
                await self.owner._dashboard.broadcast({
                    "type": "log", "speaker": "jarvis", "text": answer,
                })
            except Exception:
                pass
        await self._speak(answer)
        if not self.owner.ui.muted:
            self.owner.ui.set_state("LISTENING")

    async def run(self) -> bool:
        """Return True when internet returns and Gemini should reconnect."""
        if not await self._prepare():
            return False
        self.owner._offline_mode = True
        self.owner._local_tts = self
        self.owner._offline_commands = self._commands
        try:
            self._system = await self._system_prompt()
            self.owner.ui.write_log(
                f"SYS: Sem internet. Modo local ativo: Ollama {self.model}, "
                f"transcrição Whisper e voz {self.voice}."
            )
            self.owner.ui.set_state("LISTENING")
            try:
                stream = self._open_input()
            except Exception as exc:
                self.owner.ui.write_log(f"ERR: Não foi possível abrir o microfone local: {exc}")
                return False

            pre_roll = deque(maxlen=5)
            utterance: list[np.ndarray] = []
            silence = 0.0
            speaking = False
            last_probe = time.monotonic()
            with stream:
                while True:
                    try:
                        chunk = await asyncio.to_thread(self._audio.get, True, 0.20)
                        pcm = np.asarray(chunk[:, 0] if chunk.ndim > 1 else chunk, dtype=np.int16)
                        level = float(np.sqrt(np.mean(pcm.astype(np.float32) ** 2)) / 32768.0)
                        seconds = len(pcm) / SAMPLE_RATE
                        if level >= SPEECH_RMS:
                            if not speaking:
                                utterance = list(pre_roll)
                                speaking = True
                            utterance.append(pcm)
                            silence = 0.0
                        elif speaking:
                            utterance.append(pcm)
                            silence += seconds
                            if silence >= END_SILENCE_SECONDS:
                                audio = np.concatenate(utterance)
                                utterance, speaking, silence = [], False, 0.0
                                self.owner.ui.set_state("THINKING")
                                await self._handle_utterance(audio)
                        else:
                            pre_roll.append(pcm)
                    except queue.Empty:
                        pass

                    while True:
                        try:
                            command = self._commands.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                        if command:
                            self.owner.ui.write_log(f"Você: {command}")
                            await self._handle_text(str(command))

                    if time.monotonic() - last_probe >= ONLINE_RETRY_SECONDS:
                        last_probe = time.monotonic()
                        if await asyncio.to_thread(internet_available):
                            self.owner.ui.write_log("SYS: Internet restaurada; retomando o Gemini.")
                            return True
        finally:
            self.owner._offline_mode = False
            self.owner._local_tts = None
            self.owner._offline_commands = None

    async def _handle_text(self, text: str) -> None:
        self.owner._last_user_speech = time.monotonic()
        self.owner._session_log.append(f"User: {text}")
        self.owner.ui.set_state("THINKING")
        try:
            answer = await self._turn(text)
        except Exception as exc:
            answer = f"Ollama não respondeu: {str(exc)[:120]}"
        self.owner.ui.write_log(f"{self.owner._asst_name}: {answer}")
        self.owner._session_log.append(f"{self.owner._asst_name}: {answer}")
        await self._speak(answer)
        if not self.owner.ui.muted:
            self.owner.ui.set_state("LISTENING")
