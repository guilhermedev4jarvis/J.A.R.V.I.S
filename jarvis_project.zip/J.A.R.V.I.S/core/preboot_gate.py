"""core/preboot_gate.py — Stage-1 password gate BEFORE heavy imports.

Runs with minimal dependencies (stdlib + optional tkinter). No Gemini, no
camera, no microphone, no dashboard, no action loader.

Password policy
---------------
* Canonical secret: ``123gui834``
* Env override (plain): ``JARVIS_BOOT_PASSWORD``
* Stored comparison uses SHA-256 hex digest (never log the plain password).
* Max 3 attempts → audit + hard exit.
* Skip for automated tests: ``JARVIS_SKIP_PREBOOT=1``.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# ── constants ────────────────────────────────────────────────────────────────

DEFAULT_PLAIN = "123gui834"
# sha256("123gui834")
DEFAULT_HASH = "79d8d70cc2b3d9cf76d36ea9d91557e5c60058e1e9dd9d3a819aa86b15e7930d"
MAX_ATTEMPTS = 3

_BASE = Path(__file__).resolve().parents[1]
_AUDIT_DIR = _BASE / "memory" / "audit"
_SESSION_FLAG = _BASE / "memory" / "biometrics" / ".preboot_ok"

_validated = False
_lock = threading.Lock()


def _sha256(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def expected_hash() -> str:
    """Resolve the hash we compare against.

    Priority:
      1. JARVIS_BOOT_PASSWORD_HASH (explicit hash override)
      2. SHA-256 of JARVIS_BOOT_PASSWORD (plain override)
      3. Built-in DEFAULT_HASH of 123gui834
    """
    env_hash = (os.getenv("JARVIS_BOOT_PASSWORD_HASH") or "").strip().lower()
    if env_hash and len(env_hash) == 64:
        return env_hash
    env_plain = (os.getenv("JARVIS_BOOT_PASSWORD") or "").strip()
    if env_plain:
        return _sha256(env_plain)
    return DEFAULT_HASH


def password_ok(candidate: str | None) -> bool:
    if not candidate:
        return False
    return _sha256(str(candidate).strip()) == expected_hash()


def is_validated() -> bool:
    return _validated


def _audit_failure(attempt: int, reason: str) -> None:
    try:
        _AUDIT_DIR.mkdir(parents=True, exist_ok=True)
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = _AUDIT_DIR / f"audit_{day}.jsonl"
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "kind": "preboot_password_fail",
            "attempt": attempt,
            "max_attempts": MAX_ATTEMPTS,
            "reason": reason,
            "detail": "password hash mismatch (plain redacted)",
        }
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _audit_success() -> None:
    try:
        _AUDIT_DIR.mkdir(parents=True, exist_ok=True)
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = _AUDIT_DIR / f"audit_{day}.jsonl"
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "kind": "preboot_password_ok",
            "detail": "pre-boot gate passed",
        }
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _console_prompt(attempt: int) -> str:
    try:
        return input(
            f"[JARVIS PRE-BOOT] Senha mestra ({attempt}/{MAX_ATTEMPTS}): "
        ).strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def _tk_prompt(attempt: int) -> Optional[str]:
    """Minimal blocking password dialog via tkinter. Returns None on cancel."""
    try:
        import tkinter as tk
        from tkinter import simpledialog, messagebox
    except Exception:
        return None

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        root.update()
    except Exception:
        pass

    result: dict[str, Optional[str]] = {"value": None}

    def _ask() -> None:
        try:
            val = simpledialog.askstring(
                "J.A.R.V.I.S. — Pré-Boot",
                f"Senha mestra ({attempt}/{MAX_ATTEMPTS})\n"
                "Nenhum módulo de IA/câmera/rede será carregado até validar.",
                show="*",
                parent=root,
            )
            result["value"] = val
        except Exception:
            result["value"] = None
        finally:
            try:
                root.destroy()
            except Exception:
                pass

    try:
        root.after(50, _ask)
        root.mainloop()
    except Exception:
        try:
            root.destroy()
        except Exception:
            pass
        return None
    return result["value"]


def run_preboot_gate(*, force: bool = False) -> bool:
    """Block until password is accepted or process exits after 3 failures.

    Returns True only on success. Never returns False — failed attempts call
    ``os._exit(1)``.
    """
    global _validated

    with _lock:
        if _validated and not force:
            return True

        if (os.getenv("JARVIS_SKIP_PREBOOT") or "").strip().lower() in (
            "1", "true", "yes", "on",
        ):
            _validated = True
            print("[PREBOOT] skipped (JARVIS_SKIP_PREBOOT=1)", flush=True)
            return True

        # Already validated in this process
        if _validated:
            return True

        print("[PREBOOT] Gate de senha pré-carregamento — aguardando autenticação…", flush=True)

        for attempt in range(1, MAX_ATTEMPTS + 1):
            candidate: Optional[str] = None

            # Prefer GUI when a display is available
            if sys.platform == "win32" or os.environ.get("DISPLAY") or sys.platform == "darwin":
                candidate = _tk_prompt(attempt)
                if candidate is None:
                    # User cancelled dialog → count as failed attempt
                    candidate = ""

            if candidate is None:
                candidate = _console_prompt(attempt)

            if password_ok(candidate):
                _validated = True
                _audit_success()
                try:
                    _SESSION_FLAG.parent.mkdir(parents=True, exist_ok=True)
                    _SESSION_FLAG.write_text(
                        datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        encoding="utf-8",
                    )
                except Exception:
                    pass
                print("[PREBOOT] Senha aceita. Liberando carregamento do sistema…", flush=True)
                return True

            _audit_failure(attempt, "hash_mismatch")
            remaining = MAX_ATTEMPTS - attempt
            if remaining > 0:
                msg = f"[PREBOOT] Senha inválida. Tentativas restantes: {remaining}"
                print(msg, flush=True)
                try:
                    import tkinter as tk
                    from tkinter import messagebox
                    root = tk.Tk()
                    root.withdraw()
                    messagebox.showerror("J.A.R.V.I.S.", msg)
                    root.destroy()
                except Exception:
                    pass
            else:
                print(
                    "[PREBOOT] 3 tentativas falhas — encerrando processo.",
                    flush=True,
                )
                try:
                    import tkinter as tk
                    from tkinter import messagebox
                    root = tk.Tk()
                    root.withdraw()
                    messagebox.showerror(
                        "J.A.R.V.I.S.",
                        "Acesso negado após 3 tentativas.\nProcesso será encerrado.",
                    )
                    root.destroy()
                except Exception:
                    pass
                os._exit(1)

        os._exit(1)
        return False  # unreachable


__all__ = [
    "DEFAULT_PLAIN",
    "DEFAULT_HASH",
    "MAX_ATTEMPTS",
    "expected_hash",
    "password_ok",
    "is_validated",
    "run_preboot_gate",
]
