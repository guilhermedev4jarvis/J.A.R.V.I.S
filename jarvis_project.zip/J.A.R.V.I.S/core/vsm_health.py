"""core/vsm_health.py — integrity + controlled launch check for VSM/VSM.exe.

Used during boot (Stage-2/3) to surface a clear HUD warning when the house
camera client is missing or broken, without blocking JARVIS startup.
"""
from __future__ import annotations

import os
import platform
import subprocess
import time
from pathlib import Path
from typing import Any, Optional

_BASE = Path(__file__).resolve().parents[1]


def _env(key: str, default: str = "") -> str:
    return (os.environ.get(key) or default).strip().strip('"')


def candidate_paths() -> list[Path]:
    """Ordered candidate locations for VSM/VSM.exe (and VMS aliases)."""
    out: list[Path] = []
    seen: set[str] = set()

    def add(p: Path | str | None) -> None:
        if not p:
            return
        path = Path(p)
        key = str(path).lower()
        if key in seen:
            return
        seen.add(key)
        out.append(path)

    for k in ("VSM_APP_PATH", "VMS_APP_PATH", "ICSEE_APP_PATH", "CAMERA_APP_PATH"):
        add(_env(k))

    for base in (
        _BASE,
        _BASE.parent,
        Path.cwd(),
        Path.home() / "Downloads",
        Path.home() / "Desktop",
    ):
        add(base / "VSM" / "VSM.exe")
        add(base / "VSM" / "VMS.exe")
        add(base / "VMS" / "VMS.exe")
        add(base / "VMS" / "VSM.exe")
        add(base / "VSM.exe")
        add(base / "VMS.exe")

    local = os.environ.get("LOCALAPPDATA") or ""
    pf = os.environ.get("ProgramFiles") or r"C:\Program Files"
    pf86 = os.environ.get("ProgramFiles(x86)") or r"C:\Program Files (x86)"
    for root in filter(None, [local, pf, pf86, r"C:\VSM", r"C:\VMS"]):
        root_p = Path(root)
        add(root_p / "VSM" / "VSM.exe")
        add(root_p / "VMS" / "VMS.exe")
        add(root_p / "VSM.exe")
        add(root_p / "VMS.exe")

    return out


def resolve_vsm() -> Optional[Path]:
    for p in candidate_paths():
        try:
            if p.is_file():
                return p.resolve()
        except Exception:
            continue
    try:
        from shutil import which
        for name in ("VSM.exe", "VMS.exe", "VSM", "VMS"):
            w = which(name)
            if w:
                return Path(w).resolve()
    except Exception:
        pass
    return None


def check_file(path: Path) -> dict[str, Any]:
    """Existence, size > 0, and execute permission (best-effort)."""
    info: dict[str, Any] = {
        "path": str(path),
        "exists": False,
        "size": 0,
        "executable": False,
        "ok": False,
        "error": "",
    }
    try:
        if not path.is_file():
            info["error"] = "not_a_file"
            return info
        info["exists"] = True
        size = path.stat().st_size
        info["size"] = int(size)
        if size <= 0:
            info["error"] = "zero_bytes"
            return info
        # Permission: on Windows is_file is enough; on POSIX check mode
        if platform.system() != "Windows":
            info["executable"] = os.access(path, os.X_OK)
            if not info["executable"]:
                info["error"] = "not_executable"
                return info
        else:
            info["executable"] = True
        info["ok"] = True
        return info
    except Exception as e:
        info["error"] = str(e)
        return info


def controlled_launch_test(
    path: Path,
    *,
    timeout_sec: float = 4.0,
) -> dict[str, Any]:
    """Start the process briefly and terminate it.

    Detects immediate crash / missing DLL without leaving the app running.
    On non-Windows hosts the launch is skipped (VSM is a Windows client).
    """
    result: dict[str, Any] = {
        "launched": False,
        "pid": None,
        "exit_code": None,
        "error": "",
        "ok": False,
    }
    if platform.system() != "Windows":
        result["error"] = "skipped_non_windows"
        result["ok"] = True  # not a failure on Linux CI
        return result

    creationflags = 0
    try:
        creationflags = subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]
    except Exception:
        creationflags = 0

    proc: Optional[subprocess.Popen] = None
    try:
        proc = subprocess.Popen(
            [str(path)],
            cwd=str(path.parent),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
        result["launched"] = True
        result["pid"] = proc.pid
        # Brief wait: if it dies instantly, capture exit code
        deadline = time.time() + min(1.2, timeout_sec)
        while time.time() < deadline:
            rc = proc.poll()
            if rc is not None:
                result["exit_code"] = rc
                # Immediate exit with non-zero → likely missing dependency
                if rc != 0:
                    result["error"] = f"immediate_exit_code_{rc}"
                    result["ok"] = False
                    return result
                # Exit 0 quickly may still be ok (some apps spawn and exit parent)
                result["ok"] = True
                return result
            time.sleep(0.15)

        # Still running after warm-up → healthy enough
        result["ok"] = True
        return result
    except OSError as e:
        result["error"] = f"os_error:{e}"
        result["ok"] = False
        return result
    except Exception as e:
        result["error"] = str(e)
        result["ok"] = False
        return result
    finally:
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
            try:
                proc.wait(timeout=2.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass


def run_health_check(*, try_launch: bool = True) -> dict[str, Any]:
    """Full diagnostic for VSM/VSM.exe.

    Returns a structured report suitable for logs and HUD warnings.
    """
    report: dict[str, Any] = {
        "resolved_path": None,
        "file": None,
        "launch": None,
        "ok": False,
        "message": "",
        "candidates": candidate_paths()[:8],
    }

    path = resolve_vsm()
    if path is None:
        report["message"] = (
            "VSM/VSM.exe não encontrado. Coloque em J.A.R.V.I.S/VSM/VSM.exe "
            "ou defina VSM_APP_PATH no .env"
        )
        report["ok"] = False
        return report

    report["resolved_path"] = str(path)
    file_info = check_file(path)
    report["file"] = file_info
    if not file_info.get("ok"):
        report["message"] = (
            f"VSM encontrado em {path} mas inválido: {file_info.get('error')}"
        )
        report["ok"] = False
        return report

    if try_launch and (os.getenv("JARVIS_SKIP_VSM_LAUNCH") or "").strip().lower() not in (
        "1", "true", "yes",
    ):
        launch = controlled_launch_test(path)
        report["launch"] = launch
        if not launch.get("ok"):
            report["message"] = (
                f"VSM em {path} falhou no teste de invocação: {launch.get('error')}"
            )
            report["ok"] = False
            return report
        report["message"] = f"VSM OK — {path} (pid teste={launch.get('pid')})"
        report["ok"] = True
        return report

    report["message"] = f"VSM arquivo OK — {path} (launch skip)"
    report["ok"] = True
    return report


def log_and_notify(ui: Any = None) -> dict[str, Any]:
    """Run health check, print to console, optionally surface on HUD."""
    report = run_health_check(try_launch=True)
    msg = report.get("message") or ("VSM OK" if report.get("ok") else "VSM FAIL")
    tag = "OK" if report.get("ok") else "WARN"
    print(f"[VSM_HEALTH] [{tag}] {msg}", flush=True)
    if ui is not None:
        try:
            ui.write_log(f"VSM: {msg}")
        except Exception:
            pass
        if not report.get("ok"):
            # Best-effort status line if the UI exposes one
            for name in ("show_status", "set_status", "notify"):
                fn = getattr(ui, name, None)
                if callable(fn):
                    try:
                        fn(f"⚠ {msg}")
                    except Exception:
                        pass
                    break
    try:
        from core import audit
        audit.log_event(
            "vsm_health",
            tool="vsm_health",
            extra={
                "ok": report.get("ok"),
                "path": report.get("resolved_path"),
                "detail": report.get("message"),
            },
        )
    except Exception:
        pass
    return report


__all__ = [
    "candidate_paths",
    "resolve_vsm",
    "check_file",
    "controlled_launch_test",
    "run_health_check",
    "log_and_notify",
]
