Biometrics dir for vozdono.mp3 + fotobase1/2/3.jpg
