# Upgrade: MCP · Realtime · Episodic/Graph memory · GUI validate loop

Implemented as optional, non-breaking layers on top of the existing architecture.

## 1. MCP (Model Context Protocol)

| File | Change |
|------|--------|
| `core/mcp_client.py` | **NEW** — stdio MCP client, tool schema adapter, `call_tool` |
| `core/plugin_loader.py` | After local plugins, merges MCP tools as `PluginRecord`s |
| `config/mcp_servers.json.example` | **NEW** — example server list |

**Setup**
```bash
pip install mcp
cp config/mcp_servers.json.example config/mcp_servers.json
# edit servers (npx + official MCP packages, tokens in env)
```
Tools appear as `mcp_<server>__<tool_name>` and go through the normal plugin path.

## 2. OpenAI Realtime (native audio WebSocket)

| File | Change |
|------|--------|
| `providers/engine_openai_realtime.py` | **NEW** — Live-shaped engine over OpenAI Realtime API |
| `providers/registry.py` | Registers `engine_openai_realtime` under `engine` |

**Setup**
```bash
pip install websockets
```
Select **OpenAI Realtime** in the providers panel; set API key + model.
Gemini Live remains the default path. Viseme / barge-in / tools reuse the same `Msg` contract.

## 3. Episodic memory + knowledge graph

| File | Change |
|------|--------|
| `memory/memory_manager.py` | Episodes (`episodes.jsonl`), graph (`graph.json`), optional Chroma, `search_memory_rich` |
| `actions/memory_compactor.py` | Status shows episode/graph stats; `action=compact_episodes` |
| `main.py` | `recall_memory` uses `search_memory_rich` |

**API (Python)**
- `add_episode(text, role=..., entities=[...], summary=...)`
- `search_episodes(query)`
- `upsert_node` / `link` / `related`
- `search_memory_rich(query)` — facts + episodes + graph

**Optional**
```bash
pip install chromadb   # semantic episode search
```

Prompt budget is unchanged: only the core block is injected; episodes/graph are tool-on-demand.

## 4. GUI grounding — Observar → Agir → Validar

| File | Change |
|------|--------|
| `plugins/desktop_agent.py` | `_screen_fingerprint`, `_validate_action`, loop wires validate after every act |

After each action the agent:
1. Snapshots a cheap `phash` before the act
2. Executes
3. Validates pixel change + optional fast Gemini check
4. On `validate_fail` → treated as failure → existing `_replan` path

Works with the existing UIA / vision / Playwright stack; no new required deps.

## Optional packages (summary)

```bash
pip install mcp websockets chromadb
```

None of these are required for boot. Missing packages are logged and skipped.
