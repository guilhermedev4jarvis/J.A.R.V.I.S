"""Prepare the local models while the computer is online.

Run after installing requirements-local.txt and pulling the configured Ollama
model. The first run downloads/caches Whisper, Kokoro, and the selected voice.
"""
from __future__ import annotations

import sys

from core.llm_client import (
    ensure_offline_ollama_running,
    get_offline_ollama_settings,
    offline_model_available,
)


def main() -> int:
    url, model = get_offline_ollama_settings()
    if not ensure_offline_ollama_running(timeout=8):
        print("Ollama não está disponível. Instale-o e tente novamente.")
        return 1
    if not offline_model_available():
        print(f"Baixe o modelo antes: ollama pull {model}")
        return 1

    from core.stt import WhisperSTT
    from core.tts import KokoroTTSEngine

    print("Preparando transcrição local em português (Whisper base)…")
    WhisperSTT(model_name="base", language="pt")
    print("Preparando voz Kokoro pf_dora em português brasileiro…")
    KokoroTTSEngine(voice="pf_dora")
    print("Pronto. Ollama, Whisper e Kokoro foram preparados para uso sem internet.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
