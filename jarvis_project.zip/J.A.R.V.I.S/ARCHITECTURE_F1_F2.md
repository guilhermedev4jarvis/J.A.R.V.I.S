# MARK LVI — Mapa de Arquitetura (Frentes 1 e 2)

```
                    ┌─────────────────────────────┐
                    │  main.py / action_loader    │
                    │  plugin_loader / hot_reload │
                    └─────────────┬───────────────┘
                                  │
          ┌───────────────────────┼───────────────────────┐
          ▼                       ▼                       ▼
┌──────────────────┐   ┌──────────────────┐   ┌──────────────────┐
│ actions/code_*   │   │ plugins/*_assist │   │ core/outcome     │
│ (wrappers)       │   │ roblox/blender/  │   │ contracts/retry  │
└────────┬─────────┘   │ godot            │   └──────────────────┘
         │             └────────┬─────────┘
         ▼                      ▼
┌──────────────────┐   ┌──────────────────┐
│ core/code_engine │   │ core/engine_     │
│ Architect        │   │ bridge           │
│ Builder          │   │  ├─ roblox_bridge│
│ SandboxVerifier  │   │  ├─ blender CLI  │
│ AutoHealer       │   │  └─ godot files  │
└────────┬─────────┘   └────────┬─────────┘
         │                      │
         ▼                      ▼
┌──────────────────┐   ┌──────────────────┐
│ core/sandbox     │   │ Studio plugin    │
│ core/retry       │   │ .rbxmx / FBX     │
│ LLM (gemini/     │   │ project.godot    │
│  llm_client)     │   │                  │
└──────────────────┘   └──────────────────┘
```

## Frente 1 — Programação unificada

| Legado | Destino |
|--------|---------|
| `code_forge` | `CodeEngine.forge / generate / analyze / fix` |
| `code_helper` | `generate_python / builder / run_module` |
| `code_assist` | `pipeline()` |
| `code_review_local` | `analyze` + git facts |
| `dev_agent` | `pipeline()` multi-file |
| `self_program` | `analyze` + `builder` (write gated) |

## Frente 2 — Bridge 3D

| Target | Transporte |
|--------|------------|
| Roblox | `roblox_bridge` HTTP `:28859` + Luau plugin + `.rbxmx` |
| Blender | `blender --background --python` via `engine_bridge` |
| Godot | escrita de `project.godot` / `.gd` / `.tscn` |

`dispatch({"target":"roblox|blender|godot", "type":"..."})` é a API única.
