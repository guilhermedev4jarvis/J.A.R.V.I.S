# J.A.R.V.I.S. — MARK LXI (61)

### Assistente virtual e agente autônomo de desktop

**J.A.R.V.I.S. — MARK LXI (61)** ouve, vê, fala e controla o PC em **Windows, macOS e Linux**.

- **Nuvem:** Gemini Live (voz em tempo real), com fallback **100% local** (Ollama + Whisper + Piper).
- **Local:** `python mainlocal.py` (air-gapped) ou pipeline offline.
- **Sem wake word:** escuta **contínua** (VAD / mic sempre ativo) — fale direto, ex.: *“ativar protocolo 190”*.
- **Autoria:** Guilherme · **Licença:** [CC BY-NC 4.0](LICENSE)

---

## Índice

1. [Visão geral](#visão-geral)
2. [Novidades desta build](#novidades-desta-build)
3. [Biometria do dono](#biometria-do-dono)
4. [Protocolo 190 e demo](#protocolo-190-e-demo)
5. [Tools unificadas](#tools-unificadas)
6. [Instalação](#instalação)
7. [Modo 24/7 no Windows](#modo-247-no-windows)
8. [AudioRelay](#audiorelay)
9. [Dashboard e autonomia](#dashboard-e-autonomia)
10. [Dados e privacidade](#dados-e-privacidade)
11. [Licença](#licença)

---

## Visão geral

| Capacidade | Descrição |
|------------|-----------|
| Voz contínua | Sem palavra de ativação — processa a frase assim que detecta fala |
| Biometria | Face → voz no boot (threshold voz **0.75**) |
| Protocolo 190 | iCSee + print + visão IA + WhatsApp/Telegram/Webhook (silencioso) |
| Protocolo demo | Demonstração falada sem alerta de emergência |
| Missões / gatilhos | `mission_planner`, `context_triggers`, loop proativo |
| Desktop | Janelas, apps, PowerShell com safety |
| Offline | `mainlocal.py` + Ollama `qwen2.5-coder:7b` |

---

## Novidades desta build

- **Wake word removida** (`core/wake_word.py` stub) — mic sempre ativo.
- **`protocolo` 190 / demo** com **iCSee** (app ou https://xmeye.net), RTSP opcional.
- **190 multi-canal:** WhatsApp + Telegram Bot + `webhook_bridge` (sem ligação telefônica, sem PIN).
- **AudioRelay** sobe automaticamente no boot Windows (`main.py` / `mainlocal.py`) se instalado.
- **Isolamento 24/7** nas etapas do protocolo (timeouts ~5s, try/except por passo).
- **Redação** de RTSP/tokens/telefones nos logs de auditoria.
- Scripts **`install_24h.ps1`** e **`rodar_jarvis_24h.bat.example`**.

---

## Biometria do dono

1. Face (`core/face_auth.py`) → TTS de etapa.  
2. Voz (`core/voice_auth.py`, threshold **0.75**).  
3. Falha → tentar de novo; sucesso → HUD principal.

---

## Protocolo 190 e demo

Comandos de voz/texto:

```text
ativar protocolo 190
ativar protocolo demo
```

### 190 (imediato, silencioso)
1. Abre/foca **iCSee** (ou portal web).  
2. Aguarda carga da UI / opcional RTSP.  
3. Print → pasta `memory/audit/evidencias/`.  
4. Análise visual (Gemini/LLM).  
5. Envia **em paralelo** (canais configurados):
   - WhatsApp (`whatsapp_web` / `send_message`)
   - Telegram (`TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID`)
   - Webhook (`webhook_bridge`)

Mensagem padrão pede ao contato que **ligue o 190** e cita o endereço + resumo das câmeras.

### demo
Anuncia por TTS, diagnóstico de sistema/rede, iCSee + narração — **não** envia emergência.

### Variáveis úteis (`.env`)

```bash
EMERGENCY_CONTACT_PHONE=5517999999999
EMERGENCY_CONTACT_NAME=Maria
HOME_ADDRESS=Rua São Luiz, nº 244, Jardim Europa, São José do Rio Preto - SP
ICSEE_APP_PATH=C:\Path\iCSee.exe
# ICSEE_WEB_URL=https://xmeye.net
# ICSEE_RTSP_URL=rtsp://admin:senha@IP:554/...
TELEGRAM_BOT_TOKEN=123456:ABC...
TELEGRAM_CHAT_ID=999999999
CAMERA_LOAD_DELAY_SEC=4
AUDIORELAY_PATH=C:\Path\AudioRelay.exe
```

---

## Tools unificadas

Principais: `protocolo`, `mission_planner`, `context_triggers`, `whatsapp_web`, `screen_context_advisor`, `git_voice_copilot`, `routine_orchestrator`, `local_doc_rag`, `intruder_alert`, `desktop_control`, `system_health`, …

Contrato: `TOOL` + `core.outcome` em `actions/`.

---

## Instalação

```bash
python -m venv .venv
# Windows:
.\.venv\Scripts\activate
pip install -r requirements.txt
# opcional offline:
pip install -r requirements-local.txt

python main.py
# ou 100% local:
python mainlocal.py
```

`python setup.py` / `python setup.py --local` / `--heavy` / `--all` conforme o instalador do repositório.

---

## Modo 24/7 no Windows

> **Onde rodar:** PowerShell **no Windows**, na pasta do projeto (junto de `main.py`).  
> Neste ambiente de build (Linux) o script **não** é executado de ponta a ponta; a estrutura do `.bat` e do fluxo foi validada e o arquivo oficial é `install_24h.ps1`.

### Opção rápida (recomendado)

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\install_24h.ps1
```

### O que o script faz

1. **Energia (tomada):** não suspender, não desligar monitor, não hibernar  
   ```powershell
   powercfg /change standby-timeout-ac 0
   powercfg /change monitor-timeout-ac 0
   powercfg /change hibernate-timeout-ac 0
   ```
2. Cria **`.venv`**, atualiza pip e instala `requirements.txt`
3. Gera **`rodar_jarvis_24h.bat`** (loop: `python main.py` → espera 3s → reinicia)
4. Atalho em **Inicialização do Windows** (`shell:startup` → `JARVIS_24h.lnk`)
5. Tarefa **`JARVIS_Manutencao_Diaria`** às **04:00** (`taskkill /f /im python.exe`)
6. Inicia o watchdog imediatamente

### Equivalente manual (mesmo fluxo)

```powershell
# 1. Energia
powercfg /change standby-timeout-ac 0
powercfg /change monitor-timeout-ac 0
powercfg /change hibernate-timeout-ac 0

# 2. venv + deps
if (-Not (Test-Path ".venv")) { python -m venv .venv }
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\pip.exe install -r requirements.txt

# 3–6. Prefira .\install_24h.ps1 (cria bat, startup, schtasks e Start-Process)
```

**Avisos:**

- `schtasks` e às vezes `powercfg` pedem **Administrador**.
- A tarefa das 04:00 mata **todo** `python.exe` — ajuste se outros scripts Python rodarem na mesma máquina.
- WhatsApp Web precisa da sessão QR ativa para o canal 190; configure **Telegram** como fallback 24/7.

---

## AudioRelay

No boot (`main.py` / `mainlocal.py`), se estiver no Windows:

1. Verifica se `AudioRelay.exe` já está rodando  
2. Senão, procura em `AUDIORELAY_PATH` e pastas padrão  
3. Inicia em processo destacado + ~2s de espera pelo Virtual Mic  
4. Se não instalado → log discreto e microfone padrão  

---

## Dashboard e autonomia

- `dashboard/server.py` + UI estática  
- APIs de missões, gatilhos, timeline, áudio, segurança  
- Loop proativo: triggers + timeline opcional  

---

## Dados e privacidade

- Memória e biometria locais (`memory/`)  
- Redaction de segredos em logs (`core/redaction.py`)  
- Sem telemetria obrigatória  

---

## Licença

**J.A.R.V.I.S. — MARK LXI (61)** · © 2026 Guilherme · **CC BY-NC 4.0** — ver [LICENSE](LICENSE) e [AUTORIA.md](AUTORIA.md).
