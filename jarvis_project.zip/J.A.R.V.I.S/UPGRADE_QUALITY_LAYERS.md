# Upgrade: Quality layers (reliability · memory · voice · security · extensibility · UX)

Non-breaking modules layered on the existing architecture. Missing optional
pieces are skipped; core boot does not require them.

## 1. Reliability

| File | Role |
|------|------|
| `core/contracts.py` | Risk tiers (`safe` / `review` / `destructive` / `autonomous`), TOOL schema helpers, outcome assertion helpers for tests |
| `core/retry.py` | Exponential backoff + per-tool circuit breaker |
| `core/sandbox.py` | Thread-local dry-run, allow-listed path policy |
| `tests/test_action_contracts.py` | Existing golden shape tests (unchanged) |
| `tests/test_quality_layers.py` | **NEW** — contracts, retry, sandbox, redaction, agent mode, memory hygiene |

Tools may declare `"risk": "destructive"` in their `TOOL` / `PLUGIN` dict.
Destructive heuristics also look at `action=delete|shutdown|…`.

## 2. Memory quality

| API | Purpose |
|-----|---------|
| `consolidate_episodes()` | Promote frequent episode topics → graph + long-term facts; TTL prune |
| `forget_old_episodes(ttl_days=30)` | Drop stale episode lines |
| `detect_contradictions()` | Same key, conflicting values |
| `memory_hygiene_report()` | Human-readable summary |

Exposed via `memory_compactor` actions: `consolidate`, `hygiene`, `forget_old`.

## 3. Voice & latency

| Change | Detail |
|--------|--------|
| `actions/audio_latency_tuner.py` | New `action=auto` — A/B probe of buffer sizes, applies best to `config/audio_latency.json` |
| `core/network_fallback.py` | `should_use_local()` / `internet_reachable()` for cloud → offline hand-off |

## 4. Security & privacy

| File | Role |
|------|------|
| `core/redaction.py` | Mask API keys, tokens, passwords (optional soft PII) before logs |
| `core/audit.py` | Append-only JSONL under `memory/audit/audit_YYYY-MM-DD.jsonl` |
| `core/agent_mode.py` | `air_gapped` flag blocks known cloud tools |

`main.py` redacts tool args in console output and audits high-stakes tools.

## 5. Extensibility

| Change | Detail |
|--------|--------|
| `core/contracts.py` | Shared formal TOOL validation (risk, requires_confirm) |
| `actions/hot_reload.py` | Failed reload restores last-good module; one broken file does not abort the batch |
| `config/mcp_servers.json.example` | Expanded examples: filesystem, github, memory, git, brave_search, sqlite |

## 6. UX — mode + validate feedback

| Piece | Detail |
|-------|--------|
| `core/agent_mode.py` | Modes: `listen` (no actuation), `assist` (default), `autonomous` |
| `actions/agent_mode_control.py` | Tool to set mode / air_gap / strict_paths / validate_feedback |
| `config/agent_mode.json` | Persistence (created on first change) |
| `core/action_feedback.py` | Toasts for `validate_fail` / `validate_ok` from desktop_agent |
| `main.py` | Gate: listen-only blocks actuation; sandbox dry-run short-circuits |

### Mode labels (PT)

- **somente escuta** — ouve e responde; não move mouse/arquivos
- **assistente** — padrão, com confirms
- **autônomo** — agentes multi-step mais livres (destrutivo ainda pede confirm)

## Quick start

```bash
# optional deps already listed in requirements where needed
python tests/test_quality_layers.py
python tests/test_action_contracts.py

# switch mode by voice/tool
# agent_mode_control action=set mode=listen
# memory_compactor action=consolidate
# audio_latency_tuner action=auto
```

## Integration notes

- Quality imports in `main.py` are wrapped in `try/except` so an older tree
  without these files still boots.
- Circuit breaker state is process-local (clears on restart).
- Audit log is best-effort and never raises into the tool path.

## 8. Default local model

Default Ollama model is now **`qwen2.5-coder:7b`** in:

- `core/llm_client.py` (`_DEFAULTS`)
- `core/offline_assistant.py` (`MODEL_NAME`)
- `config/api_keys.json` / `api_keys.json.example`

Pull once:

```bash
ollama pull qwen2.5-coder:7b
```

## 9. Biometrics (voice + face)

| Module | Role |
|--------|------|
| `core/voice_auth.py` | Enroll/verify WAV → spectral fingerprint, cosine score |
| `core/face_auth.py` | Enroll/verify image/camera → OpenCV hist (or face_recognition if installed) |
| `actions/biometrics.py` | Tool: `status / enroll / verify / clear` with `kind=voice\|face` |

Profiles: `memory/biometrics/voice_profile.json`, `face_profile.json` (fingerprints only).

```text
biometrics action=enroll kind=voice wav_path=/path/to/me.wav
biometrics action=verify kind=voice wav_path=/path/to/probe.wav
biometrics action=enroll kind=face camera=true
biometrics action=verify kind=face camera=true
```

Voice works with **stdlib + numpy** only. Face needs **opencv-python** (already in requirements; use 4.x — OpenCV 5 may drop Haar helpers).

## Dependency check

```bash
python scripts/check_deps.py
```
