"""Boot flow: pre-boot password gate + face biometrics stage."""
from __future__ import annotations

import hashlib

from core import boot_biometrics as bb
from core import owner_gate as og
from core import preboot_gate as pg
from core import vsm_health


def test_preboot_default_hash():
    assert pg.DEFAULT_PLAIN == "123gui834"
    assert pg.DEFAULT_HASH == hashlib.sha256(b"123gui834").hexdigest()
    assert pg.expected_hash() == pg.DEFAULT_HASH


def test_preboot_password_ok(monkeypatch):
    monkeypatch.delenv("JARVIS_BOOT_PASSWORD", raising=False)
    monkeypatch.delenv("JARVIS_BOOT_PASSWORD_HASH", raising=False)
    assert pg.password_ok("123gui834")
    assert not pg.password_ok("wrong")
    assert not pg.password_ok("")
    assert not pg.password_ok(None)


def test_preboot_env_override(monkeypatch):
    monkeypatch.setenv("JARVIS_BOOT_PASSWORD", "custom-secret-99")
    assert pg.password_ok("custom-secret-99")
    assert not pg.password_ok("123gui834")
    monkeypatch.delenv("JARVIS_BOOT_PASSWORD", raising=False)


def test_boot_biometrics_password_helpers(monkeypatch):
    monkeypatch.delenv("JARVIS_BOOT_PASSWORD", raising=False)
    assert bb.master_password() == "123gui834"
    assert bb.password_ok("123gui834")
    assert not bb.password_ok("wrong")


def test_enforce_startup_with_face_skip(monkeypatch):
    monkeypatch.setenv("JARVIS_SKIP_FACE_BOOT", "1")
    assert bb.enforce_startup_biometrics() is True
    monkeypatch.delenv("JARVIS_SKIP_FACE_BOOT", raising=False)


def test_owner_gate_password(monkeypatch):
    monkeypatch.delenv("JARVIS_BOOT_PASSWORD", raising=False)
    monkeypatch.delenv("JARVIS_MASTER_PASSWORD", raising=False)
    r = og.require_owner(tool_name="test", action="cmd", password="123gui834")
    assert r.get("ok") is True
    r2 = og.require_owner(tool_name="test", action="cmd", password="nope")
    assert r2.get("ok") is False


def test_extract_password():
    assert og.extract_password_from_text("senha 123gui834") == "123gui834"
    assert og.extract_password_from_text("/senha 123gui834") == "123gui834"


def test_vsm_health_report_shape():
    report = vsm_health.run_health_check(try_launch=False)
    assert "ok" in report
    assert "message" in report
    assert "candidates" in report
    assert isinstance(report["ok"], bool)


def test_vsm_candidate_paths_include_project_vsm():
    paths = vsm_health.candidate_paths()
    assert any(str(p).replace("\\", "/").endswith("VSM/VSM.exe") for p in paths)


def test_redaction_masks_boot_password():
    from core.redaction import redact_text
    assert "123gui834" not in redact_text("password=123gui834 used at boot")
    assert "***" in redact_text("password=123gui834 used at boot")
