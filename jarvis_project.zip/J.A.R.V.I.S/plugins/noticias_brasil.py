"""Deprecated shim — implementation lives in actions/noticias_brasil.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.noticias_brasil is deprecated; import from actions.noticias_brasil",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.noticias_brasil import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.noticias_brasil moved to actions/noticias_brasil.py (unified TOOL contract)"
    ) from e
