"""Deprecated shim — implementation lives in actions/baixar_arquivo.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.baixar_arquivo is deprecated; import from actions.baixar_arquivo",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.baixar_arquivo import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.baixar_arquivo moved to actions/baixar_arquivo.py (unified TOOL contract)"
    ) from e
