"""Deprecated shim — implementation lives in actions/blender_assist.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.blender_assist is deprecated; import from actions.blender_assist",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.blender_assist import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.blender_assist moved to actions/blender_assist.py (unified TOOL contract)"
    ) from e
