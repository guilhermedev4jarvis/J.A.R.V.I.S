"""Deprecated shim — implementation lives in actions/desktop_agent.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.desktop_agent is deprecated; import from actions.desktop_agent",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.desktop_agent import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.desktop_agent moved to actions/desktop_agent.py (unified TOOL contract)"
    ) from e
