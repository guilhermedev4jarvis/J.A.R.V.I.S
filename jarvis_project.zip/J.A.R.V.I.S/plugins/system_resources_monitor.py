"""Deprecated shim — implementation lives in actions/system_resources_monitor.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.system_resources_monitor is deprecated; import from actions.system_resources_monitor",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.system_resources_monitor import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.system_resources_monitor moved to actions/system_resources_monitor.py (unified TOOL contract)"
    ) from e
