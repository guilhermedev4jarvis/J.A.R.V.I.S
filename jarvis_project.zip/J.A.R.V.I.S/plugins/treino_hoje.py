"""Deprecated shim — implementation lives in actions/treino_hoje.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.treino_hoje is deprecated; import from actions.treino_hoje",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.treino_hoje import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.treino_hoje moved to actions/treino_hoje.py (unified TOOL contract)"
    ) from e
