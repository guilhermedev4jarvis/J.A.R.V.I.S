"""Deprecated shim — implementation lives in actions/resumo_link.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.resumo_link is deprecated; import from actions.resumo_link",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.resumo_link import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.resumo_link moved to actions/resumo_link.py (unified TOOL contract)"
    ) from e
