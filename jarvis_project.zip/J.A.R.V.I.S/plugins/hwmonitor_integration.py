"""Deprecated shim — implementation lives in actions/hwmonitor_integration.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.hwmonitor_integration is deprecated; import from actions.hwmonitor_integration",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.hwmonitor_integration import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.hwmonitor_integration moved to actions/hwmonitor_integration.py (unified TOOL contract)"
    ) from e
