"""Deprecated shim — implementation lives in actions/cotacao_dolar.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.cotacao_dolar is deprecated; import from actions.cotacao_dolar",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.cotacao_dolar import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.cotacao_dolar moved to actions/cotacao_dolar.py (unified TOOL contract)"
    ) from e
