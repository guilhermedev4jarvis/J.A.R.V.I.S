"""Deprecated shim — implementation lives in actions/roblox_assist.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.roblox_assist is deprecated; import from actions.roblox_assist",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.roblox_assist import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.roblox_assist moved to actions/roblox_assist.py (unified TOOL contract)"
    ) from e
