"""Deprecated shim — implementation lives in actions/monitor_tool.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.monitor_tool is deprecated; import from actions.monitor_tool",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.monitor_tool import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.monitor_tool moved to actions/monitor_tool.py (unified TOOL contract)"
    ) from e
