"""Deprecated shim — implementation lives in actions/clima.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.clima is deprecated; import from actions.clima",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.clima import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.clima moved to actions/clima.py (unified TOOL contract)"
    ) from e
