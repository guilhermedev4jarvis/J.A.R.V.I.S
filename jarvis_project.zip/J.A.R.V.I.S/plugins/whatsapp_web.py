"""Deprecated shim — implementation lives in actions/whatsapp_web.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.whatsapp_web is deprecated; import from actions.whatsapp_web",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.whatsapp_web import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.whatsapp_web moved to actions/whatsapp_web.py (unified TOOL contract)"
    ) from e
