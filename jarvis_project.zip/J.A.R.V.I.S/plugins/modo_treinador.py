"""Deprecated shim — implementation lives in actions/modo_treinador.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.modo_treinador is deprecated; import from actions.modo_treinador",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.modo_treinador import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.modo_treinador moved to actions/modo_treinador.py (unified TOOL contract)"
    ) from e
