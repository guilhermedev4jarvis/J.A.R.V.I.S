"""Deprecated shim — implementation lives in actions/programador.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.programador is deprecated; import from actions.programador",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.programador import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.programador moved to actions/programador.py (unified TOOL contract)"
    ) from e
