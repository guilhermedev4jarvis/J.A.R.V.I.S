"""Deprecated shim — implementation lives in actions/godot_assist.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.godot_assist is deprecated; import from actions.godot_assist",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.godot_assist import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.godot_assist moved to actions/godot_assist.py (unified TOOL contract)"
    ) from e
