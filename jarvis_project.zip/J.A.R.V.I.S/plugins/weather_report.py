"""Deprecated shim — implementation lives in actions/weather_report.py."""
from __future__ import annotations
import warnings
warnings.warn(
    "plugins.weather_report is deprecated; import from actions.weather_report",
    DeprecationWarning,
    stacklevel=2,
)
try:
    from actions.weather_report import *  # noqa: F401,F403
except Exception as e:
    raise ImportError(
        f"plugins.weather_report moved to actions/weather_report.py (unified TOOL contract)"
    ) from e
