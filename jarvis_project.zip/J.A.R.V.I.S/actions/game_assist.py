"""Alias legacy tool `game_assist` → `game_assistant` (mode=assist)."""
from __future__ import annotations

from actions.game_assistant import game_assistant as _impl


def game_assist(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "assist")
    params.setdefault("action", params.get("action") or "assist")
    return _impl(params, **ctx)


TOOL = {
    "name": "game_assist",
    "description": 'Alias → game_assistant mode=assist',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": game_assist,
    "tier": "core",
    "risk": "review",
}
