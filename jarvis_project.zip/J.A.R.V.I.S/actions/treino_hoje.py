"""Alias legacy tool `treino_hoje` → `treinador` (mode=hoje)."""
from __future__ import annotations

from actions.treinador import treinador as _impl


def treino_hoje(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "hoje")
    params.setdefault("action", params.get("action") or "hoje")
    return _impl(params, **ctx)


TOOL = {
    "name": "treino_hoje",
    "description": 'Alias → treinador mode=hoje',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": treino_hoje,
    "tier": "core",
    "risk": "safe",
}
