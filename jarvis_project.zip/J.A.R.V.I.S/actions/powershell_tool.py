"""Unified PowerShell/shell tool: generate | explain | execute (static_safety)."""
from __future__ import annotations

from core.outcome import done, failed, ask


def _dispatch(impl: str, names: list[str], params: dict, **ctx) -> str:
    import importlib
    mod = importlib.import_module(f"actions.{impl}")
    for fn in names:
        h = getattr(mod, fn, None)
        if callable(h):
            try:
                return h(params, **ctx)
            except TypeError:
                try:
                    return h(parameters=params)
                except TypeError:
                    return h(params)
    return failed("powershell_tool", f"missing {impl}")


def powershell_tool(parameters=None, **ctx) -> str:
    params = dict(parameters or {})
    mode = str(params.get("mode") or params.get("action") or "execute").strip().lower()
    if mode in ("execute", "run", "cmd", "powershell_cmd"):
        return _dispatch("_powershell_cmd_impl", ["powershell_cmd"], params, **ctx)
    if mode in ("assist", "powershell_assist", "explain"):
        return _dispatch("_powershell_assist_impl", ["powershell_assist"], params, **ctx)
    if mode in ("generate", "generator", "powershell_generator"):
        return _dispatch("_powershell_generator_impl", ["powershell_generator"], params, **ctx)
    if mode == "help":
        return done("powershell_tool", modes=["execute", "explain", "generate"])
    return ask("powershell_tool", "mode?", hint="execute|explain|generate")


TOOL = {
    "name": "powershell_tool",
    "description": "PowerShell/shell unificado: mode=execute|explain|generate (com static_safety no execute).",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "command": {"type": "STRING"},
            "cmd": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": powershell_tool,
    "tier": "core",
    "risk": "destructive",
}
