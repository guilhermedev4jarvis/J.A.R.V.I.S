"""
Plugin: resumo_link — recebe uma URL e resume o conteúdo da página.
"""

from __future__ import annotations

import re
import urllib.request
from html.parser import HTMLParser
from urllib.parse import urlparse

from core import gemini

class _TextExtractor(HTMLParser):
    """Extrai texto visível, ignorando script/style/noscript."""

    _SKIP = {"script", "style", "noscript", "svg", "iframe"}

    def __init__(self) -> None:
        super().__init__()
        self._skip_depth = 0
        self._chunks: list[str] = []
        self.title = ""
        self._in_title = False

    def handle_starttag(self, tag: str, attrs) -> None:
        t = tag.lower()
        if t in self._SKIP:
            self._skip_depth += 1
        if t == "title":
            self._in_title = True

    def handle_endtag(self, tag: str) -> None:
        t = tag.lower()
        if t in self._SKIP and self._skip_depth > 0:
            self._skip_depth -= 1
        if t == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._skip_depth:
            return
        text = data.strip()
        if not text:
            return
        if self._in_title and not self.title:
            self.title = text
        else:
            self._chunks.append(text)

    def text(self, limit: int = 12000) -> str:
        raw = " ".join(self._chunks)
        raw = re.sub(r"\s+", " ", raw).strip()
        return raw[:limit]


def _fetch(url: str) -> tuple[str, str]:
    """Retorna (title, text)."""
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
        },
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        ctype = (resp.headers.get("Content-Type") or "").lower()
        raw = resp.read()

    # encoding
    enc = "utf-8"
    m = re.search(r"charset=([\w-]+)", ctype)
    if m:
        enc = m.group(1)
    try:
        html = raw.decode(enc, errors="replace")
    except Exception:
        html = raw.decode("utf-8", errors="replace")

    parser = _TextExtractor()
    try:
        parser.feed(html)
    except Exception:
        pass
    return parser.title, parser.text()


def run(parameters: dict, player=None, session_memory=None) -> str:
    url = (parameters.get("url") or "").strip()
    foco = (parameters.get("foco") or "").strip()

    if not url:
        return "Me manda o link, senhor."
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urlparse(url)
    if not parsed.netloc:
        return "URL inválida."

    if player:
        try:
            player.write_log(f"JARVIS: Resumindo {parsed.netloc}…")
        except Exception:
            pass

    try:
        title, text = _fetch(url)
    except Exception as e:
        return f"Não consegui abrir o link: {e}"

    if len(text) < 80:
        return (
            f"A página abriu, mas quase não tinha texto legível "
            f"({parsed.netloc}). Pode ser um app pesado em JavaScript."
        )

    prompt = f"""
Resuma a página abaixo em português do Brasil.
Seja direto, estilo assistente (curto e útil).

Título: {title or "(sem título)"}
URL: {url}
{"Foco pedido pelo usuário: " + foco if foco else ""}

Formato:
- 1 linha: do que se trata
- 3 a 6 bullets com o essencial
- Se for artigo longo, no máximo ~120 palavras no total

Conteúdo extraído:
{text[:11000]}
"""

    try:
        resumo = gemini.text(prompt, tier=gemini.FAST, timeout_ms=45_000)
    except Exception as e:
        return f"Baixei a página, mas falhei ao resumir: {e}"

    header = title.strip() if title else parsed.netloc
    return f"**{header}**\n{url}\n\n{resumo.strip()}"

# ── Unified action contract (migrated from plugins/) ──────────────────────────

def resumo_link(parameters=None, player=None, session_memory=None, **_ctx):
    """TOOL handler — delegates to legacy run()."""
    params = parameters if isinstance(parameters, dict) else {}
    try:
        return run(params, player=player, session_memory=session_memory)
    except TypeError:
        try:
            return run(params, player=player)
        except TypeError:
            return run(params)


TOOL = {
    "name": "resumo_link",
    "description": ('Resume o conteúdo de uma página da web a partir de um link.  Use quando o usuário disser  ,  ,   ,  , etc.  Precisa da URL completa.'),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "url": {
                "type": "STRING",
                "description": "URL completa da página (http ou https)",
            },
            "foco": {
                "type": "STRING",
                "description": (
                    "Opcional. O que destacar no resumo "
                    "(ex: 'só a parte técnica', 'em 3 bullets')."
                ),
            },
        },
        "required": ["url"],
    },
    "handler": resumo_link,
    "tier": "plugin",
    "risk": "review",
}
