"""Alias legacy tool `system_health` → `system_monitor` (mode=health)."""
from __future__ import annotations

from actions.system_monitor import system_monitor as _impl


def system_health(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "health")
    params.setdefault("action", params.get("action") or "health")
    return _impl(params, **ctx)


TOOL = {
    "name": "system_health",
    "description": 'Alias → system_monitor mode=health',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": system_health,
    "tier": "core",
    "risk": "safe",
}
