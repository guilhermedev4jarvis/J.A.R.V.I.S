"""DeepArchives: lista e lê os arquivos de um diretório, um por vez.

Uso como módulo:
    from deeparchives import processar_diretorio
    resultados = processar_diretorio(r"C:\\Jarvis\\arquivos")

Uso no terminal:
    python deeparchives.py "C:\\Jarvis\\arquivos"

O módulo é local: não envia arquivos para serviços externos.
"""
from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator


@dataclass
class ResultadoArquivo:
    caminho: str
    status: str
    tamanho_bytes: int | None = None
    codificacao: str | None = None
    conteudo: str | None = None
    erro: str | None = None


def listar_arquivos(
    diretorio: str | Path,
    *,
    recursivo: bool = True,
) -> tuple[list[Path], list[str]]:
    """Lista todos os arquivos, retornando também erros encontrados na enumeração."""
    raiz = Path(diretorio).expanduser()
    if not raiz.exists():
        raise FileNotFoundError(f"Diretório não encontrado: {raiz}")
    if not raiz.is_dir():
        raise NotADirectoryError(f"O caminho não é um diretório: {raiz}")

    arquivos: list[Path] = []
    erros: list[str] = []

    def registrar_erro(exc: OSError) -> None:
        erros.append(f"{getattr(exc, 'filename', None) or raiz}: {exc}")

    if recursivo:
        for atual, diretorios, nomes in os.walk(
            raiz,
            topdown=True,
            onerror=registrar_erro,
            followlinks=False,
        ):
            diretorios.sort(key=str.casefold)
            for nome in sorted(nomes, key=str.casefold):
                caminho = Path(atual) / nome
                try:
                    if caminho.is_file():
                        arquivos.append(caminho)
                except OSError as exc:
                    erros.append(f"{caminho}: {exc}")
    else:
        try:
            with os.scandir(raiz) as entradas:
                for entrada in sorted(entradas, key=lambda item: item.name.casefold()):
                    try:
                        if entrada.is_file(follow_symlinks=False):
                            arquivos.append(Path(entrada.path))
                    except OSError as exc:
                        erros.append(f"{entrada.path}: {exc}")
        except OSError as exc:
            erros.append(f"{raiz}: {exc}")

    return arquivos, erros


def _detectar_binario(dados: bytes) -> bool:
    """Evita despejar bytes binários como texto corrompido no terminal."""
    amostra = dados[:8192]
    if b"\x00" in amostra:
        return True
    if not amostra:
        return False
    controles = sum(
        byte < 32 and byte not in (7, 8, 9, 10, 12, 13, 27)
        for byte in amostra
    )
    return controles / len(amostra) > 0.10


def ler_arquivo(caminho: str | Path) -> ResultadoArquivo:
    """Lê um arquivo individual, tratando permissão, I/O e codificações."""
    arquivo = Path(caminho)
    try:
        dados = arquivo.read_bytes()
    except PermissionError as exc:
        return ResultadoArquivo(str(arquivo), "sem_permissao", erro=str(exc))
    except OSError as exc:
        return ResultadoArquivo(str(arquivo), "erro_de_leitura", erro=str(exc))

    tamanho = len(dados)
    if _detectar_binario(dados):
        return ResultadoArquivo(
            str(arquivo),
            "binario_nao_decodificado",
            tamanho_bytes=tamanho,
            erro="Arquivo lido em bytes; conteúdo binário não foi convertido para texto.",
        )

    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            texto = dados.decode(encoding)
            return ResultadoArquivo(
                str(arquivo),
                "lido",
                tamanho_bytes=tamanho,
                codificacao=encoding,
                conteudo=texto,
            )
        except UnicodeDecodeError:
            continue
        except LookupError as exc:
            return ResultadoArquivo(
                str(arquivo), "erro_de_codificacao", tamanho_bytes=tamanho, erro=str(exc)
            )

    return ResultadoArquivo(
        str(arquivo),
        "erro_de_codificacao",
        tamanho_bytes=tamanho,
        erro="Nenhuma das codificações de texto suportadas conseguiu ler o arquivo.",
    )


def iterar_conteudos(
    diretorio: str | Path,
    *,
    recursivo: bool = True,
) -> Iterator[ResultadoArquivo]:
    """Percorre os arquivos em ordem e entrega o resultado de leitura de cada um."""
    arquivos, erros = listar_arquivos(diretorio, recursivo=recursivo)
    for erro in erros:
        yield ResultadoArquivo(str(diretorio), "erro_de_listagem", erro=erro)
    for arquivo in arquivos:
        yield ler_arquivo(arquivo)


def processar_diretorio(
    diretorio: str | Path,
    *,
    recursivo: bool = True,
    exibir_conteudo: bool = True,
) -> list[ResultadoArquivo]:
    """Primeiro lista todos os arquivos; depois lê cada um individualmente."""
    raiz = Path(diretorio).expanduser()
    arquivos, erros_listagem = listar_arquivos(raiz, recursivo=recursivo)

    print(f"\n[DEEPARCHIVES] Diretório: {raiz.resolve()}")
    print(f"[DEEPARCHIVES] Total de arquivos encontrados: {len(arquivos)}")
    for erro in erros_listagem:
        print(f"[AVISO/LISTAGEM] {erro}")
    for indice, arquivo in enumerate(arquivos, start=1):
        print(f"{indice:04d}. {arquivo}")

    resultados: list[ResultadoArquivo] = []
    print("\n[DEEPARCHIVES] Lendo arquivos individualmente...")
    for indice, arquivo in enumerate(arquivos, start=1):
        resultado = ler_arquivo(arquivo)
        resultados.append(resultado)
        print(f"\n--- [{indice}/{len(arquivos)}] {arquivo} ---")
        print(f"Status: {resultado.status}")
        if resultado.tamanho_bytes is not None:
            print(f"Tamanho: {resultado.tamanho_bytes} bytes")
        if resultado.codificacao:
            print(f"Codificação: {resultado.codificacao}")
        if resultado.erro:
            print(f"Erro/aviso: {resultado.erro}")
        if exibir_conteudo and resultado.conteudo is not None:
            print("Conteúdo:")
            print(resultado.conteudo)

    lidos = sum(item.status == "lido" for item in resultados)
    binarios = sum(item.status == "binario_nao_decodificado" for item in resultados)
    falhas = len(resultados) - lidos - binarios
    print(
        f"\n[DEEPARCHIVES] Finalizado: {lidos} texto(s) lido(s), "
        f"{binarios} binário(s), {falhas} falha(s)."
    )
    return resultados


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Lista e lê arquivos de um diretório, um por vez."
    )
    parser.add_argument("diretorio", nargs="?", default="arquivos", help="Diretório a percorrer.")
    parser.add_argument("--somente-diretorio", action="store_true", help="Não percorre subpastas.")
    parser.add_argument("--sem-conteudo", action="store_true", help="Não imprime o texto dos arquivos.")
    args = parser.parse_args()
    try:
        processar_diretorio(
            args.diretorio,
            recursivo=not args.somente_diretorio,
            exibir_conteudo=not args.sem_conteudo,
        )
    except (FileNotFoundError, NotADirectoryError, PermissionError) as exc:
        print(f"[DEEPARCHIVES] Não foi possível acessar o diretório: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
