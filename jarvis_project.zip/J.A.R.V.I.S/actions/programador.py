"""Alias legacy tool `programador` → `code_studio` (mode=programador)."""
from __future__ import annotations

from actions.code_studio import code_studio as _impl


def programador(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "programador")
    params.setdefault("action", params.get("action") or "programador")
    return _impl(params, **ctx)


TOOL = {
    "name": "programador",
    "description": 'Alias → code_studio mode=programador',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": programador,
    "tier": "core",
    "risk": "review",
}
