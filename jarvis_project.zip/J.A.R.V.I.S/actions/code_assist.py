"""Alias legacy tool `code_assist` → `code_studio` (mode=assist)."""
from __future__ import annotations

from actions.code_studio import code_studio as _impl


def code_assist(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "assist")
    params.setdefault("action", params.get("action") or "assist")
    return _impl(params, **ctx)


TOOL = {
    "name": "code_assist",
    "description": 'Alias → code_studio mode=assist',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_assist,
    "tier": "core",
    "risk": "review",
}
