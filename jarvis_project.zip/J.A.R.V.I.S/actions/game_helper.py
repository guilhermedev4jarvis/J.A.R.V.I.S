"""Alias legacy tool `game_helper` → `game_assistant` (mode=helper)."""
from __future__ import annotations

from actions.game_assistant import game_assistant as _impl


def game_helper(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "helper")
    params.setdefault("action", params.get("action") or "helper")
    return _impl(params, **ctx)


TOOL = {
    "name": "game_helper",
    "description": 'Alias → game_assistant mode=helper',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": game_helper,
    "tier": "core",
    "risk": "review",
}
