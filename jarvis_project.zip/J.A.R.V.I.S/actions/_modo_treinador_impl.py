"""
Plugin: modo_treinador — treinos, dieta e core por posição e idade.

Lê os arquivos da pasta config/treinador_base/ e responde com base neles.
Quando não achar material local, usa conhecimento geral + avisa pra baixar as bases.
"""

from __future__ import annotations

import json
from pathlib import Path

from core import gemini

def _base_dir() -> Path:
    return Path(__file__).resolve().parent / "treinador_base"


def _list_bases() -> list[Path]:
    d = _base_dir()
    if not d.is_dir():
        return []
    exts = {".txt", ".md", ".json", ".pdf"}
    return sorted(
        p for p in d.iterdir()
        if p.is_file() and p.suffix.lower() in exts and p.name != "README.txt"
    )


def _read_text_safe(path: Path, limit: int = 8000) -> str:
    try:
        if path.suffix.lower() == ".pdf":
            # extrai texto simples se tiver pypdf/pdfminer; senão avisa
            try:
                from pypdf import PdfReader
                reader = PdfReader(str(path))
                parts = []
                for page in reader.pages[:20]:
                    t = page.extract_text() or ""
                    parts.append(t)
                return "\n".join(parts)[:limit]
            except Exception:
                return f"[PDF {path.name} — instale pypdf pra ler o conteúdo]"
        return path.read_text(encoding="utf-8", errors="replace")[:limit]
    except Exception as e:
        return f"[erro lendo {path.name}: {e}]"


def _load_context(posicao: str, idade: str) -> str:
    files = _list_bases()
    if not files:
        return ""

    pos = (posicao or "").lower()
    age = (idade or "").lower().replace(" ", "")
    scored: list[tuple[int, Path]] = []

    for p in files:
        name = p.stem.lower()
        score = 0
        if pos and pos in name:
            score += 3
        if age and (age in name or age.replace("-", "") in name):
            score += 2
        if "dieta" in name or "nutri" in name:
            score += 1
        if "core" in name or "forca" in name or "força" in name:
            score += 1
        if score == 0:
            score = 1  # qualquer base serve como contexto geral
        scored.append((score, p))

    scored.sort(key=lambda x: (-x[0], x[1].name))
    chunks = []
    total = 0
    for _, path in scored[:6]:
        text = _read_text_safe(path)
        if not text:
            continue
        block = f"### {path.name}\n{text}\n"
        if total + len(block) > 14000:
            break
        chunks.append(block)
        total += len(block)
    return "\n".join(chunks)


def _links_sugeridos() -> str:
    return (
        "Links grátis pra baixar material base (coloque os PDFs/TXT em "
        "config/treinador_base/):\n\n"
        "1. 29 sessões de treino (PDF) — iCoachFootball\n"
        "   https://www.icoachfootball.net/29-football-training-sessions-pdf/\n\n"
        "2. Organização do treino no futebol de formação (PDF)\n"
        "   https://infolivros.org/pdfview/a-organizacao-do-treino-e-do-jogo-no-futebol-de-formacao-pedro-gil-goncalves-dos-santos-7763/\n\n"
        "3. Modelo de treino U12/U13 — FIGC (PDF)\n"
        "   https://www.figc.it/media/125461/modello-di-allenamento-per-la-categoria-esordienti-u12_u13-versione-breve.pdf\n\n"
        "4. Guias por idade — US Soccer\n"
        "   https://www.ussoccer.com/us-way/player-development/environment/age-group-guide\n\n"
        "5. Treinos por posição (casa) — Futebol Peneira\n"
        "   https://futebolpeneira.com.br/treinando-em-casa-dicas-de-treinos-por-posicao/\n\n"
        "6. Planos de sessão por idade (U13–U16) — Pembee\n"
        "   https://www.pembee.app/blog/football-training-session-plans\n"
    )


def run(parameters: dict, player=None, session_memory=None) -> str:
    acao = (parameters.get("acao") or "treino").strip().lower()
    posicao = (parameters.get("posicao") or "geral").strip().lower()
    idade = (parameters.get("idade") or "13").strip()
    pedido = (parameters.get("pedido") or "").strip()

    if player:
        try:
            player.write_log(f"JARVIS: Modo treinador → {acao} | {posicao} | {idade}")
        except Exception:
            pass

    # ---- listar bases ----
    if acao in ("listar_bases", "listar", "bases", "arquivos"):
        files = _list_bases()
        if not files:
            return (
                "Nenhum arquivo em config/treinador_base/ ainda.\n\n"
                + _links_sugeridos()
            )
        lista = "\n".join(f"  - {p.name}" for p in files)
        return f"Bases carregadas ({len(files)}):\n{lista}"

    # ---- só links ----
    if acao in ("links", "baixar", "download"):
        return _links_sugeridos()

    # ---- contexto local ----
    contexto = _load_context(posicao, idade)
    tem_base = bool(contexto)

    foco = {
        "treino": "monte um treino prático (aquecimento, parte principal, finalização/jogo, volta à calma) com tempo e séries",
        "dieta": "sugira alimentação do dia / pré e pós treino adequada à idade",
        "core": "passe exercícios de core/força funcional seguros pra idade, com séries e repetições",
        "plano": "faça um microciclo de 3–4 dias (treino + recuperação)",
        "dica": "dê 3 dicas objetivas e acionáveis",
        "ativar": "apresente o modo treinador e peça posição + o que ele quer treinar hoje",
    }.get(acao, "responda de forma prática e direta")

    prompt = f"""
Você é o treinador pessoal de futebol do Guilherme (13 anos, São José do Rio Preto).
Responda em português do Brasil, curto, direto e motivador (estilo Jarvis).

Dados do pedido:
- Ação: {acao}
- Posição: {posicao}
- Idade/categoria: {idade}
- Pedido livre: {pedido or "(nenhum)"}

{"MATERIAL BASE LOCAL (use como fonte principal):" if tem_base else "NÃO HÁ ARQUIVOS LOCAIS AINDA."}
{contexto if tem_base else "(vazio)"}

Instrução: {foco}

Regras:
- Adapte tudo à idade {idade} (sem carga de adulto, priorize técnica + coordenação + diversão).
- Se for treino em casa, use pouco material (bola, cones improvisados, peso do corpo).
- Se não tiver base local suficiente, use conhecimento geral sólido e avise no final:
  "Pra eu ficar mais preciso, baixa os PDFs e joga em config/treinador_base/".
- Nunca invente lesão ou volume perigoso.
- Resposta final: só o conteúdo útil, sem rodeio.
"""

    try:
        resposta = gemini.text(prompt, tier=gemini.SMART, timeout_ms=60_000)
    except Exception as e:
        return f"Não consegui montar o treino agora: {e}"

    if not tem_base:
        resposta += (
            "\n\n---\n"
            "Ainda não tem base local. Baixa os arquivos e coloca em "
            "config/treinador_base/ pra eu ficar afiado:\n"
            "• https://www.icoachfootball.net/29-football-training-sessions-pdf/\n"
            "• https://infolivros.org/pdfview/a-organizacao-do-treino-e-do-jogo-no-futebol-de-formacao-pedro-gil-goncalves-dos-santos-7763/\n"
            "• https://www.figc.it/media/125461/modello-di-allenamento-per-la-categoria-esordienti-u12_u13-versione-breve.pdf"
        )

    return resposta.strip()

# ── Unified action contract (migrated from plugins/) ──────────────────────────

def modo_treinador(parameters=None, player=None, session_memory=None, **_ctx):
    """_LEGACY_TOOL handler — delegates to legacy run()."""
    params = parameters if isinstance(parameters, dict) else {}
    try:
        return run(params, player=player, session_memory=session_memory)
    except TypeError:
        try:
            return run(params, player=player)
        except TypeError:
            return run(params)


_LEGACY_TOOL = {
    "name": "modo_treinador",
    "description": ('Ativa o modo treinador de futebol.  Use quando o usuário disser  ,  ,   ,  ,  ,   ,  , etc. '),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "acao": {
                "type": "STRING",
                "description": (
                    "'ativar' | 'treino' | 'dieta' | 'core' | 'plano' | 'listar_bases' | "
                    "'dica'. Padrão: treino."
                ),
            },
            "posicao": {
                "type": "STRING",
                "description": (
                    "Posição: goleiro, zagueiro, lateral, volante, meia, "
                    "ponta, atacante (ou 'geral')."
                ),
            },
            "idade": {
                "type": "STRING",
                "description": "Idade ou categoria (ex: 13, sub-13, 14).",
            },
            "pedido": {
                "type": "STRING",
                "description": "Pedido livre do usuário (ex: 'treino de finalização em casa').",
            },
        },
        "required": [],
    },
    "handler": modo_treinador,
    "tier": "plugin",
    "risk": "review",
}
