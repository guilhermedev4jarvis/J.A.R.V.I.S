"""Basic clipboard get/set via pyperclip."""
from __future__ import annotations
from core.outcome import done, failed, ask

def clipboard(parameters=None, **ctx):
    params = parameters or {}
    action = str(params.get("action") or params.get("mode") or "get").lower()
    try:
        import pyperclip
    except Exception as e:
        return failed("clipboard", f"pyperclip: {e}")
    if action in ("get", "read"):
        return done("clipboard", action="get", text=(pyperclip.paste() or "")[:4000])
    if action in ("set", "write", "copy"):
        text = str(params.get("text") or params.get("value") or "")
        pyperclip.copy(text)
        return done("clipboard", action="set", chars=len(text))
    if action == "clear":
        pyperclip.copy("")
        return done("clipboard", action="clear")
    return ask("clipboard", "action?", hint="get|set|clear")
