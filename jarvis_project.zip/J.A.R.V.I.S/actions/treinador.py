"""Unified sports coach (modo_treinador + treino_hoje). Base: config/treinador_base/."""
from __future__ import annotations

from pathlib import Path
from core.outcome import done, failed, ask

_BASE = Path(__file__).resolve().parents[1] / "config" / "treinador_base"


def _dispatch(impl: str, names: list[str], params: dict, **ctx) -> str:
    import importlib
    mod = importlib.import_module(f"actions.{impl}")
    for fn in names:
        h = getattr(mod, fn, None)
        if callable(h):
            try:
                return h(params, **ctx)
            except TypeError:
                try:
                    return h(parameters=params)
                except TypeError:
                    return h(params)
    return failed("treinador", f"missing {impl}")


def treinador(parameters=None, **ctx) -> str:
    params = dict(parameters or {})
    mode = str(params.get("mode") or params.get("action") or "hoje").strip().lower()
    params.setdefault("base_dir", str(_BASE))
    if mode in ("modo", "modo_treinador", "plan"):
        return _dispatch("_modo_treinador_impl", ["modo_treinador", "run"], params, **ctx)
    if mode in ("hoje", "treino_hoje", "today"):
        return _dispatch("_treino_hoje_impl", ["treino_hoje", "run"], params, **ctx)
    if mode == "help":
        return done("treinador", modes=["hoje", "modo"], base=str(_BASE))
    return _dispatch("_treino_hoje_impl", ["treino_hoje", "run"], params, **ctx)


TOOL = {
    "name": "treinador",
    "description": "Treinador esportivo unificado: mode=hoje|modo. Base em config/treinador_base/.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": treinador,
    "tier": "plugin",
    "risk": "safe",
}
