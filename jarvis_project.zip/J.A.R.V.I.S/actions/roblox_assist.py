"""roblox_assist — advanced Roblox modeling + project tooling for JARVIS."""
from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Optional
from xml.dom import minidom

_STRUCTURES = ("room", "box", "platform", "tower", "stairs", "wall", "house", "bridge", "arena", "pillar_grid")
_COLORS = {
    "gray": (163, 162, 165), "red": (196, 40, 28), "blue": (13, 105, 172),
    "green": (75, 151, 75), "brown": (124, 92, 70), "white": (242, 243, 243),
    "orange": (218, 133, 65), "black": (27, 42, 53), "yellow": (245, 205, 48),
}
_STUBS = {
    "ModuleScript": "--!strict\n-- {name}: {desc}\nlocal M = {{}}\nfunction M.hello()\n\treturn \"ok\"\nend\nreturn M\n",
    "Script": "--!strict\n-- {name}: {desc}\nprint(\"[{name}] server started\")\n",
    "LocalScript": "--!strict\n-- {name}: {desc}\nlocal Players = game:GetService(\"Players\")\nprint(\"[client]\")\n",
}
_PLUGIN_LUA = Path(__file__).resolve().parents[1] / "config" / "roblox_assets" / "studio_bridge_plugin.lua"


def _log(player, msg):
    if player:
        try:
            player.write_log("JARVIS: " + str(msg))
        except Exception:
            pass


def _studio_bin():
    env = os.environ.get("ROBLOX_STUDIO_PATH")
    if env and Path(env).is_file():
        return env
    system = platform.system()
    if system == "Windows":
        local = Path(os.environ.get("LOCALAPPDATA", ""))
        versions = local / "Roblox" / "Versions"
        if versions.is_dir():
            for child in sorted(versions.iterdir(), reverse=True):
                exe = child / "RobloxStudioBeta.exe"
                if exe.is_file():
                    return str(exe)
        return shutil.which("RobloxStudioBeta.exe")
    if system == "Darwin":
        for p in (
            Path("/Applications/RobloxStudio.app/Contents/MacOS/RobloxStudio"),
            Path.home() / "Applications/RobloxStudio.app/Contents/MacOS/RobloxStudio",
        ):
            if p.is_file():
                return str(p)
    return None


def _rojo_bin():
    return shutil.which("rojo")


def _blender_bin():
    env = os.environ.get("BLENDER_PATH") or os.environ.get("BLENDER")
    if env and Path(env).is_file():
        return env
    w = shutil.which("blender")
    if w:
        return w
    if platform.system() == "Windows":
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        hits = list(Path(pf).glob("Blender Foundation/Blender */blender.exe"))
        return str(hits[-1]) if hits else None
    if platform.system() == "Darwin":
        p = Path("/Applications/Blender.app/Contents/MacOS/Blender")
        return str(p) if p.is_file() else None
    for p in (Path("/usr/bin/blender"), Path("/snap/bin/blender")):
        if p.is_file():
            return str(p)
    return None


def _default_project_root(name):
    return Path.home() / "RobloxProjects" / name


def _parse_color(raw):
    if not raw:
        return _COLORS["gray"]
    key = str(raw).strip().lower()
    if key in _COLORS:
        return _COLORS[key]
    parts = [p.strip() for p in str(raw).replace(";", ",").split(",")]
    if len(parts) == 3:
        try:
            return tuple(max(0, min(255, int(float(x)))) for x in parts)
        except ValueError:
            pass
    return _COLORS["gray"]


def _num(params, key, default):
    try:
        v = params.get(key)
        return default if v is None or v == "" else float(v)
    except (TypeError, ValueError):
        return default


def _parse_size(raw, default=(4.0, 1.0, 4.0)):
    if not raw:
        return default
    if isinstance(raw, (list, tuple)) and len(raw) >= 3:
        return float(raw[0]), float(raw[1]), float(raw[2])
    parts = [p.strip() for p in str(raw).replace("x", ",").split(",")]
    if len(parts) >= 3:
        try:
            return float(parts[0]), float(parts[1]), float(parts[2])
        except ValueError:
            pass
    return default


def _init_rojo_project(root, place_name):
    root.mkdir(parents=True, exist_ok=True)
    for sub in (
        "src/ServerScriptService",
        "src/StarterPlayer/StarterPlayerScripts",
        "src/ReplicatedStorage",
        "src/Workspace",
        "assets/meshes",
    ):
        (root / sub).mkdir(parents=True, exist_ok=True)
    project = {
        "name": place_name,
        "tree": {
            "$className": "DataModel",
            "ServerScriptService": {"$path": "src/ServerScriptService"},
            "ReplicatedStorage": {"$path": "src/ReplicatedStorage"},
            "StarterPlayer": {
                "$className": "StarterPlayer",
                "StarterPlayerScripts": {"$path": "src/StarterPlayer/StarterPlayerScripts"},
            },
            "Workspace": {"$path": "src/Workspace"},
        },
    }
    (root / "default.project.json").write_text(json.dumps(project, indent=2) + "\n", encoding="utf-8")
    (root / "README.md").write_text(
        "# %s\n\nJARVIS roblox_assist + Rojo.\n" % place_name,
        encoding="utf-8",
    )


def _service_dir(root, service, script_type):
    service = service or (
        "ServerScriptService" if script_type == "Script"
        else "StarterPlayerScripts" if script_type == "LocalScript"
        else "ReplicatedStorage"
    )
    mapping = {
        "ServerScriptService": root / "src/ServerScriptService",
        "ReplicatedStorage": root / "src/ReplicatedStorage",
        "Workspace": root / "src/Workspace",
        "StarterPlayerScripts": root / "src/StarterPlayer/StarterPlayerScripts",
    }
    d = mapping.get(service, root / "src/ReplicatedStorage")
    d.mkdir(parents=True, exist_ok=True)
    return d
def _item(parent, class_name, referent=None):
    el = ET.SubElement(parent, "Item")
    el.set("class", class_name)
    if referent:
        el.set("referent", referent)
    return el


def _string(props_el, name, value):
    el = ET.SubElement(props_el, "STRING")
    el.set("name", name)
    el.text = str(value)


def _bool(props_el, name, value):
    el = ET.SubElement(props_el, "bool")
    el.set("name", name)
    el.text = "true" if value else "false"


def _token(props_el, name, value):
    el = ET.SubElement(props_el, "token")
    el.set("name", name)
    el.text = str(value)


def _vector3(props_el, name, x, y, z):
    el = ET.SubElement(props_el, "Vector3")
    el.set("name", name)
    for tag, val in (("X", x), ("Y", y), ("Z", z)):
        t = ET.SubElement(el, tag)
        t.text = str(val)


def _color3(props_el, name, rgb):
    c = ET.SubElement(props_el, "Color3")
    c.set("name", name)
    for tag, val in (("R", rgb[0] / 255.0), ("G", rgb[1] / 255.0), ("B", rgb[2] / 255.0)):
        t = ET.SubElement(c, tag)
        t.text = str(val)


def _add_part_item(parent, part, ref):
    class_name = part.get("class", "Part")
    item = _item(parent, class_name, referent=ref)
    props = ET.SubElement(item, "Properties")
    _string(props, "Name", part.get("name", "Part"))
    _bool(props, "Anchored", part.get("anchored", True))
    _bool(props, "CanCollide", part.get("can_collide", True))
    size = part.get("size", (4, 1, 4))
    _vector3(props, "size", size[0], size[1], size[2])
    pos = part.get("position", (0, 0, 0))
    cf = ET.SubElement(props, "CoordinateFrame")
    cf.set("name", "CFrame")
    for tag, val in (
        ("X", pos[0]), ("Y", pos[1]), ("Z", pos[2]),
        ("R00", 1), ("R01", 0), ("R02", 0),
        ("R10", 0), ("R11", 1), ("R12", 0),
        ("R20", 0), ("R21", 0), ("R22", 1),
    ):
        t = ET.SubElement(cf, tag)
        t.text = str(val)
    _color3(props, "Color3", part.get("color", (163, 162, 165)))
    mat_map = {
        "Plastic": "256", "SmoothPlastic": "10752", "Concrete": "1040",
        "Brick": "528", "Wood": "784", "Metal": "1296", "Grass": "1280",
        "Slate": "10496", "Stone": "1056",
    }
    mat = part.get("material", "Concrete")
    _token(props, "Material", mat_map.get(mat, "1040"))
    return item


def structure_to_parts(structure, opts):
    W, H, D = opts["width"], opts["height"], opts["depth"]
    ox, oy, oz = opts["x"], opts["y"], opts["z"]
    rgb = opts["color"]
    mat = opts["material"]
    t = 1.0
    floors = int(opts.get("floors", 3))
    parts = []

    def add(name, size, pos, class_name="Part"):
        parts.append({
            "name": name, "size": size, "position": pos,
            "color": rgb, "material": mat, "class": class_name, "anchored": True,
        })

    if structure == "box":
        add("Box", (W, H, D), (ox, oy + H / 2, oz))
    elif structure == "platform":
        add("Platform", (W, t, D), (ox, oy + t / 2, oz))
    elif structure == "wall":
        add("Wall", (W, H, t), (ox, oy + H / 2, oz))
    elif structure == "room":
        add("Floor", (W, t, D), (ox, oy + t / 2, oz))
        add("Ceiling", (W, t, D), (ox, oy + H - t / 2, oz))
        add("WallN", (W, H - 2 * t, t), (ox, oy + H / 2, oz - D / 2 + t / 2))
        add("WallS", (W, H - 2 * t, t), (ox, oy + H / 2, oz + D / 2 - t / 2))
        add("WallW", (t, H - 2 * t, D - 2 * t), (ox - W / 2 + t / 2, oy + H / 2, oz))
        add("WallE", (t, H - 2 * t, D - 2 * t), (ox + W / 2 - t / 2, oy + H / 2, oz))
    elif structure == "tower":
        for i in range(floors):
            base = oy + i * H
            add("Floor_%d" % (i + 1), (W, t, D), (ox, base + t / 2, oz))
            add("WallN_%d" % (i + 1), (W, H - t, t), (ox, base + H / 2, oz - D / 2 + t / 2))
            add("WallS_%d" % (i + 1), (W, H - t, t), (ox, base + H / 2, oz + D / 2 - t / 2))
            add("WallW_%d" % (i + 1), (t, H - t, D - 2 * t), (ox - W / 2 + t / 2, base + H / 2, oz))
            add("WallE_%d" % (i + 1), (t, H - t, D - 2 * t), (ox + W / 2 - t / 2, base + H / 2, oz))
        add("Roof", (W + 2, t, D + 2), (ox, oy + floors * H + t / 2, oz))
    elif structure == "stairs":
        steps = max(3, int(H))
        step_h = H / steps
        step_d = max(1.5, D / steps)
        for i in range(steps):
            add(
                "Step_%d" % (i + 1),
                (W, step_h, step_d),
                (ox, oy + i * step_h + step_h / 2, oz - D / 2 + i * step_d + step_d / 2),
                "WedgePart",
            )
    elif structure == "house":
        add("Floor", (W, t, D), (ox, oy + t / 2, oz))
        add("WallN", (W, H, t), (ox, oy + H / 2, oz - D / 2 + t / 2))
        add("WallS", (W, H, t), (ox, oy + H / 2, oz + D / 2 - t / 2))
        add("WallW", (t, H, D - 2 * t), (ox - W / 2 + t / 2, oy + H / 2, oz))
        add("WallE", (t, H, D - 2 * t), (ox + W / 2 - t / 2, oy + H / 2, oz))
        add("Chimney", (2, H * 0.4, 2), (ox + W * 0.25, oy + H + 2, oz - D * 0.15))
    elif structure == "bridge":
        add("Deck", (W, t, D), (ox, oy + H, oz))
        pillars = max(2, int(D // 12))
        for i in range(pillars):
            z = oz - D / 2 + (i + 0.5) * (D / pillars)
            add("PillarL_%d" % (i + 1), (2, H, 2), (ox - W / 2 + 2, oy + H / 2, z))
            add("PillarR_%d" % (i + 1), (2, H, 2), (ox + W / 2 - 2, oy + H / 2, z))
    elif structure == "arena":
        R = max(W, D) / 2
        add("ArenaFloor", (R * 2, t, R * 2), (ox, oy + t / 2, oz))
    elif structure == "pillar_grid":
        cols = max(2, int(W // 8))
        rows = max(2, int(D // 8))
        for ix in range(cols):
            for iz in range(rows):
                px = ox - W / 2 + (ix + 0.5) * (W / cols)
                pz = oz - D / 2 + (iz + 0.5) * (D / rows)
                add("Pillar_%d_%d" % (ix + 1, iz + 1), (2, H, 2), (px, oy + H / 2, pz))
        add("Canopy", (W, 1, D), (ox, oy + H + 0.5, oz))
    else:
        add("Box", (W, H, D), (ox, oy + H / 2, oz))
    return parts


def write_rbxmx(path, model_name, parts, scripts=None):
    root = ET.Element("roblox")
    root.set("xmlns:xmime", "http://www.w3.org/2005/05/xmlmime")
    root.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
    root.set("xsi:noNamespaceSchemaLocation", "http://www.roblox.com/roblox.xsd")
    root.set("version", "4")
    meta = ET.SubElement(root, "Meta")
    meta.set("name", "ExplicitAutoJoints")
    meta.text = "true"
    model = _item(root, "Model", referent="RBX0")
    props = ET.SubElement(model, "Properties")
    _string(props, "Name", model_name)
    for i, part in enumerate(parts):
        _add_part_item(model, part, ref="RBX%d" % (i + 1))
    if scripts:
        for j, sc in enumerate(scripts):
            s_item = _item(model, sc.get("class", "Script"), referent="RBXS%d" % j)
            sp = ET.SubElement(s_item, "Properties")
            _string(sp, "Name", sc.get("name", "Script"))
            src = ET.SubElement(sp, "ProtectedString")
            src.set("name", "Source")
            src.text = sc.get("source", "-- empty")
    rough = ET.tostring(root, encoding="utf-8")
    pretty = minidom.parseString(rough).toprettyxml(indent="  ", encoding="utf-8")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(pretty)
    return path


def _structure_opts(params):
    return {
        "width": _num(params, "width", 24),
        "height": _num(params, "height", 12),
        "depth": _num(params, "depth", 24),
        "floors": _num(params, "floors", 3),
        "material": str(params.get("material") or "Concrete").replace(" ", ""),
        "color": _parse_color(params.get("color")),
        "x": _num(params, "x", 0),
        "y": _num(params, "y", 0),
        "z": _num(params, "z", 0),
        "model_name": str(params.get("model_name") or "JarvisModel"),
    }
def _blender_mesh_pipeline(params, player=None):
    try:
        from core import engine_bridge
        name = str(params.get("name") or "OrganicMesh").replace(" ", "_")
        path = params.get("path")
        from pathlib import Path as _P
        root = _P(path) if path else _P.home() / "RobloxProjects" / "JarvisBuild"
        out_dir = root / "assets" / "meshes"
        out_dir.mkdir(parents=True, exist_ok=True)
        fmt = str(params.get("format") or "fbx").lower()
        out_file = _P(params["output"]) if params.get("output") else out_dir / (name + "." + fmt)
        res = engine_bridge.blender_mesh_export(
            name=name,
            output=str(out_file),
            fmt=fmt,
            prompt=str(params.get("prompt") or ""),
        )
        if res.get("ok"):
            return "status=done action=roblox_assist detail=blender_mesh output=%s via=engine_bridge" % out_file
        return "status=failed action=roblox_assist reason=%s" % (res.get("error") or res.get("log_tail") or "blender_failed")
    except Exception as _e:
        return "status=failed action=roblox_assist reason=%s" % _e
    # legacy fallback unreachable
def _blender_mesh_pipeline(params, player=None):
    try:
        from core import engine_bridge
        name = str(params.get("name") or "OrganicMesh").replace(" ", "_")
        path = params.get("path")
        from pathlib import Path as _P
        root = _P(path) if path else _P.home() / "RobloxProjects" / "JarvisBuild"
        out_dir = root / "assets" / "meshes"
        out_dir.mkdir(parents=True, exist_ok=True)
        fmt = str(params.get("format") or "fbx").lower()
        out_file = _P(params["output"]) if params.get("output") else out_dir / (name + "." + fmt)
        res = engine_bridge.blender_mesh_export(
            name=name,
            output=str(out_file),
            fmt=fmt,
            prompt=str(params.get("prompt") or ""),
        )
        if res.get("ok"):
            return "status=done action=roblox_assist detail=blender_mesh output=%s via=engine_bridge" % out_file
        return "status=failed action=roblox_assist reason=%s" % (res.get("error") or res.get("log_tail") or "blender_failed")
    except Exception as _e:
        return "status=failed action=roblox_assist reason=%s" % _e
    # legacy fallback unreachable
def run(parameters, player=None, session_memory=None):
    params = parameters or {}
    action = str(params.get("action") or "status").strip().lower()

    if action in ("bridge_start", "start_bridge"):
        try:
            from core import roblox_bridge
            port = int(params.get("port") or 28859)
            st = roblox_bridge.start(port=port)
            return (
                "status=done action=roblox_assist detail=bridge_start url=%s running=%s plugin_lua=%s "
                "note=Install studio_bridge_plugin.lua in Studio Plugins folder; enable HttpService; Connect"
                % (st.get("base_url"), st.get("running"), _PLUGIN_LUA)
            )
        except Exception as e:
            return "status=failed action=roblox_assist reason=bridge_start_failed error=%s" % e

    if action in ("bridge_stop", "stop_bridge"):
        try:
            from core import roblox_bridge
            st = roblox_bridge.stop()
            return "status=done action=roblox_assist detail=bridge_stop running=%s" % st.get("running")
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action == "bridge_status":
        try:
            from core import roblox_bridge
            st = roblox_bridge.status()
            return "status=done action=roblox_assist detail=bridge_status data=%r" % st
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action in ("build_live", "create_part_live"):
        try:
            from core import roblox_bridge
            if not roblox_bridge.is_running():
                roblox_bridge.start(port=int(params.get("port") or 28859))
            if action == "create_part_live":
                size = _parse_size(params.get("size"), (4, 1, 4))
                color = _parse_color(params.get("color"))
                op = {
                    "type": "create_part",
                    "className": str(params.get("class_name") or "Part"),
                    "Name": str(params.get("name") or "Part"),
                    "Size": list(size),
                    "Position": [_num(params, "x", 0), _num(params, "y", 1), _num(params, "z", 0)],
                    "Color": list(color),
                    "Material": str(params.get("material") or "Concrete"),
                    "model": str(params.get("model_name") or "JarvisBuild"),
                }
            else:
                structure = str(params.get("structure") or "room").lower()
                if structure not in _STRUCTURES:
                    return "status=ask action=roblox_assist question=structure? options=%s" % ("|".join(_STRUCTURES))
                opts = _structure_opts(params)
                op = {
                    "type": "build_structure",
                    "structure": structure,
                    "width": opts["width"],
                    "height": opts["height"],
                    "depth": opts["depth"],
                    "floors": int(opts["floors"]),
                    "material": opts["material"],
                    "color": list(opts["color"]),
                    "origin": [opts["x"], opts["y"], opts["z"]],
                    "model": opts["model_name"] if opts["model_name"] != "JarvisModel" else ("Jarvis_%s" % structure.title()),
                }
            if params.get("op"):
                try:
                    op = json.loads(params["op"]) if isinstance(params["op"], str) else params["op"]
                except Exception:
                    pass
            rec = roblox_bridge.enqueue(op)
            return (
                "status=done action=roblox_assist detail=%s id=%s op_type=%s "
                "note=Studio plugin must be Connected"
                % (action, rec["id"], op.get("type"))
            )
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action == "export_rbxmx":
        structure = str(params.get("structure") or "house").lower()
        if structure not in _STRUCTURES:
            structure = "box"
        opts = _structure_opts(params)
        model_name = opts["model_name"] if opts["model_name"] != "JarvisModel" else ("Jarvis_%s" % structure.title())
        parts = structure_to_parts(structure, opts)
        out = params.get("output") or params.get("path")
        if out and str(out).endswith(".rbxmx"):
            dest = Path(str(out))
        else:
            base = Path(out) if out else _default_project_root("JarvisBuild")
            if base.suffix:
                base = base.parent
            dest = base / "assets" / (model_name + ".rbxmx")
        try:
            write_rbxmx(dest, model_name, parts)
            return (
                "status=done action=roblox_assist detail=export_rbxmx path=%s parts=%d model=%s "
                "note=Drag .rbxmx into Studio"
                % (dest, len(parts), model_name)
            )
        except Exception as e:
            return "status=failed action=roblox_assist reason=rbxmx_failed error=%s" % e

    if action in ("blender_mesh", "organic_mesh"):
        try:
            return _blender_mesh_pipeline(params, player=player)
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action == "install_plugin_help":
        return (
            "status=done action=roblox_assist detail=install_plugin_help lua_path=%s "
            "steps=1_Copy_to_Roblox_Plugins_folder|2_Restart_Studio|3_bridge_start|4_Click_Connect|5_Allow_HttpService"
            % _PLUGIN_LUA
        )

    if action in ("status", "info", ""):
        try:
            from core import roblox_bridge
            br = roblox_bridge.status()
        except Exception:
            br = {"running": False, "base_url": ""}
        return (
            "status=done action=roblox_assist detail=status studio=%s rojo=%s blender=%s "
            "bridge_running=%s bridge_url=%s structures=%s"
            % (
                "found" if _studio_bin() else "not_found",
                "found" if _rojo_bin() else "not_found",
                "found" if _blender_bin() else "not_found",
                br.get("running"),
                br.get("base_url", ""),
                ",".join(_STRUCTURES),
            )
        )

    if action == "list_structures":
        return "status=done action=roblox_assist detail=list_structures options=%s" % list(_STRUCTURES)

    if action == "build_structure":
        results = []
        try:
            from core import roblox_bridge
            if roblox_bridge.is_running():
                results.append(run(dict(params, action="build_live"), player=player))
        except Exception:
            pass
        results.append(run(dict(params, action="export_rbxmx"), player=player))
        return "status=done action=roblox_assist detail=build_structure modes=%d last=%s" % (
            len(results), results[-1] if results else ""
        )

    if action == "open_studio":
        studio = _studio_bin()
        if not studio:
            return "status=failed action=roblox_assist reason=studio_not_found"
        try:
            subprocess.Popen([studio], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return "status=started action=roblox_assist detail=open_studio"
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action == "new_project":
        name = str(params.get("name") or "MeuPlace").strip().replace(" ", "")
        path = params.get("path")
        root = Path(path) if path else _default_project_root(name)
        if root.exists() and any(root.iterdir()):
            return "status=failed action=roblox_assist reason=folder_not_empty path=%s" % root
        try:
            _init_rojo_project(root, name)
            return "status=done action=roblox_assist detail=new_project path=%s name=%s" % (root, name)
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action == "add_script":
        path = params.get("path")
        if not path:
            return "status=ask action=roblox_assist question=path?"
        root = Path(path)
        if not root.is_dir():
            return "status=failed action=roblox_assist reason=path_not_dir"
        name = str(params.get("name") or "NewScript").strip().replace(" ", "")
        stype = str(params.get("script_type") or "ModuleScript").strip()
        if stype not in _STUBS:
            return "status=ask action=roblox_assist question=script_type?"
        body = params.get("code") or _STUBS[stype].format(name=name, desc=params.get("description") or "JARVIS")
        dest = _service_dir(root, str(params.get("service") or ""), stype) / (name + ".lua")
        if dest.exists():
            return "status=failed action=roblox_assist reason=exists path=%s" % dest
        dest.write_text(body, encoding="utf-8")
        dest.with_suffix(dest.suffix + ".meta.json").write_text(
            json.dumps({"className": stype}, indent=2) + "\n", encoding="utf-8"
        )
        return "status=done action=roblox_assist detail=add_script type=%s path=%s" % (stype, dest)

    if action == "list_scripts":
        path = params.get("path")
        if not path:
            return "status=ask action=roblox_assist question=path?"
        root = Path(path)
        luas = sorted(root.rglob("*.lua")) if root.is_dir() else []
        rel = [str(p.relative_to(root)) for p in luas[:80]]
        return "status=done action=roblox_assist detail=list_scripts count=%s files=%r" % (len(luas), rel)

    if action == "rojo_serve":
        path = params.get("path")
        if not path:
            return "status=ask action=roblox_assist question=path?"
        rojo = _rojo_bin()
        if not rojo:
            return "status=failed action=roblox_assist reason=rojo_not_found"
        try:
            subprocess.Popen([rojo, "serve"], cwd=str(path), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return "status=started action=roblox_assist detail=rojo_serve path=%s" % path
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    if action == "open_folder":
        path = params.get("path")
        if not path:
            return "status=ask action=roblox_assist question=path?"
        root = Path(path)
        if not root.exists():
            return "status=failed action=roblox_assist reason=path_missing"
        system = platform.system()
        try:
            if system == "Windows":
                os.startfile(str(root))
            elif system == "Darwin":
                subprocess.Popen(["open", str(root)])
            else:
                subprocess.Popen(["xdg-open", str(root)])
            return "status=started action=roblox_assist detail=open_folder path=%s" % root
        except Exception as e:
            return "status=failed action=roblox_assist reason=%s" % e

    return (
        "status=ask action=roblox_assist question=action? "
        "options=status|bridge_start|bridge_stop|build_live|create_part_live|"
        "export_rbxmx|blender_mesh|build_structure|list_structures|"
        "open_studio|new_project|add_script|install_plugin_help"
    )

# ── Unified action contract (migrated from plugins/) ──────────────────────────

def roblox_assist(parameters=None, player=None, session_memory=None, **_ctx):
    """TOOL handler — delegates to legacy run()."""
    params = parameters if isinstance(parameters, dict) else {}
    try:
        return run(params, player=player, session_memory=session_memory)
    except TypeError:
        try:
            return run(params, player=player)
        except TypeError:
            return run(params)


TOOL = {
    "name": "roblox_assist",
    "description": ('Roblox Studio avancado: modelagem 3D ao vivo via bridge HTTP, export .rbxmx, '),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "see description"},
            "path": {"type": "STRING"},
            "name": {"type": "STRING"},
            "script_type": {"type": "STRING"},
            "service": {"type": "STRING"},
            "code": {"type": "STRING"},
            "description": {"type": "STRING"},
            "structure": {"type": "STRING"},
            "width": {"type": "NUMBER"},
            "height": {"type": "NUMBER"},
            "depth": {"type": "NUMBER"},
            "floors": {"type": "NUMBER"},
            "material": {"type": "STRING"},
            "color": {"type": "STRING"},
            "x": {"type": "NUMBER"},
            "y": {"type": "NUMBER"},
            "z": {"type": "NUMBER"},
            "model_name": {"type": "STRING"},
            "run_on_start": {"type": "STRING"},
            "port": {"type": "NUMBER"},
            "class_name": {"type": "STRING"},
            "size": {"type": "STRING"},
            "prompt": {"type": "STRING"},
            "format": {"type": "STRING"},
            "output": {"type": "STRING"},
            "op": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": roblox_assist,
    "tier": "plugin",
    "risk": "review",
}
