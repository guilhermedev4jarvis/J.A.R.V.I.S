"""Alias legacy tool `file_processor` → `file_manager` (mode=process)."""
from __future__ import annotations

from actions.file_manager import file_manager as _impl


def file_processor(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "process")
    params.setdefault("action", params.get("action") or "process")
    return _impl(params, **ctx)


TOOL = {
    "name": "file_processor",
    "description": 'Alias → file_manager mode=process',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": file_processor,
    "tier": "core",
    "risk": "review",
}
