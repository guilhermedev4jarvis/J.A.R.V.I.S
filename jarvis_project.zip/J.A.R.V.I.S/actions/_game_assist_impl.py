"""
game_assist — sessão unificada de jogo (rede + coach + player).

Substitui o uso separado de network_guard, game_coach e game_player com uma
única action. Por baixo dos panos reutiliza os handlers desses módulos.

Modos principais:
  session_start / session_stop / session_status
      Liga (ou desliga) rede + coach juntos — o “modo ranked”.

  net_*     → network_guard   (start/stop/status/check)
  coach_*   → game_coach      (start/stop/status/tip/categories)
  play_*    → game_player     (dino/hold/macro/reaction/stop/status)

Atalhos legados (action=dino, hold, tip, …) também funcionam.
Nunca faz aimbot / detecção de inimigos em shooters online.
"""
from __future__ import annotations

from typing import Any

from core.outcome import done, failed, ask

# Import handlers from the specialised modules (same process, shared state).
from actions.network_guard import network_guard
from actions.game_coach import game_coach
from actions.game_player import game_player


def _dispatch_net(sub: str, params: dict) -> str:
    p = dict(params)
    p["action"] = sub
    return network_guard(p)


def _dispatch_coach(sub: str, params: dict) -> str:
    p = dict(params)
    p["action"] = sub
    return game_coach(p)


def _dispatch_play(sub: str, params: dict) -> str:
    p = dict(params)
    p["action"] = sub
    return game_player(p)


def _session_start(params: dict) -> str:
    """Start network guard + coach together."""
    game = (params.get("game") or "Fortnite").strip()
    topic = (params.get("topic") or "").strip()
    try:
        net_interval = int(params.get("net_interval_sec") or params.get("interval_sec") or 1200)
    except (TypeError, ValueError):
        net_interval = 1200
    try:
        coach_interval = int(params.get("coach_interval_sec") or 720)
    except (TypeError, ValueError):
        coach_interval = 720

    net_res = network_guard({
        "action": "start",
        "interval_sec": net_interval,
    })
    coach_res = game_coach({
        "action": "start",
        "game": game,
        "topic": topic,
        "interval_sec": coach_interval,
    })

    net_ok = "status=started" in net_res or "status=done" in net_res
    coach_ok = "status=started" in coach_res or "status=done" in coach_res

    if net_ok and coach_ok:
        return done(
            "game_assist",
            action="session_start",
            game=game,
            network="on",
            coach="on",
            net_interval_sec=net_interval,
            coach_interval_sec=coach_interval,
            note=(
                f"Session on for {game}: network alerts (~every {net_interval // 60} min when good) "
                f"+ voice coach (~every {coach_interval // 60} min). "
                "Use action=session_stop to end both. "
                "play_dino / play_hold / play_macro still available separately."
            ),
        )

    return failed(
        "game_assist",
        "could not start full session",
        network_result=net_res[:300],
        coach_result=coach_res[:300],
    )


def _session_stop(params: dict) -> str:
    net_res = network_guard({"action": "stop"})
    coach_res = game_coach({"action": "stop"})
    # Also stop any active player loop
    play_res = game_player({"action": "stop"})
    return done(
        "game_assist",
        action="session_stop",
        network=_short(net_res),
        coach=_short(coach_res),
        player=_short(play_res),
        note="Network guard, coach and player loops stopped.",
    )


def _session_status(params: dict) -> str:
    net = network_guard({"action": "status"})
    coach = game_coach({"action": "status"})
    play = game_player({"action": "status"})
    return done(
        "game_assist",
        action="session_status",
        network=_short(net),
        coach=_short(coach),
        player=_short(play),
    )


def _short(outcome: str, n: int = 220) -> str:
    s = (outcome or "").replace("\n", " ")
    return s if len(s) <= n else s[:n] + "…"


# Map unified action names → (subsystem, sub-action)
_MAP: dict[str, tuple[str, str]] = {
    # session
    "session_start": ("session", "start"),
    "session_stop": ("session", "stop"),
    "session_status": ("session", "status"),
    "start_session": ("session", "start"),
    "stop_session": ("session", "stop"),
    "ranked": ("session", "start"),
    "modo_ranked": ("session", "start"),
    # network
    "net_start": ("net", "start"),
    "net_stop": ("net", "stop"),
    "net_status": ("net", "status"),
    "net_check": ("net", "check"),
    "network": ("net", "status"),
    "net": ("net", "status"),
    # coach
    "coach_start": ("coach", "start"),
    "coach_stop": ("coach", "stop"),
    "coach_status": ("coach", "status"),
    "coach_tip": ("coach", "tip"),
    "tip": ("coach", "tip"),
    "coach": ("coach", "status"),
    "categories": ("coach", "categories"),
    # player
    "play_dino": ("play", "dino"),
    "dino": ("play", "dino"),
    "play_hold": ("play", "hold"),
    "hold": ("play", "hold"),
    "play_macro": ("play", "macro"),
    "macro": ("play", "macro"),
    "play_reaction": ("play", "reaction"),
    "reaction": ("play", "reaction"),
    "play_stop": ("play", "stop"),
    "play_status": ("play", "status"),
    "play": ("play", "status"),
}


def game_assist(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = (params.get("action") or params.get("mode") or "session_status").strip().lower()

    # Allow dotted form: action="net.start" or "coach.tip"
    if "." in action:
        left, right = action.split(".", 1)
        action = f"{left}_{right}"

    # Session bundle
    if action in ("session_start", "start_session", "ranked", "modo_ranked"):
        return _session_start(params)
    if action in ("session_stop", "stop_session"):
        return _session_stop(params)
    if action in ("session_status", "status"):
        return _session_status(params)

    mapped = _MAP.get(action)
    if not mapped:
        return ask(
            "game_assist",
            "what should I do?",
            options=(
                "session_start (game=Fortnite) | session_stop | session_status | "
                "net_start/stop/check | coach_start/tip/stop | "
                "dino | hold | macro | play_stop"
            ),
        )

    system, sub = mapped
    if system == "session":
        if sub == "start":
            return _session_start(params)
        if sub == "stop":
            return _session_stop(params)
        return _session_status(params)
    if system == "net":
        return _dispatch_net(sub, params)
    if system == "coach":
        return _dispatch_coach(sub, params)
    if system == "play":
        return _dispatch_play(sub, params)

    return failed("game_assist", f"unknown subsystem {system}")


_LEGACY_TOOL = {
    "name": "game_assist",
    "description": (
        "Unified gaming assistant: network lag alerts + voice coach tips + simple "
        "player helpers (Chrome dino, key hold, macros). "
        "Prefer this over calling network_guard, game_coach or game_player separately. "
        "\n"
        "SESSION: session_start (game=Fortnite) turns on network monitor + coach together; "
        "session_stop ends both (and any player loop); session_status reports all three.\n"
        "NETWORK: net_start, net_stop, net_check, net_status "
        "(~20 min interval when net is good; faster when laggy).\n"
        "COACH: coach_start, coach_tip, coach_stop, categories "
        "(positioning, building, loot, rotation, survival, aim_habits, mindset).\n"
        "PLAYER: dino, hold (keys=w mouse=left), macro, reaction, play_stop — "
        "offline/simple assists only; NO aimbot or enemy ESP for online shooters.\n"
        "Aliases: ranked, tip, dino, hold, status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "session_start|session_stop|session_status|"
                    "net_start|net_stop|net_check|net_status|"
                    "coach_start|coach_tip|coach_stop|categories|"
                    "dino|hold|macro|reaction|play_stop|play_status"
                ),
            },
            "game": {
                "type": "STRING",
                "description": "For session_start / coach_start / tip (default Fortnite)",
            },
            "topic": {
                "type": "STRING",
                "description": "Optional coach focus (e.g. endgame, solo ranked)",
            },
            "category": {
                "type": "STRING",
                "description": "For tip: positioning|building|loot|rotation|survival|aim_habits|mindset",
            },
            "net_interval_sec": {
                "type": "NUMBER",
                "description": "Seconds between net checks when network is good (default 1200)",
            },
            "coach_interval_sec": {
                "type": "NUMBER",
                "description": "Seconds between coach tips (default 720)",
            },
            "keys": {
                "type": "STRING",
                "description": "For hold: e.g. 'w' or 'w a'",
            },
            "mouse": {
                "type": "STRING",
                "description": "For hold: left|right|middle",
            },
            "duration": {
                "type": "NUMBER",
                "description": "For hold: seconds (omit = until play_stop)",
            },
            "name": {
                "type": "STRING",
                "description": "For macro: saved macro name",
            },
            "steps": {
                "type": "ARRAY",
                "description": "For macro: list of step objects",
            },
            "region": {
                "type": "STRING",
                "description": "For dino/reaction: left,top,width,height",
            },
        },
        "required": [],
    },
    "handler": game_assist,
    "tier": "core",
}
