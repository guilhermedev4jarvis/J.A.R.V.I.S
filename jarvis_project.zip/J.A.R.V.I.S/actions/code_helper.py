"""Alias legacy tool `code_helper` → `code_studio` (mode=helper)."""
from __future__ import annotations

from actions.code_studio import code_studio as _impl


def code_helper(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "helper")
    params.setdefault("action", params.get("action") or "helper")
    return _impl(params, **ctx)


TOOL = {
    "name": "code_helper",
    "description": 'Alias → code_studio mode=helper',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_helper,
    "tier": "core",
    "risk": "review",
}
