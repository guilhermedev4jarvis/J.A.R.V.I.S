"""Alias legacy tool `modo_treinador` → `treinador` (mode=modo)."""
from __future__ import annotations

from actions.treinador import treinador as _impl


def modo_treinador(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "modo")
    params.setdefault("action", params.get("action") or "modo")
    return _impl(params, **ctx)


TOOL = {
    "name": "modo_treinador",
    "description": 'Alias → treinador mode=modo',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": modo_treinador,
    "tier": "core",
    "risk": "safe",
}
