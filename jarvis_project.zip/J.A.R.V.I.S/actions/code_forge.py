"""Alias legacy tool `code_forge` → `code_studio` (mode=forge)."""
from __future__ import annotations

from actions.code_studio import code_studio as _impl


def code_forge(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "forge")
    params.setdefault("action", params.get("action") or "forge")
    return _impl(params, **ctx)


TOOL = {
    "name": "code_forge",
    "description": 'Alias → code_studio mode=forge',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_forge,
    "tier": "core",
    "risk": "review",
}
