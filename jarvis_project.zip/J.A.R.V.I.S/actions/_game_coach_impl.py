"""
game_coach — modo coach por voz com dicas gerais e atualizadas.

Enquanto a sessão está ativa, a cada N minutos (default ~12) entrega uma dica
rotativa de:
  positioning | building | loot | rotation | survival | aim_habits | mindset

Fontes (nessa ordem):
  1. Gemini (se API key configurada) — pede dica curta e atual do jogo/season
  2. Fallback local honesto (frameworks atemporais, sem inventar patch notes)

Não joga por você, não lê a tela do jogo para achar inimigos, não atira.
É coach de voz / texto.
"""
from __future__ import annotations

import json
import random
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from core.outcome import done, failed, ask, started

_BASE = Path(__file__).resolve().parent.parent
_STATE_PATH = _BASE / "config" / "game_coach.json"
_lock = threading.Lock()

_worker: threading.Thread | None = None
_stop_event = threading.Event()
_runtime: dict[str, Any] = {
    "running": False,
    "game": None,
    "started_at": None,
    "tips_given": 0,
    "last_tip": None,
    "last_category": None,
}

_CATEGORIES = (
    "positioning",
    "building",
    "loot",
    "rotation",
    "survival",
    "aim_habits",
    "mindset",
)

_FALLBACK: dict[str, list[str]] = {
    "positioning": [
        "Priorize high ground e cover antes de trocar tiro; ângulo > mira perfeita.",
        "Evite horizonte aberto: sempre tenha uma rota de escape mental antes do fight.",
        "Em third-party, espere o segundo time gastar utilitário — depois entre.",
        "Som de passo à direita não significa inimigo à direita: confira vertical também.",
    ],
    "building": [
        "Cone + floor rápido cria cover instantâneo; pratique o edit de 90° no creative.",
        "Não overbuild no early: materiais são vida no mid-game.",
        "Wall em sua frente + edit window é mais seguro que peek largo.",
        "Se o oponente spamma, reforçe a peça que ele está quebrando, não a do lado.",
    ],
    "loot": [
        "Priorize shield e mobilidade antes de arma 'bonita' com pouco utilitário.",
        "Duas armas de ranges diferentes batem loadout de um range só.",
        "Deixe slot mental para heal; inventário cheio de tiro sem shield perde fight.",
        "Loot barulhento em zona quente atrai third party — seja rápido e saia.",
    ],
    "rotation": [
        "Rotacione cedo por edge ou por cover natural; storm fight só se necessário.",
        "Olhe o mapa: se 3 times colidem no mesmo POI, você não precisa ser o quarto.",
        "Guarde mobilidade (pad, shockwave, veiculo) para a zone final, não gaste no mid.",
        "Rotação alta (high ground path) custa material mas vende menos costas.",
    ],
    "survival": [
        "Depois de um kill, heal imediatamente — o third party chega em segundos.",
        "Não reinicie fight com metade de HP se tiver cover e tempo de potion.",
        "Disengage é skill: porta dos fundos > ego.",
        "Audio > visual em close range; baixe música do jogo um pouco se estiver tiltado.",
    ],
    "aim_habits": [
        "Aqueça 5–10 min em aim trainer ou creative antes de ranked — consistência > hero play.",
        "Crosshair na altura da cabeça no nível que você espera o inimigo, não no chão.",
        "Primeiro tiro no peito, depois rastreie a cabeça; não force headshot no spray.",
        "Se errou o primeiro spray, reset atrás de cover em vez de re-peek no mesmo timing.",
    ],
    "mindset": [
        "Uma death boba não define a session — respire e foque a próxima decisão.",
        "Tilt acelera rotas ruins; se perdeu 3 fights seguidos, troque de modo 10 min.",
        "VOD de 1 death por session ensina mais que 20 wins no piloto automático.",
        "Jogue para melhorar uma mecânica por dia, não para salvar o rank em uma night.",
    ],
}


def _api_key() -> str:
    p = _BASE / "config" / "api_keys.json"
    try:
        return json.loads(p.read_text(encoding="utf-8")).get("gemini_api_key") or ""
    except Exception:
        return ""


def _load() -> dict:
    try:
        return json.loads(_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {
            "default_game": "Fortnite",
            "interval_sec": 12 * 60,
            "history": [],
        }


def _save(data: dict) -> None:
    _STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = datetime.now().isoformat(timespec="seconds")
    _STATE_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _gemini_tip(game: str, category: str, topic: str = "") -> Optional[str]:
    key = _api_key()
    if not key:
        return None
    try:
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=key)
        prompt = (
            f"You are a concise in-game voice coach for {game}. "
            f"Give ONE practical tip on '{category}'"
            + (f" focusing on '{topic}'" if topic else "")
            + ". "
            "Max 2 short sentences. No patch-note invention if unsure — speak evergreen fundamentals. "
            "No preamble, no bullet list, plain text the player can hear aloud."
        )
        resp = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt,
            config=types.GenerateContentConfig(temperature=0.7, max_output_tokens=120),
        )
        text = (getattr(resp, "text", None) or "").strip()
        if not text:
            return None
        # keep it speakable
        text = re.sub(r"\s+", " ", text)
        return text[:400]
    except Exception:
        return None


def _fallback_tip(category: str) -> str:
    pool = _FALLBACK.get(category) or _FALLBACK["mindset"]
    return random.choice(pool)


def _pick_category(prefer: str | None, last: str | None) -> str:
    if prefer and prefer in _CATEGORIES:
        return prefer
    choices = [c for c in _CATEGORIES if c != last] or list(_CATEGORIES)
    return random.choice(choices)


def _one_tip(game: str, category: str, topic: str = "") -> dict:
    source = "gemini"
    text = _gemini_tip(game, category, topic)
    if not text:
        source = "fallback"
        text = _fallback_tip(category)
    return {
        "at": datetime.now().isoformat(timespec="seconds"),
        "game": game,
        "category": category,
        "source": source,
        "tip": text,
    }


def _loop(game: str, interval_sec: int, topic: str) -> None:
    global _runtime
    _runtime = {
        "running": True,
        "game": game,
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "tips_given": 0,
        "last_tip": None,
        "last_category": None,
    }
    disk = _load()
    last_cat = None
    # first tip soon (45s) so the user hears the coach is alive
    first_delay = 45
    try:
        deadline = time.time() + first_delay
        while not _stop_event.is_set():
            now = time.time()
            if now < deadline:
                time.sleep(0.4)
                continue
            cat = _pick_category(None, last_cat)
            tip = _one_tip(game, cat, topic)
            last_cat = cat
            with _lock:
                _runtime["last_tip"] = tip
                _runtime["last_category"] = cat
                _runtime["tips_given"] = int(_runtime.get("tips_given") or 0) + 1
            hist = disk.get("history") or []
            hist.append(tip)
            disk["history"] = hist[-40:]
            disk["default_game"] = game
            _save(disk)
            print(f"[GameCoach] ({cat}) {tip['tip']}")
            deadline = time.time() + interval_sec
    finally:
        with _lock:
            _runtime["running"] = False


def game_coach(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = (params.get("action") or "status").strip().lower()
    disk = _load()

    # ── status ────────────────────────────────────────────────────────────
    if action in ("status", "report"):
        with _lock:
            rt = dict(_runtime)
        last = rt.get("last_tip") or {}
        return done(
            "game_coach",
            action="status",
            running=bool(rt.get("running")),
            game=rt.get("game") or disk.get("default_game"),
            tips_given=rt.get("tips_given") or 0,
            last_category=rt.get("last_category"),
            last_tip=last.get("tip"),
            last_source=last.get("source"),
            started_at=rt.get("started_at"),
        )

    # ── tip now (one-shot) ────────────────────────────────────────────────
    if action in ("tip", "once", "now", "advice"):
        game = (params.get("game") or disk.get("default_game") or "Fortnite").strip()
        cat = (params.get("category") or "").strip().lower() or None
        if cat and cat not in _CATEGORIES:
            return ask(
                "game_coach",
                "which category?",
                options=", ".join(_CATEGORIES),
            )
        topic = (params.get("topic") or "").strip()
        chosen = _pick_category(cat, None)
        tip = _one_tip(game, chosen, topic)
        hist = disk.get("history") or []
        hist.append(tip)
        disk["history"] = hist[-40:]
        disk["default_game"] = game
        _save(disk)
        return done(
            "game_coach",
            action="tip",
            game=game,
            category=chosen,
            source=tip["source"],
            tip=tip["tip"],
        )

    # ── start session ─────────────────────────────────────────────────────
    if action in ("start", "session", "on", "coach"):
        global _worker
        if _runtime.get("running") and _worker and _worker.is_alive():
            return failed("game_coach", "session already running — stop first")

        game = (params.get("game") or disk.get("default_game") or "Fortnite").strip()[:60]
        topic = (params.get("topic") or "").strip()[:80]
        try:
            interval = int(params.get("interval_sec") or params.get("interval") or disk.get("interval_sec") or 12 * 60)
        except (TypeError, ValueError):
            interval = 12 * 60
        interval = max(120, min(interval, 30 * 60))

        disk["default_game"] = game
        disk["interval_sec"] = interval
        _save(disk)

        _stop_event.clear()
        _worker = threading.Thread(
            target=_loop,
            args=(game, interval, topic),
            name="jarvis-game-coach",
            daemon=True,
        )
        _worker.start()
        return started(
            "game_coach",
            game=game,
            interval_sec=interval,
            topic=topic or "(general)",
            note=(
                f"Coach session on for {game}. First tip in ~45s, then about every "
                f"{interval // 60} min (positioning, building, loot, rotation…). "
                "action=tip for an immediate tip; action=stop to end."
            ),
        )

    # ── stop ──────────────────────────────────────────────────────────────
    if action in ("stop", "off", "halt", "end"):
        was = bool(_runtime.get("running"))
        _stop_event.set()
        if _worker and _worker.is_alive():
            _worker.join(timeout=3.0)
        with _lock:
            _runtime["running"] = False
        return done(
            "game_coach",
            action="stop",
            was_running=was,
            tips_given=_runtime.get("tips_given") or 0,
        )

    # ── categories ────────────────────────────────────────────────────────
    if action in ("categories", "list"):
        return done(
            "game_coach",
            action="categories",
            categories=", ".join(_CATEGORIES),
        )

    return ask(
        "game_coach",
        "what should I do?",
        options="start (game=Fortnite), tip, stop, status, categories",
    )


_LEGACY_TOOL = {
    "name": "game_coach",
    "description": (
        "Voice/text coaching session while gaming: rotating tips on positioning, "
        "building, loot, rotation, survival, aim habits and mindset. "
        "Uses Gemini when configured for fresher advice; otherwise solid evergreen "
        "fundamentals. Does not look at the game screen or control the mouse. "
        "Actions: start (game=..., interval_sec=...), tip (one tip now), stop, status, categories. "
        "Use when the user wants a coach talking general strategy while they play."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "start | tip | stop | status | categories",
            },
            "game": {
                "type": "STRING",
                "description": "Game name (default Fortnite or last used)",
            },
            "category": {
                "type": "STRING",
                "description": "For tip: positioning|building|loot|rotation|survival|aim_habits|mindset",
            },
            "topic": {
                "type": "STRING",
                "description": "Optional focus, e.g. 'endgame' or 'solo ranked'",
            },
            "interval_sec": {
                "type": "NUMBER",
                "description": "Seconds between tips in a session (default 720 = 12 min)",
            },
        },
        "required": [],
    },
    "handler": game_coach,
    "tier": "core",
}
