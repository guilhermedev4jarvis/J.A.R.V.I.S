"""Alias legacy tool `game_player` → `game_assistant` (mode=player)."""
from __future__ import annotations

from actions.game_assistant import game_assistant as _impl


def game_player(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "player")
    params.setdefault("action", params.get("action") or "player")
    return _impl(params, **ctx)


TOOL = {
    "name": "game_player",
    "description": 'Alias → game_assistant mode=player',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": game_player,
    "tier": "core",
    "risk": "review",
}
