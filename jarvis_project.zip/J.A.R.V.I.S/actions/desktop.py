
"""Legacy module path — implementation unified in desktop_control.py."""
from __future__ import annotations
from actions.desktop_control import desktop_control  # noqa: F401
# No TOOL here: avoids name collision with actions/desktop_control.py
