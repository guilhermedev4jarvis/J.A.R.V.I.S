"""Alias legacy tool `powershell_assist` → `powershell_tool` (mode=explain)."""
from __future__ import annotations

from actions.powershell_tool import powershell_tool as _impl


def powershell_assist(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "explain")
    params.setdefault("action", params.get("action") or "explain")
    return _impl(params, **ctx)


TOOL = {
    "name": "powershell_assist",
    "description": 'Alias → powershell_tool mode=explain',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": powershell_assist,
    "tier": "core",
    "risk": "review",
}
