"""actions.smarthome — domain package."""
