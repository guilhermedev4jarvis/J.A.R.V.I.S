"""Alias legacy tool `monitor_tool` → `system_monitor` (mode=monitor_tool)."""
from __future__ import annotations

from actions.system_monitor import system_monitor as _impl


def monitor_tool(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "monitor_tool")
    params.setdefault("action", params.get("action") or "monitor_tool")
    return _impl(params, **ctx)


TOOL = {
    "name": "monitor_tool",
    "description": 'Alias → system_monitor mode=monitor_tool',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": monitor_tool,
    "tier": "core",
    "risk": "safe",
}
