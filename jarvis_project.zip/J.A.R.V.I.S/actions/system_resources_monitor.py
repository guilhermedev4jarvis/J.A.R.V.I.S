"""Alias legacy tool `system_resources_monitor` → `system_monitor` (mode=resources)."""
from __future__ import annotations

from actions.system_monitor import system_monitor as _impl


def system_resources_monitor(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "resources")
    params.setdefault("action", params.get("action") or "resources")
    return _impl(params, **ctx)


TOOL = {
    "name": "system_resources_monitor",
    "description": 'Alias → system_monitor mode=resources',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": system_resources_monitor,
    "tier": "core",
    "risk": "safe",
}
