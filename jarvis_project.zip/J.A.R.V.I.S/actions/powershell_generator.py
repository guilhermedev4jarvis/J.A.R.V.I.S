"""Alias legacy tool `powershell_generator` → `powershell_tool` (mode=generate)."""
from __future__ import annotations

from actions.powershell_tool import powershell_tool as _impl


def powershell_generator(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "generate")
    params.setdefault("action", params.get("action") or "generate")
    return _impl(params, **ctx)


TOOL = {
    "name": "powershell_generator",
    "description": 'Alias → powershell_tool mode=generate',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": powershell_generator,
    "tier": "core",
    "risk": "review",
}
