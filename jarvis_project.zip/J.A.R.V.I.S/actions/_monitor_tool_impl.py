"""
monitor_tool — topics monitoring (migrated from plugins/).
"""
from __future__ import annotations

from core.outcome import done, failed, ask

_TOPICS: list[str] = []


def monitor_tool(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "list").strip().lower()
    topic = str(params.get("topic") or "").strip()

    if action in ("list", "status"):
        return done("monitor_tool", action="list", topics=list(_TOPICS), count=len(_TOPICS))
    if action == "add":
        if not topic:
            return ask("monitor_tool", "topic?")
        if topic not in _TOPICS:
            _TOPICS.append(topic)
        return done("monitor_tool", action="add", topic=topic, topics=list(_TOPICS))
    if action == "remove":
        if topic in _TOPICS:
            _TOPICS.remove(topic)
        return done("monitor_tool", action="remove", topic=topic, topics=list(_TOPICS))
    return ask("monitor_tool", "action?", hint="add|remove|list")


_LEGACY_TOOL = {
    "name": "monitor_tool",
    "description": "Monitora topicos definidos pelo usuario (add|remove|list).",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "add|remove|list"},
            "topic": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": monitor_tool,
    "tier": "plugin",
    "risk": "safe",
}
