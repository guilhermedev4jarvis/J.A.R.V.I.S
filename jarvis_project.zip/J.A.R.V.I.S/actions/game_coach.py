"""Alias legacy tool `game_coach` → `game_assistant` (mode=coach)."""
from __future__ import annotations

from actions.game_assistant import game_assistant as _impl


def game_coach(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "coach")
    params.setdefault("action", params.get("action") or "coach")
    return _impl(params, **ctx)


TOOL = {
    "name": "game_coach",
    "description": 'Alias → game_assistant mode=coach',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": game_coach,
    "tier": "core",
    "risk": "review",
}
