"""Alias legacy tool `game_updater` → `game_assistant` (mode=update)."""
from __future__ import annotations

from actions.game_assistant import game_assistant as _impl


def game_updater(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "update")
    params.setdefault("action", params.get("action") or "update")
    return _impl(params, **ctx)


TOOL = {
    "name": "game_updater",
    "description": 'Alias → game_assistant mode=update',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": game_updater,
    "tier": "core",
    "risk": "review",
}
