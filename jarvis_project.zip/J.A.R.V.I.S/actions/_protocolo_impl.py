"""protocolo — 190 (multi-canal silencioso + iCSee) e demo.

190: sem owner_gate/confirm/PIN/TTS/ligação telefônica.
Canais de socorro: WhatsApp + Telegram Bot + webhook_bridge (em paralelo).
Cada etapa isolada com try/except e timeout curto (~5s) para operação 24/7.
"""
from __future__ import annotations

import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from core.outcome import ask, done, failed

_BASE = Path(__file__).resolve().parents[1]
_EVID = _BASE / "memory" / "audit" / "evidencias"

_DEFAULT_CONTACT_PHONE = "5517999999999"
_DEFAULT_HOME_ADDRESS = (
    "Rua São Luiz, nº 244, Jardim Europa, São José do Rio Preto - SP"
)
_DEFAULT_ICSEE_WEB = "https://xmeye.net"
_DEFAULT_CAMERA_LOAD_SEC = 4.0
_STEP_TIMEOUT = 5.0
_SUPPORTED = frozenset({"190", "demo"})


def _env(name: str, default: str = "") -> str:
    return (os.getenv(name) or default or "").strip()


def _redact(text: str) -> str:
    """Mask RTSP credentials, tokens and long digit runs in logs."""
    try:
        from core.redaction import redact_text
        text = redact_text(text or "")
    except Exception:
        pass
    s = text or ""
    s = re.sub(r"(rtsp://)([^:@/]+):([^@/]+)@", r"\1***:***@", s, flags=re.I)
    s = re.sub(r"(token=)([^\s&]+)", r"\1***", s, flags=re.I)
    s = re.sub(r"(bot)\d+:[A-Za-z0-9_-]+", r"\1***:***", s, flags=re.I)
    s = re.sub(r"\b(\d{10,15})\b", lambda m: m.group(1)[:4] + "****" + m.group(1)[-2:], s)
    return s


def _audit(kind: str, extra: Optional[dict] = None) -> None:
    try:
        from core import audit
        safe = {}
        for k, v in (extra or {}).items():
            if isinstance(v, str):
                safe[k] = _redact(v)
            else:
                safe[k] = v
        audit.log_event(kind, tool="protocolo", extra=safe)
    except Exception as e:
        print(f"[protocolo] audit: {_redact(str(e))}")


def _run_step(name: str, fn: Callable[[], dict], timeout: float = _STEP_TIMEOUT) -> dict:
    """Isolate failures; never raise to the main loop."""
    out: dict[str, Any] = {"id": name, "ok": False}
    try:
        with ThreadPoolExecutor(max_workers=1) as pool:
            fut = pool.submit(fn)
            try:
                result = fut.result(timeout=timeout)
            except FuturesTimeout:
                return {"id": name, "ok": False, "reason": f"timeout_{timeout}s"}
        if isinstance(result, dict):
            out.update(result)
            out["id"] = name
        else:
            out["ok"] = True
            out["result"] = str(result)[:200]
    except Exception as e:
        out["ok"] = False
        out["reason"] = _redact(str(e))[:240]
    return out


def _speak(text: str, player=None, *, silent: bool = False) -> None:
    if silent or not (text or "").strip():
        return
    text = text.strip()
    if player:
        for attr in ("plugin_say", "say", "request_say"):
            fn = getattr(player, attr, None)
            if callable(fn):
                try:
                    fn(text)
                    return
                except Exception:
                    pass
    try:
        from core import tts as tts_mod
        speak = getattr(tts_mod, "speak", None)
        if callable(speak):
            speak(text)
    except Exception as e:
        print(f"[protocolo] tts: {e}")


def _normalize_name(name: str) -> str:
    n = (name or "").strip().lower()
    n = n.replace("protocolo", "").strip()
    n = re.sub(r"\s+", "", n)
    aliases = {
        "190": "190",
        "emergencia": "190",
        "emergência": "190",
        "emergencia190": "190",
        "policia": "190",
        "polícia": "190",
        "demo": "demo",
        "demonstracao": "demo",
        "demonstração": "demo",
    }
    return aliases.get(n, n)


def _ts() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _evid_dir() -> Path:
    _EVID.mkdir(parents=True, exist_ok=True)
    return _EVID


def _load_delay() -> float:
    try:
        return max(0.0, float(_env("CAMERA_LOAD_DELAY_SEC", str(_DEFAULT_CAMERA_LOAD_SEC))))
    except Exception:
        return _DEFAULT_CAMERA_LOAD_SEC


def _home_address() -> str:
    return _env("HOME_ADDRESS") or _env("ENDERECO_RESIDENCIA") or _DEFAULT_HOME_ADDRESS


def _open_icsee(player=None) -> dict:
    path = _env("ICSEE_APP_PATH") or _env("CAMERA_APP_PATH")
    name = _env("ICSEE_APP_NAME") or _env("CAMERA_APP_NAME") or "iCSee"
    web = _env("ICSEE_WEB_URL") or _env("CAMERA_APP_URL") or _DEFAULT_ICSEE_WEB
    candidates = []
    if path:
        candidates.append(path)
    candidates.extend([name, "iCSee", "iCSee.exe"])
    last = ""
    for app in candidates:
        app = (app or "").strip()
        if not app:
            continue
        try:
            from actions.open_app import open_app
            r = open_app(parameters={"app_name": app}, player=player)
            last = str(r)[:200]
            if "status=failed" not in last:
                try:
                    from actions.window_manager import window_manager
                    title = Path(app).stem if ("\\" in app or "/" in app) else app.replace(".exe", "")
                    window_manager(parameters={"action": "focus", "title": title}, player=player)
                except Exception:
                    pass
                return {"ok": True, "mode": "desktop", "app": app, "result": last}
        except Exception as e:
            last = str(e)[:200]
    try:
        from actions.browser_control import browser_control
        r = browser_control(parameters={"action": "open", "url": web}, player=player)
        return {"ok": "status=failed" not in str(r), "mode": "web", "url": _redact(web), "result": str(r)[:200]}
    except Exception:
        try:
            import webbrowser
            webbrowser.open(web)
            return {"ok": True, "mode": "web_webbrowser", "url": _redact(web)}
        except Exception as e2:
            return {"ok": False, "reason": _redact(f"{last};{e2}")}


def _capture_rtsp_frame() -> dict:
    url = _env("ICSEE_RTSP_URL") or _env("CAM_RTSP_1")
    if not url:
        return {"ok": False, "skipped": True, "reason": "no_rtsp"}
    try:
        import cv2  # type: ignore
        cap = cv2.VideoCapture(url)
        try:
            if not cap.isOpened():
                return {"ok": False, "reason": "rtsp_open_failed"}
            frame = None
            t0 = time.time()
            while time.time() - t0 < min(5.0, _STEP_TIMEOUT):
                ok, fr = cap.read()
                if ok and fr is not None:
                    frame = fr
                    break
                time.sleep(0.05)
            if frame is None:
                return {"ok": False, "reason": "rtsp_no_frame"}
            path = _evid_dir() / f"{_ts()}_icsee_rtsp.jpg"
            cv2.imwrite(str(path), frame)
            ok2, buf = cv2.imencode(".png", frame)
            png = buf.tobytes() if ok2 else path.read_bytes()
            return {"ok": True, "source": "rtsp", "file": str(path.relative_to(_BASE)), "path": str(path), "png": png}
        finally:
            cap.release()
    except Exception as e:
        return {"ok": False, "reason": _redact(str(e))[:200]}


def _capture_screen() -> dict:
    path = _evid_dir() / f"{_ts()}_icsee_screen.png"
    png = None
    try:
        from actions.screenshot_ocr import _capture_png  # type: ignore
        png = _capture_png()
    except Exception:
        try:
            import mss, mss.tools
            with mss.mss() as sct:
                shot = sct.grab(sct.monitors[1])
                png = mss.tools.to_png(shot.rgb, shot.size)
        except Exception:
            try:
                from PIL import ImageGrab
                import io
                img = ImageGrab.grab()
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                png = buf.getvalue()
            except Exception as e:
                return {"ok": False, "reason": f"capture_failed:{e}"}
    if not png:
        return {"ok": False, "reason": "empty_capture"}
    path.write_bytes(png)
    return {"ok": True, "source": "screen", "file": str(path.relative_to(_BASE)), "path": str(path), "png": png}


def _connect_icsee_and_capture(player=None) -> dict:
    opened = _open_icsee(player=player)
    time.sleep(_load_delay())
    rtsp = _capture_rtsp_frame()
    screen = _capture_screen()
    primary = screen if screen.get("ok") else rtsp
    out: dict[str, Any] = {
        "ok": bool(primary.get("ok")),
        "icsee_open": opened,
        "rtsp": {k: v for k, v in rtsp.items() if k != "png"},
        "screen": {k: v for k, v in screen.items() if k != "png"},
    }
    if primary.get("ok"):
        out["path"] = primary.get("path")
        out["file"] = primary.get("file")
        out["png"] = primary.get("png")
        out["source"] = primary.get("source")
    else:
        out["reason"] = primary.get("reason") or "no_image"
    return out


def _analyze_vision(png: bytes, player=None) -> str:
    prompt = (
        "Analise esta imagem das câmeras (iCSee). Em português, máx. 3 frases: "
        "pessoas, roupas, objetos perigosos, movimento, área. Se só UI do app, diga."
    )
    try:
        from core import gemini as gem
        from google.genai import types as gtypes
        key = gem.api_key() if hasattr(gem, "api_key") else ""
        if key:
            part = gtypes.Part.from_bytes(data=png, mime_type="image/png")
            reply = gem.text([prompt, part], timeout_ms=int(_STEP_TIMEOUT * 1000), key=key)
            if reply:
                return reply.strip()[:800]
    except Exception as e:
        print(f"[protocolo] vision: {_redact(str(e))}")
    try:
        from core.llm_client import call_llm_text
        reply = call_llm_text(prompt + f"\n(PNG {len(png)} bytes)", system="Descrição objetiva.", timeout=int(_STEP_TIMEOUT))
        if reply:
            return reply.strip()[:800]
    except Exception:
        pass
    return "Análise visual indisponível no momento."


def _sos_text(vision: str) -> str:
    addr = _home_address()
    vis = (vision or "sem descrição visual disponível").strip()[:500]
    return (
        "🚨 EMERGÊNCIA! PEDIDO DE SOCORRO! Por favor, ligue imediatamente para a "
        "polícia (190) e peça ajuda urgente no endereço: "
        f"{addr}. Situação detectada nas câmeras da casa (iCSee): {vis}"
    )


def _send_whatsapp(msg: str, image_path: Optional[str], player=None) -> dict:
    phone = re.sub(r"[^\d]", "", _env("EMERGENCY_CONTACT_PHONE", _DEFAULT_CONTACT_PHONE))
    name = _env("EMERGENCY_CONTACT_NAME") or _env("EMERGENCY_CONTACT") or ""
    contact = name or phone
    params: dict[str, Any] = {"message": msg, "contact": contact}
    if phone:
        params["phone"] = phone
    if image_path:
        params["image"] = image_path
        params["file"] = image_path
        params["attachment"] = image_path
    try:
        from actions.whatsapp_web import whatsapp_web
        r = whatsapp_web(parameters=params, player=player)
        return {"ok": "status=failed" not in str(r), "channel": "whatsapp_web", "result": _redact(str(r)[:240])}
    except Exception as e:
        try:
            from actions.send_message import send_message
            sp = {"channel": "whatsapp", "to": contact, "message": msg}
            if image_path:
                sp["file"] = image_path
            r = send_message(parameters=sp, player=player)
            return {"ok": "status=failed" not in str(r), "channel": "send_message", "result": _redact(str(r)[:240])}
        except Exception as e2:
            return {"ok": False, "channel": "whatsapp", "reason": _redact(f"{e};{e2}")[:200]}


def _send_telegram(msg: str, image_path: Optional[str]) -> dict:
    token = _env("TELEGRAM_BOT_TOKEN")
    chat = _env("TELEGRAM_CHAT_ID")
    if not token or not chat:
        return {"ok": False, "channel": "telegram", "skipped": True, "reason": "TELEGRAM_BOT_TOKEN/CHAT_ID unset"}
    try:
        import requests
    except Exception as e:
        return {"ok": False, "channel": "telegram", "reason": f"requests_missing:{e}"}
    base = f"https://api.telegram.org/bot{token}"
    try:
        if image_path and Path(image_path).is_file():
            with open(image_path, "rb") as fh:
                r = requests.post(
                    f"{base}/sendPhoto",
                    data={"chat_id": chat, "caption": msg[:1024]},
                    files={"photo": fh},
                    timeout=_STEP_TIMEOUT,
                )
        else:
            r = requests.post(
                f"{base}/sendMessage",
                json={"chat_id": chat, "text": msg[:4000]},
                timeout=_STEP_TIMEOUT,
            )
        ok = r.status_code == 200
        return {"ok": ok, "channel": "telegram", "status_code": r.status_code, "body": _redact(r.text[:180])}
    except Exception as e:
        return {"ok": False, "channel": "telegram", "reason": _redact(str(e))[:200]}


def _send_webhook(msg: str, image_path: Optional[str], player=None) -> dict:
    name = _env("EMERGENCY_WEBHOOK_NAME") or "emergencia"
    if not _env("EMERGENCY_WEBHOOK_NAME") and not _env("WEBHOOK_EMERGENCIA"):
        # optional — only if configured in webhooks.json via bridge
        pass
    try:
        from actions.webhook_bridge import webhook_bridge
        r = webhook_bridge(
            parameters={
                "action": "trigger",
                "name": name,
                "payload": {"text": msg, "image": image_path or "", "protocol": "190"},
            },
            player=player,
        )
        return {"ok": "status=failed" not in str(r), "channel": "webhook_bridge", "result": _redact(str(r)[:200])}
    except Exception as e:
        return {"ok": False, "channel": "webhook", "skipped": True, "reason": _redact(str(e))[:160]}


def _dispatch_alerts_parallel(msg: str, image_path: Optional[str], player=None) -> dict:
    """WhatsApp + Telegram + webhook ao mesmo tempo."""
    results = {}

    def wa():
        results["whatsapp"] = _send_whatsapp(msg, image_path, player=player)

    def tg():
        results["telegram"] = _send_telegram(msg, image_path)

    def wh():
        results["webhook"] = _send_webhook(msg, image_path, player=player)

    threads = [threading.Thread(target=t, daemon=True) for t in (wa, tg, wh)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=_STEP_TIMEOUT + 2)
    any_ok = any(isinstance(v, dict) and v.get("ok") for v in results.values())
    return {"ok": any_ok, "channels": results}


def _run_190(player=None) -> list[dict]:
    steps: list[dict] = []

    def step_capture():
        return _connect_icsee_and_capture(player=player)

    cap = _run_step("icsee_capturar", step_capture, timeout=max(_STEP_TIMEOUT, _load_delay() + 6))
    vision = ""
    image_path = None
    png = None
    # re-fetch png if nested — step may have stripped; run capture body result
    if cap.get("ok"):
        image_path = cap.get("path")
        # vision needs png — capture again lightweight from file if needed
        try:
            if image_path and Path(image_path).is_file():
                png = Path(image_path).read_bytes()
        except Exception:
            pass
    steps.append({k: v for k, v in cap.items() if k != "png"})

    def step_vision():
        nonlocal vision
        if not png:
            return {"ok": False, "reason": "no_png"}
        vision = _analyze_vision(png, player=player)
        return {"ok": bool(vision), "vision": vision}

    vstep = _run_step("analise_visao", step_vision, timeout=_STEP_TIMEOUT + 3)
    steps.append(vstep)
    if vstep.get("vision"):
        vision = vstep["vision"]

    msg = _sos_text(vision)

    def step_alert():
        return _dispatch_alerts_parallel(msg, image_path, player=player)

    alert = _run_step("enviar_socorro_multicanal", step_alert, timeout=_STEP_TIMEOUT + 5)
    alert["message_preview"] = _redact(msg[:180])
    steps.append(alert)
    return steps


def _run_demo(player=None) -> list[dict]:
    steps = []
    intro = (
        "Iniciando protocolo demo. Sou o J.A.R.V.I.S. Vou abrir o iCSee e narrar "
        "as câmeras — sem enviar emergência."
    )
    _speak(intro, player=player, silent=False)
    steps.append({"id": "anunciar_demo", "ok": True, "texto": intro[:160]})

    def diag():
        parts = []
        try:
            from actions.system_health import system_health
            parts.append({"system_health": str(system_health(parameters={"action": "status"}))[:200]})
        except Exception as e:
            parts.append({"system_health_error": str(e)[:80]})
        try:
            from actions.network_status import network_status
            parts.append({"network_status": str(network_status(parameters={"action": "status"}))[:200]})
        except Exception as e:
            parts.append({"network_error": str(e)[:80]})
        return {"ok": True, "parts": parts}

    steps.append(_run_step("diagnostico_sistema", diag))
    _speak("Diagnóstico concluído.", player=player)

    cap = _run_step(
        "demo_icsee",
        lambda: _connect_icsee_and_capture(player=player),
        timeout=max(_STEP_TIMEOUT, _load_delay() + 6),
    )
    vision = ""
    if cap.get("path") and Path(str(cap["path"])).is_file():
        try:
            png = Path(str(cap["path"])).read_bytes()
            vision = _analyze_vision(png, player=player)
            cap["vision"] = vision
        except Exception:
            pass
    steps.append({k: v for k, v in cap.items() if k != "png"})
    if vision:
        _speak(f"No iCSee estou vendo: {vision}", player=player)
    else:
        _speak("Sem descrição visual clara do iCSee.", player=player)

    closing = "Protocolo demo finalizado. Nenhum alerta de emergência foi enviado."
    _speak(closing, player=player)
    steps.append({"id": "resumo_tatico", "ok": True, "texto": closing})
    return steps


def run(parameters: Optional[dict] = None, player=None, session_memory=None, **_ctx) -> str:
    p = dict(parameters or {})
    action = str(p.get("action") or p.get("op") or "ativar").strip().lower()

    if action in ("list", "listar"):
        return done(
            "protocolo",
            op="list",
            count=2,
            protocolos=[
                {"nome": "190", "descricao": "Socorro multi-canal (WhatsApp+Telegram+webhook) via iCSee", "critico": True},
                {"nome": "demo", "descricao": "Demo falada iCSee sem emergência", "critico": False},
            ],
        )

    name_raw = str(p.get("nome") or p.get("protocolo") or p.get("name") or "").strip()
    if action in ("get", "info", "status"):
        if not name_raw:
            return ask("protocolo", "Qual protocolo: 190 ou demo?")
        key = _normalize_name(name_raw)
        if key not in _SUPPORTED:
            return failed("protocolo", f"desconhecido: {name_raw}", disponiveis=list(_SUPPORTED))
        return done("protocolo", op="get", nome=key)

    if not name_raw:
        return ask("protocolo", "Qual protocolo ativar: 190 ou demo?")
    key = _normalize_name(name_raw)
    if key not in _SUPPORTED:
        return failed("protocolo", "apenas 190 e demo são suportados")

    _audit("protocolo_start", {"protocolo": key, "auth": "none_by_design"})

    try:
        if key == "190":
            print("[protocolo] 190 multi-canal silencioso — iCSee + WA/TG/webhook")
            steps = _run_190(player=player)
        else:
            steps = _run_demo(player=player)
    except Exception as e:
        _audit("protocolo_crash", {"protocolo": key, "error": _redact(str(e))})
        return failed("protocolo", f"falha isolada: {_redact(str(e))[:200]}")

    ok_n = sum(1 for s in steps if s.get("ok"))
    _audit("protocolo_done", {"protocolo": key, "ok_steps": ok_n, "total": len(steps)})
    return done(
        "protocolo",
        op="ativar",
        nome=key,
        steps_ok=ok_n,
        steps_total=len(steps),
        steps=steps,
        note="190: multi-canal, sem PIN/ligação/wake-word",
    )
