"""Unified game assistant (assist/coach/helper/player/update)."""
from __future__ import annotations

from core.outcome import done, failed, ask


def _dispatch(impl: str, names: list[str], params: dict, **ctx) -> str:
    import importlib
    mod = importlib.import_module(f"actions.{impl}")
    for fn in names:
        h = getattr(mod, fn, None)
        if callable(h):
            try:
                return h(params, **ctx)
            except TypeError:
                try:
                    return h(parameters=params)
                except TypeError:
                    return h(params)
    return failed("game_assistant", f"missing handler {impl}")


def game_assistant(parameters=None, **ctx) -> str:
    params = dict(parameters or {})
    mode = str(params.get("mode") or params.get("action") or "assist").strip().lower()
    if mode in ("assist", "game_assist", "help") and mode != "help":
        return _dispatch("_game_assist_impl", ["game_assist", "run"], params, **ctx)
    if mode == "help":
        return done("game_assistant", modes=["assist", "coach", "helper", "player", "update"])
    if mode in ("coach", "game_coach"):
        return _dispatch("_game_coach_impl", ["game_coach", "run"], params, **ctx)
    if mode in ("helper", "game_helper"):
        return _dispatch("_game_helper_impl", ["game_helper", "run"], params, **ctx)
    if mode in ("player", "game_player", "play"):
        return _dispatch("_game_player_impl", ["game_player", "run"], params, **ctx)
    if mode in ("update", "updater", "game_updater"):
        return _dispatch("_game_updater_impl", ["game_updater", "run"], params, **ctx)
    return ask("game_assistant", "mode?", hint="assist|coach|helper|player|update")


TOOL = {
    "name": "game_assistant",
    "description": "Assistente de jogos unificado: mode=assist|coach|helper|player|update.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "game": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": game_assistant,
    "tier": "core",
    "risk": "review",
}
