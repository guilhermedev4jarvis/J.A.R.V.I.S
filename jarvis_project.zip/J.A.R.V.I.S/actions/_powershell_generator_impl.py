"""
powershell_generator — natural language → PowerShell script → safe execute.

Flow:
  1. Intent in natural language
  2. LLM (core.llm_client.call_llm_text, Gemini fallback) produces pure .ps1
  3. Static scan for destructive / elevation patterns
  4. Dangerous scripts go through core.confirm.request (HUD gate)
  5. Script saved under cache/ps_scripts/
  6. Executed with powershell -NoProfile -File (stdout/stderr captured)
  7. On failure, optional one-shot auto-heal (regenerate + re-run once)

Windows-first. On non-Windows returns a clear failed outcome (no fake success).
Complements powershell_cmd (short allowlisted commands) with multi-step scripts.
"""
from __future__ import annotations

import json
import platform
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from core.outcome import done, failed, ask, unverified, started

_OS = platform.system()
_BASE = Path(__file__).resolve().parent.parent
_CACHE_DIR = _BASE / "cache" / "ps_scripts"
_HISTORY_PATH = _BASE / "config" / "powershell_generator_history.json"

# ── Dangerous patterns (case-insensitive). Match → require confirm gate. ──
_DANGEROUS = (
    r"remove-item\s+[^\n]*-(recurse|force)",
    r"remove-item\s+[^\n]*-(force|recurse)",
    r"rm\s+-rf\b",
    r"format-volume\b",
    r"clear-disk\b",
    r"initialize-disk\b",
    r"stop-computer\b",
    r"restart-computer\b",
    r"shutdown(\.exe)?\b",
    r"stop-process\s+[^\n]*-force",
    r"stop-process\s+\*|get-process\s+\|\s*stop-process",
    r"disable-computerrestore\b",
    r"set-executionpolicy\b",
    r"set-mppreference\b",
    r"new-netfirewallrule\b",
    r"disable-netadapter\b",
    r"clear-eventlog\b",
    r"cipher\s+/w",
    r"takeown\b",
    r"icacls\s+[^\n]*/grant",
    r"reg\s+(delete|add)\b",
    r"remove-computer\b",
    r"reset-computermachinepassword\b",
    r"diskpart\b",
    r"mount-diskimage\b.*-storage",
)

# Always refuse — never offer confirm (too destructive / systemic)
_HARD_BLOCK = (
    r"format\s+[a-z]:",
    r"format-volume\b",
    r"clear-disk\b",
    r":\(\)\s*\{\s*:\|:&\s*\};:",
    r"remove-item\s+[^\n]*(\\windows|\\system32|/etc|/usr|/boot)",
    r"rd\s+/s\s+/q\s+[a-z]:\\windows",
)

# Heuristics that the script likely needs elevation
_ELEVATION_HINTS = (
    r"start-process\s+[^\n]*-verb\s*runas",
    r"-verb\s*runas",
    r"set-executionpolicy\b",
    r"new-netfirewallrule\b",
    r"set-service\b",
    r"restart-service\b",
    r"install-windowsfeature\b",
    r"enable-windowsoptionalfeature\b",
    r"set-netfirewallprofile\b",
    r"get-bitlockervolume\b",
    r"manage-bde\b",
    r"schtasks\s+/create",
    r"new-service\b",
    r"set-itemproperty\s+[^\n]*HKLM:",
    r"new-itemproperty\s+[^\n]*HKLM:",
)

_SYSTEM_PROMPT = """You are a PowerShell 5.1 / 7 script generator for Windows.
Output ONLY the raw PowerShell script body. Rules:
- No markdown fences, no explanations, no comments that narrate the request.
- Prefer PowerShell cmdlets over external exe when equivalent.
- Wrap risky I/O in try/catch; on error Write-Error and exit non-zero.
- Use -ErrorAction Stop inside try blocks where appropriate.
- Prefer $ErrorActionPreference = 'Stop' at the top for scripts that must fail loud.
- Do not use Format-Volume, Clear-Disk, shutdown, or wipe of Windows/System32.
- Do not change Set-ExecutionPolicy unless the user explicitly asked for policy change.
- Paths with spaces must be quoted.
- End with exit 0 on success.
- Keep scripts reasonably short and efficient (no unnecessary loops or sleeps).
"""


def _cache_dir() -> Path:
    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return _CACHE_DIR


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _append_history(entry: dict) -> None:
    try:
        hist: list = []
        if _HISTORY_PATH.exists():
            hist = json.loads(_HISTORY_PATH.read_text(encoding="utf-8"))
            if not isinstance(hist, list):
                hist = []
        hist.append(entry)
        _HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
        _HISTORY_PATH.write_text(
            json.dumps(hist[-40:], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except Exception:
        pass


def _strip_markdown(text: str) -> str:
    """Remove ```powershell fences and leading prose if the model ignored instructions."""
    t = (text or "").strip()
    if not t:
        return ""
    # Fenced block
    m = re.search(r"```(?:powershell|ps1|pwsh)?\s*([\s\S]*?)```", t, re.I)
    if m:
        return m.group(1).strip()
    # Drop leading non-code lines until something cmdlet-like appears
    lines = t.splitlines()
    start = 0
    for i, line in enumerate(lines):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if re.match(
            r"^(\$|function\s|param\s*\(|try\s*\{|if\s*\(|foreach\s*\(|"
            r"get-|set-|new-|remove-|write-|copy-|move-|test-|out-|"
            r"import-|export-|start-|stop-|invoke-|add-|clear-|select-)",
            s,
            re.I,
        ):
            start = i
            break
    return "\n".join(lines[start:]).strip()


def _scan_hard_block(script: str) -> Optional[str]:
    low = script.lower()
    for pat in _HARD_BLOCK:
        if re.search(pat, low, re.I):
            return f"hard-blocked pattern: {pat}"
    return None


def _scan_dangerous(script: str) -> list[str]:
    low = script.lower()
    hits = []
    for pat in _DANGEROUS:
        if re.search(pat, low, re.I):
            hits.append(pat)
    return hits


def _needs_elevation(script: str) -> bool:
    low = script.lower()
    return any(re.search(p, low, re.I) for p in _ELEVATION_HINTS)


def _is_admin() -> bool:
    if _OS != "Windows":
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _generate_script(intent: str, repair_context: str | None = None) -> str:
    """LLM generation with local client first, Gemini fallback."""
    user = intent.strip()
    if repair_context:
        user = (
            f"Previous script failed. Fix it.\n\n"
            f"Original intent:\n{intent}\n\n"
            f"Error / previous script:\n{repair_context}\n\n"
            f"Return ONLY the corrected PowerShell script."
        )

    # 1) core.llm_client
    try:
        from core.llm_client import call_llm_text
        text = call_llm_text(
            prompt=user,
            system=_SYSTEM_PROMPT,
            timeout=90,
        )
        cleaned = _strip_markdown(text)
        if cleaned and len(cleaned) > 8:
            return cleaned
    except Exception as e:
        llm_err = str(e)[:200]
    else:
        llm_err = "empty response"

    # 2) Gemini fallback (same keys the rest of JARVIS uses)
    try:
        key_path = _BASE / "config" / "api_keys.json"
        key = ""
        if key_path.exists():
            key = json.loads(key_path.read_text(encoding="utf-8")).get("gemini_api_key") or ""
        if key:
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=key)
            resp = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=f"{_SYSTEM_PROMPT}\n\nUser request:\n{user}",
                config=types.GenerateContentConfig(
                    temperature=0.2,
                    max_output_tokens=2048,
                ),
            )
            cleaned = _strip_markdown(getattr(resp, "text", None) or "")
            if cleaned and len(cleaned) > 8:
                return cleaned
    except Exception as e:
        gem_err = str(e)[:200]
    else:
        gem_err = "empty or no key"

    raise RuntimeError(
        f"script generation failed (llm: {llm_err}; gemini: {gem_err})"
    )


def _save_script(script: str, label: str = "script") -> Path:
    path = _cache_dir() / f"{label}_{_stamp()}.ps1"
    # UTF-8 with BOM helps Windows PowerShell 5.1 parse non-ASCII
    path.write_text(script, encoding="utf-8-sig")
    return path


def _run_ps_file(
    path: Path,
    timeout: float,
    elevated: bool = False,
) -> tuple[int, str, str]:
    """
    Execute a .ps1 file. When elevated=True on Windows, relaunches with RunAs
    (user will see UAC). Output capture is limited after elevation.
    """
    if _OS != "Windows":
        return 1, "", "powershell_generator only runs on Windows"

    if elevated and not _is_admin():
        # Launch elevated; cannot reliably capture stdout after UAC.
        # -Wait keeps us blocked until the elevated process exits.
        inner = (
            f"Start-Process -FilePath 'powershell.exe' "
            f"-ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','{path}') "
            f"-Verb RunAs -Wait"
        )
        cmd = [
            "powershell",
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy", "Bypass",
            "-Command",
            inner,
        ]
        try:
            r = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout + 30,
                creationflags=0x08000000,  # CREATE_NO_WINDOW
                encoding="utf-8",
                errors="replace",
            )
            # Elevated child output is not inherited; return code is best-effort.
            return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
        except subprocess.TimeoutExpired:
            return 124, "", f"timeout after {timeout}s (elevated)"
        except Exception as e:
            return 1, "", str(e)

    cmd = [
        "powershell",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy", "Bypass",
        "-File",
        str(path),
    ]
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=0x08000000,
            encoding="utf-8",
            errors="replace",
        )
        return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s"
    except Exception as e:
        return 1, "", str(e)


def _truncate(s: str, n: int) -> str:
    s = s or ""
    if len(s) <= n:
        return s
    return s[:n] + f"\n… [truncated, {len(s)} chars total]"


def _execute_path(
    path: Path,
    timeout: float,
    elevated: bool,
    intent: str,
) -> str:
    code, out, err = _run_ps_file(path, timeout, elevated=elevated)
    out_t = _truncate(out, 4000)
    err_t = _truncate(err, 1500)

    _append_history({
        "at": datetime.now().isoformat(timespec="seconds"),
        "intent": intent[:300],
        "script": str(path.name),
        "exit_code": code,
        "elevated": elevated,
    })

    if code == 0:
        return done(
            "powershell_generator",
            phase="executed",
            exit_code=0,
            script=str(path),
            output=out_t or "(no output)",
            elevated=elevated,
        )
    if code == 124:
        return failed(
            "powershell_generator",
            f"timeout after {timeout}s",
            script=str(path),
            elevated=elevated,
        )
    return failed(
        "powershell_generator",
        err_t or f"exit code {code}",
        exit_code=code,
        output=out_t or "",
        script=str(path),
        elevated=elevated,
        note="Call again with action=heal and the same intent to attempt auto-fix.",
    )


def powershell_generator(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = (params.get("action") or "run").strip().lower()
    intent = (params.get("intent") or params.get("request") or params.get("prompt") or "").strip()
    script_in = (params.get("script") or "").strip()
    force = str(params.get("force") or params.get("confirmed") or "").lower() in (
        "1", "true", "yes", "y",
    )
    try:
        timeout = float(params.get("timeout") or 120)
    except (TypeError, ValueError):
        timeout = 120.0
    timeout = max(15.0, min(timeout, 600.0))
    auto_heal = str(params.get("auto_heal") or "true").lower() not in ("0", "false", "no")
    want_elevate = str(params.get("elevate") or "").lower() in ("1", "true", "yes", "y")

    # ── status / history ──────────────────────────────────────────────────
    if action in ("status", "history"):
        hist = []
        try:
            if _HISTORY_PATH.exists():
                hist = json.loads(_HISTORY_PATH.read_text(encoding="utf-8"))[-8:]
        except Exception:
            hist = []
        summary = "; ".join(
            f"{h.get('at','?')[:16]} exit={h.get('exit_code')} {h.get('script','')}"
            for h in hist
        ) or "(empty)"
        return done(
            "powershell_generator",
            action="status",
            cache=str(_CACHE_DIR),
            recent=summary,
            is_admin=_is_admin() if _OS == "Windows" else False,
            platform=_OS,
        )

    # ── preview only (generate, do not run) ───────────────────────────────
    if action in ("generate", "preview", "draft"):
        if not intent and not script_in:
            return failed("powershell_generator", "intent is required for generate")
        try:
            script = script_in or _generate_script(intent)
        except Exception as e:
            return failed("powershell_generator", f"generation failed: {e}")
        hard = _scan_hard_block(script)
        if hard:
            return failed("powershell_generator", hard, phase="generate")
        danger = _scan_dangerous(script)
        elev = _needs_elevation(script) or want_elevate
        path = _save_script(script, label="preview")
        return done(
            "powershell_generator",
            phase="preview",
            script_path=str(path),
            dangerous=bool(danger),
            danger_patterns="; ".join(danger[:5]) if danger else "none",
            needs_elevation=elev,
            is_admin=_is_admin() if _OS == "Windows" else False,
            preview=_truncate(script, 2500),
            note="Not executed. Call action=run with the same intent (or script=...) to execute.",
        )

    # ── heal: regenerate from last error context ──────────────────────────
    if action in ("heal", "fix", "repair"):
        if not intent:
            return failed("powershell_generator", "intent is required for heal")
        repair = (params.get("error_context") or params.get("error") or script_in or "").strip()
        if not repair:
            return ask(
                "powershell_generator",
                "need error_context from the failed run",
                hint="Pass error_context=... with stderr / previous script",
            )
        try:
            script = _generate_script(intent, repair_context=repair)
        except Exception as e:
            return failed("powershell_generator", f"heal generation failed: {e}")
        # fall through to same validation/exec path as run
        script_in = script
        action = "run"
        intent = intent or "healed script"

    # ── run (default) ─────────────────────────────────────────────────────
    if action not in ("run", "execute", "go"):
        return ask(
            "powershell_generator",
            "what should I do?",
            options="run (intent=...), generate, heal, status",
        )

    if _OS != "Windows":
        return failed(
            "powershell_generator",
            f"this action requires Windows PowerShell (current OS: {_OS})",
        )

    if not intent and not script_in:
        return failed("powershell_generator", "intent or script is required")

    # Generate if needed
    if script_in:
        script = _strip_markdown(script_in)
    else:
        try:
            script = _generate_script(intent)
        except Exception as e:
            return failed("powershell_generator", f"generation failed: {e}")

    if not script or len(script) < 5:
        return failed("powershell_generator", "generated script was empty")

    hard = _scan_hard_block(script)
    if hard:
        return failed(
            "powershell_generator",
            f"refused: {hard}",
            preview=_truncate(script, 800),
        )

    danger = _scan_dangerous(script)
    elev = _needs_elevation(script) or want_elevate
    path = _save_script(script, label="run")

    # Dangerous → confirm gate (unless force already given by a prior human confirm path)
    if danger and not force:
        try:
            from core import confirm

            def _run_after_confirm() -> str:
                return _execute_path(path, timeout, elevated=elev, intent=intent)

            detail = (
                f"Intent: {intent[:200]}\n"
                f"Flags: {', '.join(danger[:6])}\n"
                f"Script: {path.name}\n"
                f"Elevation: {'yes' if elev else 'no'}"
            )
            msg = confirm.request(
                key=f"psgen-{path.stem}",
                title="Run generated PowerShell script?",
                detail=detail,
                run=_run_after_confirm,
            )
            # confirm.request returns a model-facing sentence, not outcome protocol
            return (
                f"status=ask action=powershell_generator "
                f"reason=confirmation_required "
                f"dangerous=true "
                f'script="{path}" '
                f'detail="{msg[:300]}"'
            )
        except Exception as e:
            # Fallback if UI confirm unavailable: require force=true
            return ask(
                "powershell_generator",
                f"dangerous script; confirm UI unavailable ({e}). "
                "Re-call with force=true if the user explicitly agreed.",
                script=str(path),
                patterns="; ".join(danger[:5]),
            )

    # Elevation without admin: warn, optionally elevate via UAC
    if elev and not _is_admin() and not force and not want_elevate:
        return ask(
            "powershell_generator",
            "This script looks like it needs Administrator rights. "
            "Re-call with elevate=true to trigger UAC, or force=true if already elevated.",
            script=str(path),
            preview=_truncate(script, 600),
        )

    result = _execute_path(path, timeout, elevated=(elev and (want_elevate or _is_admin())), intent=intent)

    # Auto-heal once on failure
    if auto_heal and "status=failed" in result and action != "heal":
        err_match = re.search(r'reason="([^"]+)"', result) or re.search(r"reason=(\S+)", result)
        err_txt = err_match.group(1) if err_match else result[:500]
        try:
            fixed = _generate_script(
                intent,
                repair_context=f"SCRIPT:\n{script}\n\nERROR:\n{err_txt}",
            )
            if _scan_hard_block(fixed):
                return result  # keep original failure
            # Do not auto-run if the fix introduced new danger without confirm
            if _scan_dangerous(fixed):
                fix_path = _save_script(fixed, label="heal_pending")
                return failed(
                    "powershell_generator",
                    "original run failed; healed script is dangerous and needs confirm",
                    original=result[:400],
                    healed_script=str(fix_path),
                    note="Review healed_script then action=run with force=true if approved.",
                )
            fix_path = _save_script(fixed, label="heal")
            heal_res = _execute_path(
                fix_path,
                timeout,
                elevated=(elev and (want_elevate or _is_admin())),
                intent=intent,
            )
            if "status=done" in heal_res:
                return done(
                    "powershell_generator",
                    phase="auto_healed",
                    original_error=_truncate(err_txt, 400),
                    script=str(fix_path),
                    result=_truncate(heal_res, 2000),
                )
            return failed(
                "powershell_generator",
                "auto-heal also failed",
                original=_truncate(result, 600),
                healed=_truncate(heal_res, 600),
            )
        except Exception as e:
            return failed(
                "powershell_generator",
                f"run failed and heal error: {e}",
                original=_truncate(result, 800),
            )

    return result


_LEGACY_TOOL = {
    "name": "powershell_generator",
    "description": (
        "Turns a natural-language Windows admin/automation request into a PowerShell "
        "script, validates it, optionally asks for confirmation on destructive ops, "
        "saves it under cache/ps_scripts/, and executes it. "
        "Use for multi-step tasks (backup+zip+cleanup, bulk file ops, reports) that "
        "are too complex for powershell_cmd. "
        "Actions: run (default, intent=...), generate/preview (no execute), "
        "heal (fix failed script with error_context), status. "
        "Hard-blocks disk format / System32 wipes. Dangerous patterns use confirm.py. "
        "Elevation: pass elevate=true to request UAC when needed."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "run | generate | heal | status",
            },
            "intent": {
                "type": "STRING",
                "description": "Natural language description of what the script should do",
            },
            "script": {
                "type": "STRING",
                "description": "Optional ready-made PowerShell to validate/run instead of generating",
            },
            "timeout": {
                "type": "NUMBER",
                "description": "Execution timeout seconds (15–600, default 120)",
            },
            "force": {
                "type": "BOOLEAN",
                "description": "Skip confirm gate after explicit user approval",
            },
            "elevate": {
                "type": "BOOLEAN",
                "description": "Request Administrator via UAC Start-Process -Verb RunAs",
            },
            "auto_heal": {
                "type": "BOOLEAN",
                "description": "On failure, try one LLM repair+rerun (default true)",
            },
            "error_context": {
                "type": "STRING",
                "description": "For action=heal: stderr / previous script text",
            },
        },
        "required": [],
    },
    "handler": powershell_generator,
    "tier": "core",
}
