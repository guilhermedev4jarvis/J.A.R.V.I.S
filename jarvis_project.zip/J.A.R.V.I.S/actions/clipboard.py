"""Unified clipboard (basic + smart)."""
from __future__ import annotations

from core.outcome import done, failed, ask


def _dispatch(impl: str, names: list[str], params: dict, **ctx) -> str:
    import importlib
    mod = importlib.import_module(f"actions.{impl}")
    for fn in names:
        h = getattr(mod, fn, None)
        if callable(h):
            try:
                return h(params, **ctx)
            except TypeError:
                try:
                    return h(parameters=params)
                except TypeError:
                    return h(params)
    return failed("clipboard", f"missing {impl}")


def clipboard(parameters=None, **ctx) -> str:
    params = dict(parameters or {})
    mode = str(params.get("mode") or params.get("action") or "smart").strip().lower()
    # Prefer smart for default; basic for explicit get/set
    if mode in ("basic", "get", "set", "clear", "clipboard"):
        # try legacy clipboard_impl if exists
        try:
            return _dispatch("_clipboard_basic_impl", ["clipboard", "run"], params, **ctx)
        except Exception:
            pass
    if mode in ("smart", "clipboard_smart", "organize", "history"):
        return _dispatch("_clipboard_smart_impl", ["clipboard_smart", "run"], params, **ctx)
    # default smart
    return _dispatch("_clipboard_smart_impl", ["clipboard_smart", "run"], params, **ctx)


TOOL = {
    "name": "clipboard",
    "description": "Area de transferencia unificada: mode=smart|basic|get|set.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "text": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": clipboard,
    "tier": "core",
    "risk": "review",
}
