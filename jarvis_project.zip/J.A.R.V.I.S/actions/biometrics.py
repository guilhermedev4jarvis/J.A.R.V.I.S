"""
biometrics — enroll / verify owner voice or face for unlock-style gates.

Voice: pass wav_path of a short recording of the user's voice.
Face: pass image_path or use camera=true (requires webcam + opencv).

Profiles live in memory/biometrics/ (fingerprints only by default).
"""
from __future__ import annotations

from pathlib import Path

from core.outcome import done, failed, ask


def biometrics(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "status").strip().lower()
    kind = str(params.get("kind") or params.get("type") or "status").strip().lower()

    if action in ("status", "info", ""):
        from core import voice_auth, face_auth
        return done(
            "biometrics",
            action="status",
            voice_enrolled=voice_auth.has_profile(),
            face_enrolled=face_auth.has_profile(),
            voice_profile=str(Path("memory/biometrics/voice_profile.json")),
            face_profile=str(Path("memory/biometrics/face_profile.json")),
            note="Use action=enroll|verify kind=voice|face with wav_path or image_path (or camera=true).",
        )

    if action == "clear":
        from core import voice_auth, face_auth
        if kind in ("voice", "all"):
            voice_auth.clear_profile()
        if kind in ("face", "all"):
            face_auth.clear_profile()
        return done("biometrics", action="clear", kind=kind)

    if action == "enroll":
        if kind == "voice":
            from core import voice_auth
            wav = params.get("wav_path") or params.get("path")
            if not wav:
                return ask("biometrics", "wav_path of your voice sample?", kind="voice")
            try:
                info = voice_auth.enroll_from_wav(wav, label=str(params.get("label") or "owner"))
                return done("biometrics", action="enroll", kind="voice", **info)
            except Exception as e:
                return failed("biometrics", f"voice enroll failed: {e}")

        if kind == "face":
            from core import face_auth
            if str(params.get("camera") or "").lower() in ("1", "true", "yes"):
                try:
                    info = face_auth.enroll_from_camera(label=str(params.get("label") or "owner"))
                    return done("biometrics", action="enroll", kind="face", **info)
                except Exception as e:
                    return failed("biometrics", f"face camera enroll failed: {e}")
            img = params.get("image_path") or params.get("path")
            if not img:
                return ask("biometrics", "image_path of your face photo, or camera=true?", kind="face")
            try:
                info = face_auth.enroll_from_image(img, label=str(params.get("label") or "owner"))
                return done("biometrics", action="enroll", kind="face", **info)
            except Exception as e:
                return failed("biometrics", f"face enroll failed: {e}")

        return ask("biometrics", "kind=voice or kind=face?", action="enroll")

    if action == "verify":
        if kind == "voice":
            from core import voice_auth
            wav = params.get("wav_path") or params.get("path")
            if not wav:
                return ask("biometrics", "wav_path to verify?", kind="voice")
            try:
                score = voice_auth.verify_wav(wav)
                status = "done" if score.accepted else "failed"
                # Use done/failed via outcome helpers
                if score.accepted:
                    return done(
                        "biometrics",
                        action="verify",
                        kind="voice",
                        accepted=True,
                        score=round(score.score, 4),
                        threshold=score.threshold,
                        detail=score.detail,
                    )
                return failed(
                    "biometrics",
                    f"voice not accepted ({score.detail})",
                    score=round(score.score, 4),
                    threshold=score.threshold,
                )
            except Exception as e:
                return failed("biometrics", f"voice verify failed: {e}")

        if kind == "face":
            from core import face_auth
            try:
                if str(params.get("camera") or "").lower() in ("1", "true", "yes"):
                    score = face_auth.verify_from_camera()
                else:
                    img = params.get("image_path") or params.get("path")
                    if not img:
                        return ask("biometrics", "image_path or camera=true?", kind="face")
                    score = face_auth.verify_image(img)
                if score.accepted:
                    return done(
                        "biometrics",
                        action="verify",
                        kind="face",
                        accepted=True,
                        score=round(score.score, 4),
                        threshold=score.threshold,
                        detail=score.detail,
                    )
                return failed(
                    "biometrics",
                    f"face not accepted ({score.detail})",
                    score=round(score.score, 4),
                    threshold=score.threshold,
                )
            except Exception as e:
                return failed("biometrics", f"face verify failed: {e}")

        return ask("biometrics", "kind=voice or kind=face?", action="verify")

    return ask(
        "biometrics",
        "what should I do?",
        options="status | enroll | verify | clear",
        kinds="voice | face",
    )


TOOL = {
    "name": "biometrics",
    "description": (
        "Owner biometrics for unlock-style gates. "
        "Voice: enroll/verify with wav_path (short recording of the user's voice). "
        "Face: enroll/verify with image_path or camera=true. "
        "Stores local fingerprints only under memory/biometrics/. "
        "Actions: status, enroll, verify, clear. kind=voice|face."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "status | enroll | verify | clear"},
            "kind": {"type": "STRING", "description": "voice | face | all (for clear)"},
            "wav_path": {"type": "STRING", "description": "Path to WAV sample for voice"},
            "image_path": {"type": "STRING", "description": "Path to face image"},
            "path": {"type": "STRING", "description": "Alias for wav_path or image_path"},
            "camera": {"type": "STRING", "description": "true to use webcam for face"},
            "label": {"type": "STRING", "description": "Profile label (default owner)"},
        },
        "required": [],
    },
    "handler": biometrics,
    "tier": "core",
    "risk": "review",
}
