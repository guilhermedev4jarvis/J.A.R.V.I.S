"""Alias legacy tool `powershell_cmd` → `powershell_tool` (mode=execute)."""
from __future__ import annotations

from actions.powershell_tool import powershell_tool as _impl


def powershell_cmd(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "execute")
    params.setdefault("action", params.get("action") or "execute")
    return _impl(params, **ctx)


TOOL = {
    "name": "powershell_cmd",
    "description": 'Alias → powershell_tool mode=execute',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": powershell_cmd,
    "tier": "core",
    "risk": "destructive",
}
