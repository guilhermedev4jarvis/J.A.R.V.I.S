"""Alias legacy tool `dev_agent` → `code_studio` (mode=dev)."""
from __future__ import annotations

from actions.code_studio import code_studio as _impl


def dev_agent(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "dev")
    params.setdefault("action", params.get("action") or "dev")
    return _impl(params, **ctx)


TOOL = {
    "name": "dev_agent",
    "description": 'Alias → code_studio mode=dev',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": dev_agent,
    "tier": "core",
    "risk": "autonomous",
}
