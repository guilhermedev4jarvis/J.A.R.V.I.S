"""Alias legacy tool `clipboard_smart` → `clipboard` (mode=smart)."""
from __future__ import annotations

from actions.clipboard import clipboard as _impl


def clipboard_smart(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "smart")
    params.setdefault("action", params.get("action") or "smart")
    return _impl(params, **ctx)


TOOL = {
    "name": "clipboard_smart",
    "description": 'Alias → clipboard mode=smart',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": clipboard_smart,
    "tier": "core",
    "risk": "review",
}
