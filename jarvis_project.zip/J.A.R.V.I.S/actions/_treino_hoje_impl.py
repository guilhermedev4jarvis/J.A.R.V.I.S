"""
Plugin: treino_hoje — monta o treino do dia (posição + idade).

Usa os arquivos em config/treinador_base/ e o mesmo motor do modo_treinador.
Foco em um plano prático pra HOJE, não um tratado teórico.
"""

from __future__ import annotations

from pathlib import Path

from core import gemini

def _base_dir() -> Path:
    return Path(__file__).resolve().parent / "treinador_base"


def _list_bases() -> list[Path]:
    d = _base_dir()
    if not d.is_dir():
        return []
    exts = {".txt", ".md", ".json", ".pdf"}
    return sorted(
        p for p in d.iterdir()
        if p.is_file() and p.suffix.lower() in exts and p.name != "README.txt"
    )


def _read_text_safe(path: Path, limit: int = 6000) -> str:
    try:
        if path.suffix.lower() == ".pdf":
            try:
                from pypdf import PdfReader
                reader = PdfReader(str(path))
                parts = []
                for page in reader.pages[:12]:
                    parts.append(page.extract_text() or "")
                return "\n".join(parts)[:limit]
            except Exception:
                return f"[PDF {path.name}]"
        return path.read_text(encoding="utf-8", errors="replace")[:limit]
    except Exception as e:
        return f"[erro {path.name}: {e}]"


def _load_context(posicao: str, idade: str) -> str:
    files = _list_bases()
    if not files:
        return ""

    pos = (posicao or "").lower()
    age = (idade or "").lower().replace(" ", "")
    scored: list[tuple[int, Path]] = []

    for p in files:
        name = p.stem.lower()
        score = 0
        if pos and pos in name:
            score += 4
        if age and (age in name or age.replace("-", "") in name):
            score += 3
        if any(k in name for k in ("treino", "geral", "core", "dieta")):
            score += 1
        if score == 0:
            score = 1
        scored.append((score, p))

    scored.sort(key=lambda x: (-x[0], x[1].name))
    chunks: list[str] = []
    total = 0
    for _, path in scored[:5]:
        text = _read_text_safe(path)
        if not text:
            continue
        block = f"### {path.name}\n{text}\n"
        if total + len(block) > 12000:
            break
        chunks.append(block)
        total += len(block)
    return "\n".join(chunks)


def run(parameters: dict, player=None, session_memory=None) -> str:
    posicao = (parameters.get("posicao") or "geral").strip().lower()
    idade = (parameters.get("idade") or "13").strip()
    onde = (parameters.get("onde") or "campo").strip().lower()
    tempo = (parameters.get("tempo_min") or "60").strip()
    foco = (parameters.get("foco") or "").strip()

    if player:
        try:
            player.write_log(
                f"JARVIS: Treino de hoje → {posicao} | {idade} | {onde} | {tempo}min"
            )
        except Exception:
            pass

    contexto = _load_context(posicao, idade)
    tem_base = bool(contexto)

    prompt = f"""
Você é o treinador pessoal de futebol do Guilherme (13 anos, Rio Preto-SP).
Monte o TREINO DE HOJE — prático, direto, em português do Brasil.

Dados:
- Posição: {posicao}
- Idade/categoria: {idade}
- Local: {onde}
- Duração: {tempo} minutos
- Foco do dia: {foco or "livre (você escolhe o mais útil)"}

{"MATERIAL BASE:" if tem_base else "Sem arquivos locais — use conhecimento sólido de formação sub-13."}
{contexto if tem_base else ""}

Formato da resposta (obrigatório):
1. Título: "Treino de hoje — {posicao} ({tempo} min)"
2. Aquecimento (com tempo)
3. Parte principal (2–3 exercícios, séries/reps ou duração)
4. Jogo / situação (se couber no tempo)
5. Core ou volta à calma (curto)
6. Uma dica do dia (1 frase)

Regras:
- Adaptado à idade {idade}: técnica + decisão, sem volume de adulto.
- Se local = casa: só peso do corpo, bola, espaço pequeno.
- Se local = campo/quadra: pode usar cones, coletes, finalizações.
- Sem enrolação. Listas curtas. Pronto pra executar agora.
"""

    try:
        resposta = gemini.text(prompt, tier=gemini.SMART, timeout_ms=60_000)
    except Exception as e:
        return f"Não consegui montar o treino agora: {e}"

    if not tem_base:
        resposta += (
            "\n\n(Dica: coloca PDFs/TXT em config/treinador_base/ "
            "pra eu personalizar melhor.)"
        )

    return resposta.strip()

# ── Unified action contract (migrated from plugins/) ──────────────────────────

def treino_hoje(parameters=None, player=None, session_memory=None, **_ctx):
    """_LEGACY_TOOL handler — delegates to legacy run()."""
    params = parameters if isinstance(parameters, dict) else {}
    try:
        return run(params, player=player, session_memory=session_memory)
    except TypeError:
        try:
            return run(params, player=player)
        except TypeError:
            return run(params)


_LEGACY_TOOL = {
    "name": "treino_hoje",
    "description": ('Monta o treino de futebol de HOJE.  Use quando o usuário disser  ,  ,   ,  ,  . '),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "posicao": {
                "type": "STRING",
                "description": (
                    "Posição: goleiro, zagueiro, lateral, volante, meia, "
                    "ponta, atacante, ou 'geral'."
                ),
            },
            "idade": {
                "type": "STRING",
                "description": "Idade ou categoria (ex: 13, sub-13). Padrão: 13.",
            },
            "onde": {
                "type": "STRING",
                "description": (
                    "Onde vai treinar: 'campo', 'casa', 'quadra'. Padrão: campo."
                ),
            },
            "tempo_min": {
                "type": "STRING",
                "description": "Duração em minutos (ex: '45', '60'). Padrão: 60.",
            },
            "foco": {
                "type": "STRING",
                "description": (
                    "Foco opcional do dia (ex: 'finalização', '1x1', 'passe', 'core')."
                ),
            },
        },
        "required": [],
    },
    "handler": treino_hoje,
    "tier": "plugin",
    "risk": "review",
}
