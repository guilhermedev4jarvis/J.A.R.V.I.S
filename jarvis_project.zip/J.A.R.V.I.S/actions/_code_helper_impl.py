"""code_helper — multi-language helper wrapper around core.code_engine for Python paths."""
from __future__ import annotations

from pathlib import Path
from core.code_engine import get_engine
from core.outcome import done, failed, ask


def code_helper(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or "write").strip().lower()
    engine = get_engine()

    if action in ("status", "help"):
        return done("code_helper", action="status", engine="core.code_engine")

    if action in ("write", "create", "generate"):
        prompt = str(params.get("prompt") or params.get("description") or params.get("goal") or "").strip()
        path = params.get("path")
        if not prompt:
            return ask("code_helper", "prompt?")
        result = engine.generate_python(prompt, dest=str(path) if path else None)
        return result.as_outcome("code_helper")

    if action in ("edit", "fix"):
        path = str(params.get("path") or "").strip()
        if not path:
            return ask("code_helper", "path?")
        source = Path(path).read_text(encoding="utf-8", errors="replace")
        intent = str(params.get("prompt") or params.get("description") or "improve code").strip()
        try:
            fixed = engine.builder.build_one(intent, path=path, prior=source)
            vr = engine.verifier.verify_source(fixed, filename=path)
            if not vr.ok:
                fixed = engine.fix(fixed, vr.message, path=path)
            Path(path).write_text(fixed, encoding="utf-8")
            return done("code_helper", action=action, path=path, chars=len(fixed))
        except Exception as e:
            return failed("code_helper", str(e), action=action)

    if action in ("explain", "review"):
        path = str(params.get("path") or "").strip()
        if not path:
            return ask("code_helper", "path?")
        vr = engine.analyze(path=path)
        return done(
            "code_helper",
            action=action,
            path=path,
            syntax_ok=vr.ok,
            detail=vr.message,
        )

    if action == "run":
        path = str(params.get("path") or "").strip()
        if not path:
            return ask("code_helper", "path?")
        source = Path(path).read_text(encoding="utf-8", errors="replace")
        vr = engine.verifier.run_module(source)
        if vr.ok:
            return done("code_helper", action="run", path=path, stdout=vr.stdout[:1500])
        return failed("code_helper", vr.message, action="run", stderr=vr.stderr[:1500])

    return ask("code_helper", "action?", hint="write|edit|explain|run|status")


_LEGACY_TOOL = {
    "name": "code_helper",
    "description": (
        "Escrita/edicao/explicacao/run de codigo via core.code_engine. "
        "Acoes: write | edit | explain | run | status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING"},
            "prompt": {"type": "STRING"},
            "description": {"type": "STRING"},
            "path": {"type": "STRING"},
            "goal": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_helper,
    "tier": "core",
    "risk": "review",
}
