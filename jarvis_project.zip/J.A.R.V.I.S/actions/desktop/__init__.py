"""actions.desktop — domain package."""
