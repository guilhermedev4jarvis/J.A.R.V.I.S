"""
programador — alias unificado para core.code_engine (ex-plugin).

Mantido para prompts antigos que chamam programador; o motor real é CodeEngine.
"""
from __future__ import annotations

from core.code_engine import get_engine
from core.outcome import done, failed, ask


def programador(parameters: dict | None = None, **_ctx) -> str:
    params = parameters or {}
    action = str(params.get("action") or params.get("acao") or "pipeline").strip().lower()
    goal = str(params.get("goal") or params.get("prompt") or params.get("pedido") or params.get("code") or "").strip()
    engine = get_engine()

    if action in ("status", "help", "ajuda"):
        return done("programador", action="status", engine="core.code_engine")

    if action in ("pipeline", "implement", "gerar", "escrever", "code", "forge", "build"):
        if not goal:
            return ask("programador", "o que devo programar?", hint="goal=...")
        result = engine.pipeline(goal, write=True, run=False)
        return result.as_outcome("programador")

    if action in ("fix", "corrigir"):
        path = str(params.get("path") or "").strip()
        error = str(params.get("error") or params.get("erro") or "").strip()
        if not path:
            return ask("programador", "path do arquivo?")
        from pathlib import Path
        source = Path(path).read_text(encoding="utf-8", errors="replace")
        fixed = engine.fix(source, error or "improve", path=path)
        Path(path).write_text(fixed, encoding="utf-8")
        return done("programador", action="fix", path=path, chars=len(fixed))

    if not goal:
        return ask("programador", "goal ou action?", hint="pipeline|fix|status")
    result = engine.pipeline(goal, write=True, run=False)
    return result.as_outcome("programador")


_LEGACY_TOOL = {
    "name": "programador",
    "description": (
        "Programa e corrige codigo via core.code_engine "
        "(Architect→Builder→SandboxVerifier→AutoHealer). "
        "Acoes: pipeline | fix | status."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "pipeline|fix|status"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
            "pedido": {"type": "STRING"},
            "path": {"type": "STRING"},
            "error": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": programador,
    "tier": "core",
    "risk": "review",
}
