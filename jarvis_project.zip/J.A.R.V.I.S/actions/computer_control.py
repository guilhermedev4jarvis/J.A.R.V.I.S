"""Alias legacy tool `computer_control` → `desktop_control` (mode=computer)."""
from __future__ import annotations

from actions.desktop_control import desktop_control as _impl


def computer_control(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "computer")
    params.setdefault("action", params.get("action") or "computer")
    return _impl(params, **ctx)


TOOL = {
    "name": "computer_control",
    "description": 'Alias → desktop_control mode=computer',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": computer_control,
    "tier": "core",
    "risk": "destructive",
}
