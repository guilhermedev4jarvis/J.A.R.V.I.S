"""Alias legacy tool `code_review_local` → `code_studio` (mode=review)."""
from __future__ import annotations

from actions.code_studio import code_studio as _impl


def code_review_local(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "review")
    params.setdefault("action", params.get("action") or "review")
    return _impl(params, **ctx)


TOOL = {
    "name": "code_review_local",
    "description": 'Alias → code_studio mode=review',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": code_review_local,
    "tier": "core",
    "risk": "safe",
}
