"""Alias legacy tool `file_controller` → `file_manager` (mode=control)."""
from __future__ import annotations

from actions.file_manager import file_manager as _impl


def file_controller(parameters=None, **ctx):
    params = dict(parameters or {})
    params.setdefault("mode", "control")
    params.setdefault("action", params.get("action") or "control")
    return _impl(params, **ctx)


TOOL = {
    "name": "file_controller",
    "description": 'Alias → file_manager mode=control',
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING"},
            "action": {"type": "STRING"},
            "query": {"type": "STRING"},
            "path": {"type": "STRING"},
            "command": {"type": "STRING"},
            "topic": {"type": "STRING"},
            "value": {"type": "STRING"},
            "goal": {"type": "STRING"},
            "prompt": {"type": "STRING"},
        },
        "required": [],
    },
    "handler": file_controller,
    "tier": "core",
    "risk": "destructive",
}
