# Frentes 3–5 — o que mudou

## Frente 3 — Segurança
- `core/static_safety.py` — AST Python + blocklist shell
- `actions/powershell_cmd.py` — static_safety → confirm → owner_gate → exec
- `actions/self_program.py` — analyze_python(strict) + owner_gate antes de write
- `dashboard/server.py` — middleware Origin, headers, CSRF opcional (`/api/csrf`, `X-CSRF-Token`), `/ws/telemetry`

## Frente 4 — Latência e memória
- `providers/engine_pipeline.py` — `_take_sentences` libera cláusulas cedo (TTFA)
- `memory/entity_index.py` — índice em memória de entidades
- `actions/memory_compactor.py` — `lookup` + rebuild no consolidate

## Frente 5 — Higiene
- Plugins promovidos de `pending/`
- `HYGIENE_OBSOLETE.md`
- Type hints / outcome nos módulos tocados
- Testes de contrato devem continuar passando
